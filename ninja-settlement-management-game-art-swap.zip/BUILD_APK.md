# Shipping Shadow Village as an Android APK

The game is already a **fully installable PWA** (manifest + offline service worker + maskable
icon), so on any Android phone you can open the site in Chrome → **⋮ → Install app** and it
lands on the home screen with the ninja-headband icon, fullscreen, no browser chrome.

For a real signed `.apk` / `.aab`, Capacitor is preconfigured in this project.

---

## 1. Prerequisites

- **Node 18+**
- **Android Studio** (includes the Android SDK + JDK 17)
- Set `ANDROID_HOME` / `JAVA_HOME` if the CLI can't find them

## 2. Build the web bundle and add the Android platform

```bash
npm run build          # produces dist/ (single-file HTML + icon + background)
npx cap add android    # one time only — creates the android/ project
npx cap sync android   # copy dist/ into the native shell (re-run after every build)
```

## 3. Generate the launcher icons + splash

```bash
npm i -D @capacitor/assets
mkdir -p assets && cp public/icon.png assets/icon.png
npx capacitor-assets generate --android
```

This produces every mipmap density, the adaptive/round icon and the splash screens from the
single 1024×1024 `public/icon.png`.

## 4. Run it on a device

```bash
npx cap open android      # opens Android Studio → press ▶ Run
# or straight from the CLI:
npx cap run android
```

## 5. Produce the installable artefacts

**Debug APK** (sideloadable immediately, no signing setup):

```bash
cd android && ./gradlew assembleDebug
# → android/app/build/outputs/apk/debug/app-debug.apk
```

**Release APK / Play Store bundle:**

```bash
# create a keystore once
keytool -genkey -v -keystore shadow-village.keystore \
  -alias shadowvillage -keyalg RSA -keysize 2048 -validity 10000

cd android
./gradlew assembleRelease   # → app/build/outputs/apk/release/app-release.apk
./gradlew bundleRelease     # → app/build/outputs/bundle/release/app-release.aab (Play Store)
```

Point Gradle at the keystore via `android/keystore.properties` or Android Studio's
**Build → Generate Signed Bundle / APK** wizard.

---

## Configuration reference

App identity lives in `capacitor.config.ts`:

| Field              | Value                     |
| ------------------ | ------------------------- |
| `appId`            | `com.shadowvillage.game`  |
| `appName`          | `Shadow Village`          |
| `webDir`           | `dist`                    |
| background/splash  | `#0d0e1a`                 |

### Recommended native tweaks

In `android/app/src/main/AndroidManifest.xml`, add to the `<activity>` tag so the game never
rotates mid-raid and keeps its fullscreen edge-to-edge layout:

```xml
android:screenOrientation="userPortrait"
android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode"
```

The web layer already handles safe-area insets (`env(safe-area-inset-*)`), disables pinch-zoom
and double-tap zoom, and pauses the simulation when the app is backgrounded — so notches,
gesture bars and the Android back-to-home flow all behave.

## Alternative: Bubblewrap (TWA, smallest APK)

```bash
npm i -g @bubblewrap/cli
bubblewrap init --manifest https://YOUR-DOMAIN/manifest.webmanifest
bubblewrap build
```

This wraps the deployed PWA as a Trusted Web Activity — a ~1 MB APK that always serves the
latest deployed build.
