# Ninja art swap

The procedural player SVG art has been replaced by 80 normalized transparent PNG portraits in `public/ninjas/`.

- General ninjas are deterministically assigned one of 74 non-special portraits from their persistent id/look values.
- Legendary archetypes use reserved generated art: Sannin 062, Jinchuriki 066, Dojutsu 067, Puppeteer 068, Swordsman 069, Sage 070.
- Full-body and bust views both derive from the same master PNG.
- Injured/dead greyscale and nature aura remain dynamic UI effects.
- The service worker pre-caches all 80 images for offline PWA use.

The original game source was not modified; this package is a separate copy.
