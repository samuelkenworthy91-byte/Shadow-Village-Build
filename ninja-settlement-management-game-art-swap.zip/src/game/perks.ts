import type { Nature, Ninja, Skill, TraitId } from "./types";

/**
 * Per-ninja tech tree. Every ninja unlocks one node every 2 levels
 * (levels 2,4,6,8,10,12...). The pool offered is unique per ninja:
 * seeded by their id and biased by nature, trait and strongest skills.
 */

export type PerkKind = "combat" | "passive" | "signature";

export interface Perk {
  id: string;
  name: string;
  kanji: string;
  desc: string;
  kind: PerkKind;
  color: string;
  /** which skill this node belongs to (for tree branches) */
  branch: Skill | "any";
  /** combat effects */
  fx?: {
    atk?: number;        // multiplier
    def?: number;
    hp?: number;
    cp?: number;
    crit?: number;       // +chance
    critMult?: number;
    dodge?: number;
    lifesteal?: number;
    counter?: number;
    regen?: number;
    firstStrike?: boolean;
    special?: boolean;   // grants the 奥義 command
  };
  /** signature technique data */
  tech?: { name: string; power: number; stat: Skill; hits: number; note: string };
  /** village-side effects */
  village?: { missionBonus?: number; fatigue?: number; healFast?: number; xp?: number; skill?: Skill; skillAmt?: number };
}

export const PERKS: Record<string, Perk> = {
  /* ---- taijutsu branch ---- */
  ironbody: {
    id: "ironbody", name: "Iron Body", kanji: "鉄", branch: "tai", kind: "passive", color: "#e2764f",
    desc: "+18% max HP and +15% defence in battle.",
    fx: { hp: 1.18, def: 1.15 },
  },
  leafwhirl: {
    id: "leafwhirl", name: "Leaf Whirlwind", kanji: "旋", branch: "tai", kind: "combat", color: "#e2764f",
    desc: "Strikes hit 25% harder and land critical blows 12% more often.",
    fx: { atk: 1.25, crit: 0.12 },
  },
  gatekeeper: {
    id: "gatekeeper", name: "Inner Gate", kanji: "門", branch: "tai", kind: "signature", color: "#ff6a3d",
    desc: "Unlocks 奥義 Eight Gates — a devastating triple strike that scales with Taijutsu.",
    fx: { special: true, atk: 1.1 },
    tech: { name: "Eight Gates Barrage", power: 0.62, stat: "tai", hits: 3, note: "three blows, ignores guard" },
  },
  counterstance: {
    id: "counterstance", name: "Counter Stance", kanji: "返", branch: "tai", kind: "passive", color: "#e2764f",
    desc: "Return 35% of melee damage taken to the attacker.",
    fx: { counter: 0.35 },
  },

  /* ---- ninjutsu branch ---- */
  chakraflow: {
    id: "chakraflow", name: "Chakra Flow", kanji: "流", branch: "nin", kind: "passive", color: "#4f9ad9",
    desc: "+35% chakra pool and +3 chakra regained each round.",
    fx: { cp: 1.35, regen: 3 },
  },
  shadowclone: {
    id: "shadowclone", name: "Shadow Clones", kanji: "影", branch: "nin", kind: "signature", color: "#4f9ad9",
    desc: "Unlocks 奥義 Clone Barrage — hits every enemy, scales with Ninjutsu.",
    fx: { special: true },
    tech: { name: "Shadow Clone Barrage", power: 0.72, stat: "nin", hits: 1, note: "strikes all foes" },
  },
  elemental: {
    id: "elemental", name: "Nature Mastery", kanji: "性", branch: "nin", kind: "combat", color: "#4f9ad9",
    desc: "Elemental jutsu deal 40% more damage.",
    fx: { atk: 1.08 },
  },
  sealing: {
    id: "sealing", name: "Sealing Arts", kanji: "封", branch: "nin", kind: "passive", color: "#4f9ad9",
    desc: "+12% mission success for any cell this ninja leads.",
    village: { missionBonus: 0.12 },
  },

  /* ---- genjutsu branch ---- */
  minddagger: {
    id: "minddagger", name: "Mind Dagger", kanji: "刃", branch: "gen", kind: "combat", color: "#b46ae0",
    desc: "Genjutsu never fails against lower-willed foes and stuns for 2 rounds.",
  },
  mirrorveil: {
    id: "mirrorveil", name: "Mirror Veil", kanji: "鏡", branch: "gen", kind: "passive", color: "#b46ae0",
    desc: "18% chance to evade any attack entirely.",
    fx: { dodge: 0.18 },
  },
  nightmare: {
    id: "nightmare", name: "Nightmare Realm", kanji: "夢", branch: "gen", kind: "signature", color: "#b46ae0",
    desc: "Unlocks 奥義 Nightmare Realm — heavy damage plus a guaranteed stun.",
    fx: { special: true },
    tech: { name: "Nightmare Realm", power: 1.15, stat: "gen", hits: 1, note: "stuns the target" },
  },

  /* ---- stealth branch ---- */
  ambush: {
    id: "ambush", name: "Ambush", kanji: "伏", branch: "ste", kind: "passive", color: "#9aa7bd",
    desc: "Always acts first in the opening round and crits 15% more often.",
    fx: { firstStrike: true, crit: 0.15 },
  },
  vanish: {
    id: "vanish", name: "Body Flicker", kanji: "瞬", branch: "ste", kind: "passive", color: "#9aa7bd",
    desc: "+14% dodge, and this ninja tires 30% more slowly on missions.",
    fx: { dodge: 0.14 }, village: { fatigue: 0.7 },
  },
  assassinate: {
    id: "assassinate", name: "Silent Kill", kanji: "殺", branch: "ste", kind: "signature", color: "#9aa7bd",
    desc: "Unlocks 奥義 Silent Kill — massive damage to the weakest enemy.",
    fx: { special: true, critMult: 0.4 },
    tech: { name: "Silent Kill", power: 1.5, stat: "ste", hits: 1, note: "executes the frailest foe" },
  },

  /* ---- medical branch ---- */
  fieldmedic: {
    id: "fieldmedic", name: "Field Medic", kanji: "療", branch: "med", kind: "passive", color: "#63c58c",
    desc: "Allies heal 40% more, and squadmates recover from injury a day sooner.",
    village: { healFast: 1 },
  },
  regeneration: {
    id: "regeneration", name: "Cell Regeneration", kanji: "再", branch: "med", kind: "passive", color: "#63c58c",
    desc: "Recover HP every round and drain 20% of damage dealt.",
    fx: { regen: 4, lifesteal: 0.2 },
  },
  mysticrevive: {
    id: "mysticrevive", name: "Mystic Revival", kanji: "蘇", branch: "med", kind: "signature", color: "#63c58c",
    desc: "Unlocks 奥義 Mystic Revival — fully mends an ally, or revives a fallen one.",
    fx: { special: true },
    tech: { name: "Mystic Revival", power: 2.4, stat: "med", hits: 1, note: "revives a downed ally" },
  },

  /* ---- speed branch ---- */
  flashstep: {
    id: "flashstep", name: "Flash Step", kanji: "閃", branch: "spd", kind: "passive", color: "#f4c64f",
    desc: "Acts far earlier in the turn order and dodges 10% of attacks.",
    fx: { dodge: 0.1, firstStrike: true },
  },
  swiftlegs: {
    id: "swiftlegs", name: "Wind Runner", kanji: "駆", branch: "spd", kind: "passive", color: "#f4c64f",
    desc: "Missions with this ninja finish a day faster where possible.",
    village: { fatigue: 0.85 },
  },
  thunderfang: {
    id: "thunderfang", name: "Thunder Fang", kanji: "雷", branch: "spd", kind: "signature", color: "#f4c64f",
    desc: "Unlocks 奥義 Thunder Fang — two lightning-fast strikes that rarely miss.",
    fx: { special: true, crit: 0.1 },
    tech: { name: "Thunder Fang", power: 0.7, stat: "spd", hits: 2, note: "two blindingly fast hits" },
  },

  /* ---- universal ---- */
  veteran: {
    id: "veteran", name: "Veteran Instinct", kanji: "戦", branch: "any", kind: "passive", color: "#cfd6e4",
    desc: "+10% to every combat stat and +15% experience.",
    fx: { atk: 1.1, def: 1.1, hp: 1.1 }, village: { xp: 1.15 },
  },
  willoffire: {
    id: "willoffire", name: "Will of Fire", kanji: "火", branch: "any", kind: "passive", color: "#ff6a3d",
    desc: "While this ninja stands, every ally hits 12% harder.",
    fx: { atk: 1.05 },
  },
  scholar: {
    id: "scholar", name: "Scroll Scholar", kanji: "巻", branch: "any", kind: "passive", color: "#cfd6e4",
    desc: "Gains 25% more experience from every mission.",
    village: { xp: 1.25 },
  },
};

/* ---------------- per-ninja tree generation ---------------- */

const BRANCH_OF: Record<Nature, Skill> = { fire: "tai", water: "med", wind: "spd", earth: "nin", light: "gen" };

const TRAIT_BRANCH: Partial<Record<TraitId, Skill>> = {
  shadowborn: "ste", hotblood: "tai", analyst: "gen", medicnin: "med", swift: "spd", wildcard: "nin",
};

function mulberry(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Tier index for a level: a node every 2 levels, starting at level 2. */
export function tiersUnlocked(level: number): number {
  return Math.max(0, Math.floor(level / 2));
}

export function pendingPerks(n: Ninja): number {
  return Math.max(0, tiersUnlocked(n.level) - n.perks.length);
}

const ALL_IDS = Object.keys(PERKS);

/**
 * Build this ninja's personal tree: 6 tiers x up to 3 choices,
 * biased toward their nature / trait / best skills but never identical.
 */
export function perkTree(n: Ninja): Perk[][] {
  const rng = mulberry(n.id * 7919 + Math.floor(n.seed * 100000));
  const favour: Skill[] = [BRANCH_OF[n.nature]];
  const tb = TRAIT_BRANCH[n.trait];
  if (tb) favour.push(tb);
  const best = (Object.keys(n.s) as Skill[]).sort((a, b) => n.s[b] - n.s[a]).slice(0, 2);
  favour.push(...best);

  const pool = [...ALL_IDS];
  // weight: favoured branches float to the front
  pool.sort((a, b) => {
    const wa = (favour.includes(PERKS[a].branch as Skill) ? 2 : 0) + rng();
    const wb = (favour.includes(PERKS[b].branch as Skill) ? 2 : 0) + rng();
    return wb - wa;
  });

  // legendary signature always sits in tier 3
  const legendPerk = n.legend ? LEGEND_PERK[n.legend] : null;

  const tiers: Perk[][] = [];
  const used = new Set<string>();
  for (let t = 0; t < 6; t++) {
    const row: Perk[] = [];
    const want = t === 0 ? 2 : 3;
    for (const id of pool) {
      if (row.length >= want) break;
      if (used.has(id)) continue;
      const p = PERKS[id];
      // signatures only from tier 2 onward
      if (p.kind === "signature" && t < 2) continue;
      row.push(p);
      used.add(id);
    }
    if (legendPerk && t === 2) {
      row.unshift(legendPerk);
      if (row.length > 3) row.pop();
    }
    if (row.length) tiers.push(row);
  }
  return tiers;
}

export function perkById(id: string): Perk | null {
  return PERKS[id] ?? LEGEND_PERKS[id] ?? null;
}

/* ---------------- legendary shinobi ---------------- */

export interface Legend {
  id: string;
  title: string;
  epithet: string;
  color: string;
  blurb: string;
  bonus: Partial<Record<Skill, number>>;
  pot: number;
  perk: Perk;
}

const mk = (id: string, name: string, kanji: string, color: string, desc: string, fx: Perk["fx"], tech?: Perk["tech"], village?: Perk["village"]): Perk => ({
  id, name, kanji, desc, color, kind: "signature", branch: "any", fx, tech, village,
});

export const LEGENDS: Record<string, Legend> = {
  jinchuriki: {
    id: "jinchuriki", title: "Jinchūriki", epithet: "the Sealed Beast", color: "#ff7a3d",
    blurb: "A tailed beast sleeps behind the seal. Terrifying reserves, terrifying risk.",
    bonus: { tai: 8, nin: 9 }, pot: 5,
    perk: mk("lg_beastcloak", "Beast Cloak", "獣", "#ff7a3d",
      "Unlocks 奥義 Beast Cloak — colossal damage that grows as HP falls, and drains life.",
      { special: true, hp: 1.35, lifesteal: 0.25, regen: 3 },
      { name: "Tailed Beast Bomb", power: 1.35, stat: "nin", hits: 1, note: "stronger the closer to death" }),
  },
  doujutsu: {
    id: "doujutsu", title: "Dōjutsu Heir", epithet: "the Mirror Eye", color: "#c0403a",
    blurb: "Born with a kekkei genkai eye. Copies technique, reads movement before it happens.",
    bonus: { gen: 9, spd: 6 }, pot: 5,
    perk: mk("lg_mirroreye", "Mirror Eye", "眼", "#c0403a",
      "Unlocks 奥義 Mirror Eye — copies the foe's strongest attack and returns it doubled. +25% dodge.",
      { special: true, dodge: 0.25, crit: 0.12 },
      { name: "Mirror Eye Reversal", power: 1.2, stat: "gen", hits: 1, note: "turns their power back on them" }),
  },
  sannin: {
    id: "sannin", title: "Sannin Pupil", epithet: "the Summoner", color: "#63c58c",
    blurb: "Trained under a legend. Signs a summoning contract no one else in the village holds.",
    bonus: { nin: 7, med: 7 }, pot: 4,
    perk: mk("lg_summon", "Summoning Contract", "召", "#63c58c",
      "Unlocks 奥義 Summoning — strikes every foe and mends the whole cell.",
      { special: true, cp: 1.4, regen: 4 },
      { name: "Summoning: Great Toad", power: 0.66, stat: "nin", hits: 1, note: "hits all foes and heals allies" }),
  },
  puppeteer: {
    id: "puppeteer", title: "Puppet Master", epithet: "of the Crimson Strings", color: "#b46ae0",
    blurb: "Fights at a distance through lacquered puppets tipped with poison.",
    bonus: { nin: 6, ste: 7 }, pot: 4,
    perk: mk("lg_puppets", "Crimson Puppets", "傀", "#b46ae0",
      "Unlocks 奥義 Puppet Storm — three poisoned strikes. Counters every melee blow.",
      { special: true, counter: 0.4, crit: 0.1 },
      { name: "Puppet Storm", power: 0.55, stat: "nin", hits: 3, note: "three poisoned blades" }),
  },
  swordsman: {
    id: "swordsman", title: "Blade Demon", epithet: "of the Silent Mist", color: "#49b6e8",
    blurb: "One of the great swords. The mist rises wherever they walk.",
    bonus: { tai: 9, ste: 6 }, pot: 4,
    perk: mk("lg_silentmist", "Silent Killing", "霧", "#49b6e8",
      "Unlocks 奥義 Silent Killing — an unavoidable execution stroke. Always strikes first.",
      { special: true, firstStrike: true, critMult: 0.5 },
      { name: "Silent Killing Stroke", power: 1.45, stat: "tai", hits: 1, note: "cannot be dodged or guarded" }),
  },
  sage: {
    id: "sage", title: "Sage Aspirant", epithet: "of the Mountain", color: "#f4c64f",
    blurb: "Draws chakra from the world itself. Calm, immovable, endlessly deep.",
    bonus: { nin: 6, tai: 5, med: 5 }, pot: 5,
    perk: mk("lg_sagemode", "Sage Mode", "仙", "#f4c64f",
      "Unlocks 奥義 Sage Art. All combat stats +20% and chakra regenerates rapidly.",
      { special: true, atk: 1.2, def: 1.2, hp: 1.2, regen: 5 },
      { name: "Sage Art: Rasengan", power: 1.25, stat: "nin", hits: 1, note: "natural energy detonation" }),
  },
};

export const LEGEND_IDS = Object.keys(LEGENDS);
export const LEGEND_PERK: Record<string, Perk> = Object.fromEntries(
  LEGEND_IDS.map((k) => [k, LEGENDS[k].perk])
);
export const LEGEND_PERKS: Record<string, Perk> = Object.fromEntries(
  LEGEND_IDS.map((k) => [LEGENDS[k].perk.id, LEGENDS[k].perk])
);

/* ---------------- aggregate a ninja's unlocked effects ---------------- */

export interface PerkFx {
  atk: number; def: number; hp: number; cp: number;
  crit: number; critMult: number; dodge: number;
  lifesteal: number; counter: number; regen: number;
  firstStrike: boolean; special: Perk | null;
  missionBonus: number; fatigue: number; healFast: number; xp: number;
  allyAtk: number;
}

export function perkFx(n: Ninja): PerkFx {
  const out: PerkFx = {
    atk: 1, def: 1, hp: 1, cp: 1, crit: 0, critMult: 0, dodge: 0,
    lifesteal: 0, counter: 0, regen: 0, firstStrike: false, special: null,
    missionBonus: 0, fatigue: 1, healFast: 0, xp: 1, allyAtk: 1,
  };
  for (const id of n.perks) {
    const p = perkById(id);
    if (!p) continue;
    const f = p.fx;
    if (f) {
      out.atk *= f.atk ?? 1;
      out.def *= f.def ?? 1;
      out.hp *= f.hp ?? 1;
      out.cp *= f.cp ?? 1;
      out.crit += f.crit ?? 0;
      out.critMult += f.critMult ?? 0;
      out.dodge += f.dodge ?? 0;
      out.lifesteal += f.lifesteal ?? 0;
      out.counter += f.counter ?? 0;
      out.regen += f.regen ?? 0;
      if (f.firstStrike) out.firstStrike = true;
      if (f.special && p.tech) out.special = p;
    }
    const v = p.village;
    if (v) {
      out.missionBonus += v.missionBonus ?? 0;
      out.fatigue *= v.fatigue ?? 1;
      out.healFast += v.healFast ?? 0;
      out.xp *= v.xp ?? 1;
    }
    if (p.id === "willoffire") out.allyAtk *= 1.12;
  }
  return out;
}
