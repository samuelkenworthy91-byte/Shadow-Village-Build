export type Phase = "menu" | "playing" | "paused" | "over" | "battle";
export type Rank = "D" | "C" | "B" | "A" | "S";
export type NinRank = "genin" | "chunin" | "jonin" | "anbu" | "kage";
export type Bld = "hall" | "farm" | "tea" | "dojo" | "tower" | "shrine";
export type NinjaStatus = "ready" | "mission" | "injured";

export type Skill = "nin" | "tai" | "gen" | "ste" | "med" | "spd";
export type Nature = "fire" | "water" | "wind" | "earth" | "light";
export type TraitId =
  | "prodigy" | "shadowborn" | "hotblood" | "analyst" | "medicnin"
  | "swift" | "ironwill" | "lucky" | "stoic" | "wildcard";

export interface Look {
  hair: number;
  hairColor: number;
  skin: number;
  eyes: number;
  mark: number;
  outfit: number;
  band: number;
  acc: number;
  build: number;
}

export interface Ninja {
  id: number;
  name: string;
  seed: number;
  look: Look;
  nature: Nature;
  trait: TraitId;
  rank: NinRank;
  level: number;
  xp: number;
  sp: number;
  pot: number;         // true potential 1..5 (revealed gradually)
  s: Record<Skill, number>;
  growth: Record<Skill, number>;
  fatigue: number;
  status: NinjaStatus;
  daysLeft: number;    // mission days remaining / injury days remaining
  missionId: number | null;
  runs: number;
  wins: number;
  /** unlocked tech-tree node ids */
  perks: string[];
  /** legendary archetype id, if this is a unique shinobi */
  legend: string | null;
  title: string | null;
}

/* ---------------- mission field report ---------------- */

export interface ReportLine {
  txt: string;
  kind: "beat" | "good" | "bad" | "clutch" | "flavour";
}

export interface ReportXp {
  id: number;
  name: string;
  xp: number;
  levels: number;
  sp: number;
  skillUps: { k: Skill; n: number }[];
  injured: boolean;
  perkReady: boolean;
}

export interface Report {
  id: number;
  day: number;
  mission: string;
  rank: Rank;
  win: boolean;
  chance: number;
  gold: number;
  rice: number;
  pts: number;
  lines: ReportLine[];
  xp: ReportXp[];
}

export interface Mission {
  id: number;
  rank: Rank;
  name: string;
  desc: string;
  req: Partial<Record<Skill, number>>;
  slots: number;
  days: number;        // days remaining once deployed
  totalDays: number;
  gold: number;
  rice: number;
  xp: number;
  score: number;
  expiresDay: number;
  minRank: NinRank;
  squad: number[];
}

/* ---------------- battle ---------------- */

export type BAction = "attack" | "jutsu" | "genjutsu" | "heal" | "guard" | "special";

export interface Unit {
  uid: string;
  name: string;
  foe: boolean;
  ninjaId: number | null;
  kind: string;        // enemy art variant
  hp: number;
  maxHp: number;
  cp: number;
  maxCp: number;
  atk: number;
  def: number;
  spd: number;
  nin: number;
  gen: number;
  med: number;
  guard: boolean;
  stun: number;
  alive: boolean;
  look: Look | null;
  nature: Nature | null;
  level: number;
  rank: NinRank | null;
  /** derived combat modifiers from skills + perks */
  crit: number;
  critMult: number;
  dodge: number;
  lifesteal: number;
  counter: number;
  regen: number;
  firstStrike: boolean;
  special: string | null;   // perk id of a signature technique
  perks: string[];
  legend: string | null;
}

export interface BattleLog {
  t: string;
  kind: "hit" | "crit" | "heal" | "info" | "down" | "miss";
}

export interface Battle {
  round: number;
  units: Unit[];
  order: string[];
  idx: number;
  state: "choose" | "resolving" | "won" | "lost";
  log: BattleLog[];
  clan: string;
  gold: number;
  score: number;
  flash: { uid: string; amount: number; kind: string; n: number } | null;
  acting: string | null;
}

export interface Stats {
  done: number;
  failed: number;
  raids: number;
  earned: number;
  levels: number;
  promos: number;
}

export interface LogEntry {
  txt: string;
  kind: string;
  id: number;
}

export interface GameState {
  phase: Phase;
  day: number;
  ap: number;
  gold: number;
  rice: number;
  score: number;
  streak: number;
  hp: number;
  hpMax: number;
  threat: number;
  hungry: boolean;
  ninjas: Ninja[];
  missions: Mission[];
  b: Record<Bld, number>;
  nextId: number;
  raids: number;
  clan: string;
  stats: Stats;
  battle: Battle | null;
  scout: Ninja[] | null;
  log: LogEntry[];
  reports: Report[];
}

export interface Ev {
  type: string;
  [k: string]: unknown;
}
