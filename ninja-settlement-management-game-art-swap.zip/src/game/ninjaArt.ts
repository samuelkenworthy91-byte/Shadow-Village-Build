import type { Look } from "./types";

/**
 * Image-backed player ninja art. Six generated portraits are reserved for
 * legendary archetypes; the remaining 74 form the deterministic general pool.
 */
export const LEGEND_ART: Record<string, number> = {
  sannin: 62,
  jinchuriki: 66,
  doujutsu: 67,
  puppeteer: 68,
  swordsman: 69,
  sage: 70,
};

export const GENERAL_ART_IDS: number[] = Array.from({ length: 80 }, (_, i) => i + 1)
  .filter((id) => !Object.values(LEGEND_ART).includes(id));

function mix32(x: number): number {
  x = Math.imul(x ^ (x >>> 16), 0x45d9f3b);
  x = Math.imul(x ^ (x >>> 16), 0x45d9f3b);
  return (x ^ (x >>> 16)) >>> 0;
}

/** Stable portrait assignment: a ninja keeps the same art for the life of the save. */
export function ninjaArtId(n: { id: number; look: Look; legend?: string | null }): number {
  if (n.legend && LEGEND_ART[n.legend]) return LEGEND_ART[n.legend];

  // Include immutable appearance rolls as salt so sequential IDs distribute well.
  const L = n.look;
  let salt = n.id >>> 0;
  salt ^= (L.hair & 15) << 1;
  salt ^= (L.hairColor & 15) << 5;
  salt ^= (L.skin & 7) << 9;
  salt ^= (L.outfit & 15) << 12;
  salt ^= (L.acc & 7) << 17;
  salt ^= (L.build & 7) << 20;
  const idx = mix32(salt) % GENERAL_ART_IDS.length;
  return GENERAL_ART_IDS[idx];
}

export function ninjaArtSrc(n: { id: number; look: Look; legend?: string | null }): string {
  return `/ninjas/ninja_${String(ninjaArtId(n)).padStart(3, "0")}.png`;
}
