import type { Bld, Nature, NinRank, Rank, Skill, TraitId } from "./types";

export const MISSION_CAP = 6;
export const AP_BASE = 3;
export const SCOUT_COST = { gold: 30, rice: 20 };
export const RECRUIT_PICK = 3;
export const REPAIR_COST = { gold: 35, rice: 10 };

export const FARM_RICE = 8;
export const TEA_GOLD = 7;
export const TOWER_DEF = 1;
export const EAT_PER_DAY = 0.9;

export const DOJO_CHANCE = 0.06;
export const DOJO_XP_DAY = 1.1;
export const SHRINE_REST = 14;      // extra fatigue recovered / day / level
export const REST_PER_DAY = 30;
export const FATIGUE_PER_DAY_OUT = 22;
export const THREAT_PER_DAY = 19;

/* ---------------- skills ---------------- */

export const SKILLS: Skill[] = ["nin", "tai", "gen", "ste", "med", "spd"];

export const SKILL_META: Record<Skill, { name: string; short: string; kanji: string; color: string }> = {
  nin: { name: "Ninjutsu", short: "NIN", kanji: "忍", color: "#4f9ad9" },
  tai: { name: "Taijutsu", short: "TAI", kanji: "体", color: "#e2764f" },
  gen: { name: "Genjutsu", short: "GEN", kanji: "幻", color: "#b46ae0" },
  ste: { name: "Stealth", short: "STE", kanji: "隠", color: "#9aa7bd" },
  med: { name: "Medical", short: "MED", kanji: "医", color: "#63c58c" },
  spd: { name: "Speed", short: "SPD", kanji: "速", color: "#f4c64f" },
};

export const NATURE_META: Record<Nature, { name: string; kanji: string; color: string; boost: Skill; jutsu: string }> = {
  fire: { name: "Fire", kanji: "火", color: "#ff6a3d", boost: "tai", jutsu: "Fireball Jutsu" },
  water: { name: "Water", kanji: "水", color: "#49b6e8", boost: "med", jutsu: "Water Dragon" },
  wind: { name: "Wind", kanji: "風", color: "#8fe0c4", boost: "spd", jutsu: "Wind Scythe" },
  earth: { name: "Earth", kanji: "土", color: "#c9a06a", boost: "nin", jutsu: "Stone Fist" },
  light: { name: "Lightning", kanji: "雷", color: "#f4d94f", boost: "gen", jutsu: "Chidori Bolt" },
};

export const TRAIT_META: Record<TraitId, { name: string; desc: string; boost?: Skill; icon: string }> = {
  prodigy: { name: "Prodigy", desc: "+40% experience gain", icon: "★" },
  shadowborn: { name: "Shadow Born", desc: "grows Stealth fast", boost: "ste", icon: "隠" },
  hotblood: { name: "Hot-Blooded", desc: "grows Taijutsu fast", boost: "tai", icon: "炎" },
  analyst: { name: "Analyst", desc: "grows Genjutsu fast", boost: "gen", icon: "眼" },
  medicnin: { name: "Medic-nin", desc: "grows Medical fast · heals allies", boost: "med", icon: "医" },
  swift: { name: "Swift", desc: "grows Speed fast", boost: "spd", icon: "疾" },
  ironwill: { name: "Iron Will", desc: "gains 40% less fatigue", icon: "鉄" },
  lucky: { name: "Lucky", desc: "+8% mission success", icon: "運" },
  stoic: { name: "Stoic", desc: "recovers from injury fast", icon: "静" },
  wildcard: { name: "Wildcard", desc: "grows Ninjutsu fast", boost: "nin", icon: "変" },
};

export const TRAIT_IDS = Object.keys(TRAIT_META) as TraitId[];

/* ---------------- ninja ranks ---------------- */

export const NIN_RANKS: NinRank[] = ["genin", "chunin", "jonin", "anbu", "kage"];

export interface RankMeta {
  name: string;
  kanji: string;
  color: string;
  /** promotion requirements to REACH this rank */
  level: number;
  missions: number;
  gold: number;
  boost: number; // flat skill boost granted on promotion
}

export const RANK_META: Record<NinRank, RankMeta> = {
  genin: { name: "Genin", kanji: "下", color: "#9aa7bd", level: 1, missions: 0, gold: 0, boost: 0 },
  chunin: { name: "Chūnin", kanji: "中", color: "#63c58c", level: 4, missions: 3, gold: 70, boost: 2 },
  jonin: { name: "Jōnin", kanji: "上", color: "#4f9ad9", level: 8, missions: 9, gold: 160, boost: 3 },
  anbu: { name: "ANBU", kanji: "暗", color: "#b46ae0", level: 13, missions: 18, gold: 320, boost: 4 },
  kage: { name: "Kage", kanji: "影", color: "#ff8a4d", level: 19, missions: 30, gold: 650, boost: 6 },
};

export function rankIndex(r: NinRank): number {
  return NIN_RANKS.indexOf(r);
}

export function nextRank(r: NinRank): NinRank | null {
  const i = rankIndex(r);
  return i < NIN_RANKS.length - 1 ? NIN_RANKS[i + 1] : null;
}

/** minimum ninja rank a mission grade demands in the cell */
export const MISSION_MIN_RANK: Record<Rank, NinRank> = {
  D: "genin", C: "genin", B: "chunin", A: "jonin", S: "anbu",
};

/* ---------------- buildings ---------------- */

export interface BldMeta {
  name: string;
  kanji: string;
  desc: string;
  costs: { gold: number; rice: number }[];
  max: number;
  hotkey: string;
  color: string;
}

export const BUILD_ORDER: Bld[] = ["farm", "tea", "dojo", "tower", "shrine", "hall"];

export const BUILDINGS: Record<Bld, BldMeta> = {
  farm: {
    name: "Rice Paddy", kanji: "田", color: "#8fce6a",
    desc: `+${FARM_RICE} rice each day`,
    costs: [{ gold: 40, rice: 0 }, { gold: 70, rice: 20 }, { gold: 110, rice: 40 }],
    max: 3, hotkey: "F",
  },
  tea: {
    name: "Tea House", kanji: "茶", color: "#f4c64f",
    desc: `+${TEA_GOLD} gold each day`,
    costs: [{ gold: 50, rice: 0 }, { gold: 85, rice: 20 }, { gold: 130, rice: 45 }],
    max: 3, hotkey: "T",
  },
  dojo: {
    name: "Dōjō", kanji: "道", color: "#4f9ad9",
    desc: `+${Math.round(DOJO_CHANCE * 100)}% success · trains resting nin`,
    costs: [{ gold: 60, rice: 10 }, { gold: 100, rice: 30 }, { gold: 160, rice: 60 }],
    max: 3, hotkey: "D",
  },
  tower: {
    name: "Watchtower", kanji: "櫓", color: "#e2764f",
    desc: "battle: +1 ally turn order · village guard",
    costs: [{ gold: 50, rice: 10 }, { gold: 90, rice: 25 }, { gold: 140, rice: 55 }],
    max: 3, hotkey: "W",
  },
  shrine: {
    name: "Shrine", kanji: "社", color: "#f2a7c3",
    desc: `+${SHRINE_REST} rest each day · faster healing`,
    costs: [{ gold: 60, rice: 15 }, { gold: 100, rice: 35 }, { gold: 150, rice: 70 }],
    max: 3, hotkey: "S",
  },
  hall: {
    name: "Main Hall", kanji: "影", color: "#e2452f",
    desc: "+2 ninja cap · +1 action each day",
    costs: [{ gold: 0, rice: 0 }, { gold: 120, rice: 10 }, { gold: 220, rice: 50 }],
    max: 3, hotkey: "H",
  },
};

export const RANK_COLOR: Record<Rank, string> = {
  D: "#9aa78f", C: "#4fb286", B: "#4f9ad9", A: "#b46ae0", S: "#f4c64f",
};

export const RANK_KANJI: Record<Rank, string> = {
  D: "丁", C: "丙", B: "乙", A: "甲", S: "神",
};

/* ---------------- missions ---------------- */

export interface MTemplate {
  name: string;
  desc: string;
  focus: Skill[];
  slots: number;
}

export const MISSION_TEMPLATES: Record<Rank, MTemplate[]> = {
  D: [
    { name: "Find the Lost Cat Tama", desc: "Fast hands, quiet feet.", focus: ["spd", "ste"], slots: 1 },
    { name: "Weed the Elder's Garden", desc: "Backbreaking. Character building.", focus: ["tai"], slots: 1 },
    { name: "Deliver the Sealed Letter", desc: "Do not open it. Seriously.", focus: ["spd"], slots: 1 },
    { name: "Patch Up the Academy Class", desc: "Scraped knees everywhere.", focus: ["med"], slots: 1 },
    { name: "Scare Off Mushroom Thieves", desc: "Look menacing. That is all.", focus: ["tai", "ste"], slots: 2 },
    { name: "Paint the Village Fence", desc: "A rite of passage.", focus: ["tai", "spd"], slots: 2 },
  ],
  C: [
    { name: "Escort the Tea Merchant", desc: "Bandits love oolong season.", focus: ["tai", "spd"], slots: 2 },
    { name: "Catch the Rice Thief", desc: "Follow the grains. Literally.", focus: ["ste", "spd"], slots: 2 },
    { name: "Break the Illusion Trap", desc: "The bamboo road lies to travellers.", focus: ["gen", "nin"], slots: 2 },
    { name: "Field Clinic at the Ford", desc: "Fever season on the river.", focus: ["med", "nin"], slots: 2 },
    { name: "Guard the Festival Drums", desc: "The taiko must not fall silent.", focus: ["tai", "gen"], slots: 2 },
    { name: "Map the Northern Pass", desc: "Ink, rope, and wet sandals.", focus: ["ste", "spd"], slots: 2 },
  ],
  B: [
    { name: "Infiltrate the Bandit Camp", desc: "Walk like them. Smell like them.", focus: ["ste", "gen", "spd"], slots: 3 },
    { name: "Retrieve the Stolen Scroll", desc: "Secrets heavier than steel.", focus: ["ste", "nin"], slots: 3 },
    { name: "Duel the Rogue Swordsman", desc: "He has beaten three cells.", focus: ["tai", "spd", "med"], slots: 3 },
    { name: "Sabotage the Storehouse", desc: "Ropes cut themselves, they say.", focus: ["nin", "ste"], slots: 3 },
    { name: "Rescue the Poisoned Caravan", desc: "Antidote, and fast.", focus: ["med", "spd", "nin"], slots: 3 },
  ],
  A: [
    { name: "Silence the War-Horn Tower", desc: "One horn. One chance.", focus: ["ste", "nin", "spd"], slots: 3 },
    { name: "Steal the Fox Lord's Ledger", desc: "Nine tails, one weakness.", focus: ["gen", "ste", "nin"], slots: 4 },
    { name: "Extract the Captured Scout", desc: "No one is left in the dark.", focus: ["med", "tai", "ste"], slots: 4 },
    { name: "Shatter the Blood Genjutsu", desc: "The village dreams of drowning.", focus: ["gen", "med", "nin"], slots: 4 },
    { name: "Hunt the Missing-nin", desc: "He was one of ours, once.", focus: ["tai", "spd", "gen"], slots: 4 },
  ],
  S: [
    { name: "Storm the Obsidian Keep", desc: "Where shadows fear to tread.", focus: ["tai", "nin", "ste", "med"], slots: 4 },
    { name: "Steal the Shogun's Seal", desc: "The realm will never know.", focus: ["ste", "gen", "spd", "nin"], slots: 4 },
    { name: "The Nine-Tailed Contract", desc: "Signed in stolen moonlight.", focus: ["nin", "gen", "med", "tai"], slots: 4 },
    { name: "Sever the Serpent's Head", desc: "One cut for a thousand lives.", focus: ["tai", "spd", "ste", "med"], slots: 4 },
  ],
};

export const NINJA_NAMES = [
  "Kaze", "Kuro", "Hana", "Rin", "Sora", "Tora", "Yuki", "Hayate", "Mika",
  "Shin", "Ayame", "Ginta", "Ren", "Kohaku", "Saya", "Tsubasa", "Inori",
  "Kenji", "Moe", "Isamu", "Noa", "Gin", "Hoshi", "Kuma", "Aoi", "Jiro",
  "Raiden", "Suzu", "Take", "Nozomi", "Fuu", "Kaito", "Emi", "Daichi",
];

export const SURNAMES = [
  "Amagiri", "Kurosawa", "Hyodo", "Shirane", "Akatsuchi", "Yugure",
  "Nanase", "Sakaki", "Tsukino", "Hazama", "Reikan", "Momochi",
];

export const CLANS = [
  "Night Talon Order", "Crimson Mist Sect", "Hollow Mask Guild",
  "Iron Cicada Clan", "Jagged Fang Clan", "Pale Viper Cabal",
];

export const ENEMY_KINDS: Record<string, { name: string; color: string; hp: number; atk: number; spd: number }> = {
  grunt: { name: "Rogue Genin", color: "#7a6a9e", hp: 0.8, atk: 0.85, spd: 1 },
  brute: { name: "Oni Brawler", color: "#c0533a", hp: 1.45, atk: 1.15, spd: 0.7 },
  shadow: { name: "Mist Assassin", color: "#4f7f9d", hp: 0.75, atk: 1.15, spd: 1.35 },
  boss: { name: "Clan Captain", color: "#d4b03c", hp: 1.9, atk: 1.3, spd: 1.05 },
};

/* ---------------- sprite palettes ---------------- */

/* Ghibli-leaning palettes: sun-warmed, muted, natural pigments. */
export const HAIR_COLORS = [
  "#e8c46a", // wheat blond
  "#d98f4e", // apricot
  "#c2543c", // clay red
  "#3b3a4a", // soft charcoal
  "#7a5638", // walnut
  "#d5d2cc", // ash white
  "#7d6aa8", // muted violet
  "#d78fa4", // dusty rose
  "#5f87ad", // slate blue
  "#6f9f74", // moss green
];
export const SKIN_TONES = ["#f7ddc0", "#eec6a1", "#dbab82", "#b4805a", "#8c5f42"];
export const OUTFIT_COLORS = [
  "#c2543c", // persimmon
  "#4a6a94", // dusk blue
  "#5f8055", // moss
  "#6d5a8c", // wisteria
  "#3e4256", // slate indigo
  "#a8794a", // ochre
  "#3f7f80", // teal
];
export const BAND_COLORS = ["#3c4664", "#6b3630", "#33564a", "#5a4a2c", "#4a3a5e", "#25333f"];
