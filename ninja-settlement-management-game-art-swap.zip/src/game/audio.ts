// Tiny WebAudio synth — no assets, instant juice.

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let muted = false;
try {
  muted = typeof localStorage !== "undefined" && localStorage.getItem("sv-muted") === "1";
} catch {
  /* noop */
}

function ensure(): boolean {
  if (!ctx) {
    try {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      ctx = new AC();
      master = ctx.createGain();
      master.gain.value = muted ? 0 : 0.5;
      master.connect(ctx.destination);
    } catch {
      return false;
    }
  }
  if (ctx.state === "suspended") void ctx.resume();
  return true;
}

function tone(o: { f: number; f2?: number; t?: OscillatorType; d?: number; v?: number; at?: number }) {
  if (!ctx || !master || muted) return;
  try {
    const t0 = ctx.currentTime + (o.at ?? 0);
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    const d = o.d ?? 0.15;
    osc.type = o.t ?? "sine";
    osc.frequency.setValueAtTime(Math.max(1, o.f), t0);
    if (o.f2) osc.frequency.exponentialRampToValueAtTime(Math.max(1, o.f2), t0 + d);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(o.v ?? 0.3, t0 + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    osc.connect(g);
    g.connect(master);
    osc.start(t0);
    osc.stop(t0 + d + 0.05);
  } catch {
    /* noop */
  }
}

function noise(o: { d?: number; v?: number; f?: number; f2?: number; at?: number }) {
  if (!ctx || !master || muted) return;
  try {
    const d = o.d ?? 0.3;
    const t0 = ctx.currentTime + (o.at ?? 0);
    const len = Math.max(1, Math.floor(ctx.sampleRate * d));
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const ch = buf.getChannelData(0);
    for (let i = 0; i < len; i++) ch[i] = Math.random() * 2 - 1;
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const fl = ctx.createBiquadFilter();
    fl.type = "lowpass";
    fl.frequency.setValueAtTime(o.f ?? 1200, t0);
    if (o.f2) fl.frequency.exponentialRampToValueAtTime(Math.max(20, o.f2), t0 + d);
    const g = ctx.createGain();
    g.gain.setValueAtTime(o.v ?? 0.3, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    src.connect(fl);
    fl.connect(g);
    g.connect(master);
    src.start(t0);
  } catch {
    /* noop */
  }
}

export const audio = {
  unlock() {
    ensure();
  },
  isMuted() {
    return muted;
  },
  setMuted(m: boolean) {
    muted = m;
    try {
      localStorage.setItem("sv-muted", m ? "1" : "0");
    } catch {
      /* noop */
    }
    if (master) master.gain.value = m ? 0 : 0.5;
  },
  click() {
    tone({ f: 640, d: 0.05, v: 0.12, t: "triangle" });
  },
  dispatch() {
    noise({ d: 0.34, f: 500, f2: 4200, v: 0.28 });
    tone({ f: 280, f2: 900, d: 0.16, v: 0.1, t: "sine" });
  },
  coin() {
    tone({ f: 988, d: 0.08, v: 0.18, t: "triangle" });
    tone({ f: 1319, d: 0.13, v: 0.2, t: "triangle", at: 0.06 });
  },
  success() {
    tone({ f: 523, d: 0.1, v: 0.16, t: "triangle" });
    tone({ f: 659, d: 0.1, v: 0.16, t: "triangle", at: 0.07 });
    tone({ f: 784, d: 0.16, v: 0.18, t: "triangle", at: 0.14 });
  },
  fail() {
    noise({ d: 0.22, f: 380, v: 0.3 });
    tone({ f: 200, f2: 88, d: 0.32, v: 0.28, t: "sawtooth" });
  },
  build() {
    tone({ f: 130, f2: 55, d: 0.2, v: 0.5, t: "sine" });
    noise({ d: 0.09, f: 950, v: 0.22, at: 0.02 });
    tone({ f: 660, d: 0.07, v: 0.12, t: "triangle", at: 0.06 });
  },
  repair() {
    noise({ d: 0.1, f: 800, v: 0.2 });
    tone({ f: 220, d: 0.09, v: 0.2, t: "square", at: 0.05 });
  },
  raidHit() {
    tone({ f: 80, f2: 38, d: 0.55, v: 0.6, t: "sine" });
    noise({ d: 0.45, f: 260, v: 0.4 });
  },
  raidWin() {
    tone({ f: 98, f2: 60, d: 0.25, v: 0.5, t: "sine" });
    tone({ f: 659, d: 0.12, v: 0.16, t: "triangle", at: 0.12 });
    tone({ f: 784, d: 0.2, v: 0.18, t: "triangle", at: 0.22 });
  },
  level() {
    tone({ f: 784, d: 0.08, v: 0.16, t: "triangle" });
    tone({ f: 1047, d: 0.14, v: 0.16, t: "triangle", at: 0.08 });
  },
  recruit() {
    tone({ f: 440, d: 0.09, v: 0.16, t: "triangle" });
    tone({ f: 587, d: 0.13, v: 0.16, t: "triangle", at: 0.08 });
  },
  start() {
    tone({ f: 196, d: 1.1, v: 0.34, t: "sine" });
    tone({ f: 392, d: 0.7, v: 0.14, t: "sine", at: 0.05 });
    noise({ d: 0.7, f: 2600, f2: 500, v: 0.06 });
  },
  over() {
    tone({ f: 392, f2: 96, d: 0.9, v: 0.3, t: "sawtooth" });
    tone({ f: 65, f2: 35, d: 1.1, v: 0.5, t: "sine", at: 0.1 });
    noise({ d: 0.6, f: 320, v: 0.3, at: 0.05 });
  },
};
