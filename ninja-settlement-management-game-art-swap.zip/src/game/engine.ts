import type { Bld, Ev, GameState, Mission, NinRank, Ninja, Rank, Skill } from "./types";
import {
  AP_BASE, BAND_COLORS, BUILDINGS, CLANS, DOJO_CHANCE, DOJO_XP_DAY, EAT_PER_DAY,
  FARM_RICE, FATIGUE_PER_DAY_OUT, HAIR_COLORS, MISSION_CAP, MISSION_MIN_RANK,
  MISSION_TEMPLATES, NATURE_META, NINJA_NAMES, OUTFIT_COLORS, RANK_META, REPAIR_COST,
  REST_PER_DAY, SCOUT_COST, SHRINE_REST, SKILLS, SKILL_META, SKIN_TONES, SURNAMES, TEA_GOLD,
  THREAT_PER_DAY, TRAIT_IDS, TRAIT_META, nextRank, rankIndex,
} from "./content";
import type { Nature, ReportLine, ReportXp } from "./types";
import { startBattle } from "./battle";
import { LEGENDS, LEGEND_IDS, pendingPerks, perkById, perkFx } from "./perks";

const ri = (min: number, max: number) => min + Math.floor(Math.random() * (max - min + 1));
const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

export function xpNext(level: number): number {
  return 4 + level * 3;
}

export function capOf(s: GameState): number {
  return 4 + s.b.hall * 2;
}

export function apMax(s: GameState): number {
  return AP_BASE + (s.b.hall - 1);
}

/* ---------------- ninja math ---------------- */

export function fatigueMod(n: Ninja): number {
  return 1 - Math.min(0.32, (n.fatigue / 100) * 0.32);
}

export function effSkill(s: GameState, n: Ninja, k: Skill): number {
  return n.s[k] * fatigueMod(n) * (s.hungry ? 0.75 : 1);
}

export function overall(n: Ninja): number {
  let t = 0;
  for (const k of SKILLS) t += n.s[k];
  return t / SKILLS.length;
}

export function topSkills(n: Ninja, count = 2): Skill[] {
  return [...SKILLS].sort((a, b) => n.s[b] - n.s[a]).slice(0, count);
}

/** Scouted potential is uncertain and narrows as the ninja gains levels. */
export function potRange(n: Ninja): { lo: number; hi: number; known: boolean } {
  const spread = Math.max(0, 2 - Math.floor(n.level / 3));
  return {
    lo: clamp(n.pot - spread, 1, 5),
    hi: clamp(n.pot + spread, 1, 5),
    known: spread === 0,
  };
}

export function squadSkill(s: GameState, squad: Ninja[], k: Skill): number {
  if (squad.length === 0) return 0;
  const vals = squad.map((n) => effSkill(s, n, k)).sort((a, b) => b - a);
  let v = vals[0];
  for (let i = 1; i < vals.length; i++) v += vals[i] * 0.45;
  return v;
}

export function coverage(s: GameState, m: Mission, squad: Ninja[]) {
  return (Object.keys(m.req) as Skill[]).map((k) => {
    const need = m.req[k] ?? 0;
    const have = squadSkill(s, squad, k);
    return { k, have, need, cov: need > 0 ? have / need : 1 };
  });
}

/** does the cell contain someone of the rank this mission grade demands? */
export function meetsRank(m: Mission, squad: Ninja[]): boolean {
  const need = rankIndex(m.minRank);
  return squad.some((n) => rankIndex(n.rank) >= need);
}

export function squadChance(s: GameState, m: Mission, squad: Ninja[]): number {
  if (squad.length === 0) return 0;
  const cov = coverage(s, m, squad);
  let sum = 0;
  for (const c of cov) sum += Math.min(1.7, c.cov);
  const avg = sum / Math.max(1, cov.length);
  let ch = 0.34 + (avg - 0.6) * 0.78;
  const fill = squad.length / m.slots;
  if (fill < 1) ch -= (1 - fill) * 0.22;
  ch += s.b.dojo * DOJO_CHANCE;
  if (squad.some((n) => n.trait === "lucky")) ch += 0.08;
  for (const n of squad) ch += perkFx(n).missionBonus;
  if (!meetsRank(m, squad)) ch -= 0.3; // under-ranked cell is out of its depth
  return clamp(ch, 0.03, 0.97);
}

export function autoSquad(s: GameState, m: Mission): number[] {
  const free = s.ninjas.filter((n) => n.status === "ready");
  const chosen: Ninja[] = [];
  while (chosen.length < m.slots) {
    let best: Ninja | null = null;
    let bestCh = squadChance(s, m, chosen);
    for (const n of free) {
      if (chosen.includes(n)) continue;
      const ch = squadChance(s, m, [...chosen, n]);
      if (ch > bestCh + 0.001) {
        bestCh = ch;
        best = n;
      }
    }
    if (!best) break;
    chosen.push(best);
  }
  if (chosen.length === 0 && free.length > 0) {
    chosen.push([...free].sort((a, b) => overall(b) - overall(a))[0]);
  }
  return chosen.map((n) => n.id);
}

export function readyNinjas(s: GameState): Ninja[] {
  return s.ninjas.filter((n) => n.status === "ready");
}

export function streakMult(s: GameState): number {
  return 1 + Math.min(s.streak, 12) * 0.08;
}

/* ---------------- generation ---------------- */

export function makeNinja(s: GameState, elite = false, legendId?: string): Ninja {
  const used = new Set(s.ninjas.map((n) => n.name.split(" ")[0]));
  const pool = NINJA_NAMES.filter((n) => !used.has(n));
  const first = pool.length ? pick(pool) : pick(NINJA_NAMES);
  const nature = pick(Object.keys(NATURE_META)) as Nature;
  const trait = pick(TRAIT_IDS);
  const growth = {} as Record<Skill, number>;
  const sk = {} as Record<Skill, number>;
  const boosted = new Set<Skill>();
  if (TRAIT_META[trait].boost) boosted.add(TRAIT_META[trait].boost!);
  boosted.add(NATURE_META[nature].boost);
  const spec = new Set<Skill>([...boosted, pick(SKILLS)]);
  for (const k of SKILLS) {
    const isSpec = spec.has(k);
    growth[k] = (isSpec ? 1.25 : 0.8) + Math.random() * 0.35;
    sk[k] = Math.max(1, Math.round((isSpec ? 7 : 3) + Math.random() * 4 + (elite ? 3 : 0)));
  }
  const legend = legendId ? LEGENDS[legendId] : null;
  if (legend) {
    for (const k of SKILLS) {
      sk[k] += legend.bonus[k] ?? 0;
      if (legend.bonus[k]) growth[k] = Math.max(growth[k], 1.45);
    }
  }
  return {
    id: s.nextId++,
    name: `${first} ${pick(SURNAMES)}`,
    seed: Math.random(),
    look: {
      hair: ri(0, 7), hairColor: ri(0, HAIR_COLORS.length - 1), skin: ri(0, SKIN_TONES.length - 1),
      eyes: ri(0, 5), mark: ri(0, 4), outfit: ri(0, OUTFIT_COLORS.length - 1),
      band: ri(0, BAND_COLORS.length - 1), acc: ri(0, 3), build: ri(0, 2),
    },
    nature,
    trait,
    rank: "genin",
    level: 1,
    xp: 0,
    sp: 0,
    pot: ri(1, 5),
    s: sk,
    growth,
    fatigue: 0,
    status: "ready",
    daysLeft: 0,
    missionId: null,
    runs: 0,
    wins: 0,
    perks: [],
    legend: legendId ?? null,
    title: legend ? legend.title : null,
  };
}

const MISSION_SPEC: Record<Rank, { req: [number, number]; days: number; gold: [number, number]; rice: [number, number]; xp: number; score: number }> = {
  D: { req: [6, 9], days: 1, gold: [22, 34], rice: [0, 8], xp: 3, score: 12 },
  C: { req: [14, 20], days: 2, gold: [48, 70], rice: [10, 20], xp: 6, score: 32 },
  B: { req: [26, 36], days: 3, gold: [100, 145], rice: [16, 30], xp: 10, score: 70 },
  A: { req: [44, 58], days: 4, gold: [190, 265], rice: [26, 46], xp: 15, score: 140 },
  S: { req: [70, 92], days: 5, gold: [380, 520], rice: [50, 85], xp: 22, score: 300 },
};

function pickRank(day: number): Rank {
  const w: [Rank, number][] = [
    ["D", 100],
    ["C", 20 + day * 11],
    ["B", day > 3 ? 6 + day * 6 : 0],
    ["A", day > 6 ? (day - 6) * 8 : 0],
    ["S", day > 10 ? (day - 10) * 7 : 0],
  ];
  let tot = 0;
  for (const [, x] of w) tot += x;
  let r = Math.random() * tot;
  for (const [k, x] of w) {
    r -= x;
    if (r < 0) return k;
  }
  return "D";
}

export function genMission(s: GameState, forced?: Rank): Mission {
  const rank = forced ?? pickRank(s.day);
  const spec = MISSION_SPEC[rank];
  const t = pick(MISSION_TEMPLATES[rank]);
  const scale = 1 + (s.day - 1) * 0.03;
  const req: Partial<Record<Skill, number>> = {};
  t.focus.forEach((k, i) => {
    const base = ri(spec.req[0], spec.req[1]) * (i === 0 ? 1 : 0.75);
    req[k] = Math.max(3, Math.round(base * scale));
  });
  return {
    id: s.nextId++,
    rank,
    name: t.name,
    desc: t.desc,
    req,
    slots: t.slots,
    days: spec.days,
    totalDays: spec.days,
    gold: Math.round(ri(spec.gold[0], spec.gold[1]) * scale),
    rice: Math.round(ri(spec.rice[0], spec.rice[1]) * scale),
    xp: spec.xp,
    score: spec.score,
    expiresDay: s.day + ri(3, 5),
    minRank: MISSION_MIN_RANK[rank],
    squad: [],
  };
}

export function createState(phase: GameState["phase"] = "menu"): GameState {
  const s: GameState = {
    phase,
    day: 1,
    ap: AP_BASE,
    gold: 90,
    rice: 60,
    score: 0,
    streak: 0,
    hp: 5,
    hpMax: 5,
    threat: 10,
    hungry: false,
    ninjas: [],
    missions: [],
    b: { hall: 1, farm: 1, tea: 0, dojo: 0, tower: 0, shrine: 0 },
    nextId: 100,
    raids: 0,
    clan: pick(CLANS),
    stats: { done: 0, failed: 0, raids: 0, earned: 0, levels: 0, promos: 0 },
    battle: null,
    scout: null,
    log: [],
    reports: [],
  };
  s.ninjas.push(makeNinja(s, true), makeNinja(s), makeNinja(s));
  s.missions.push(genMission(s, "D"), genMission(s, "D"), genMission(s, "C"));
  return s;
}

let logId = 1;
export function pushLog(s: GameState, txt: string, kind = "info"): void {
  s.log.push({ txt, kind, id: logId++ });
  if (s.log.length > 40) s.log.shift();
}

/* ---------------- actions ---------------- */

export function togglePause(s: GameState): void {
  if (s.phase === "playing") s.phase = "paused";
  else if (s.phase === "paused") s.phase = "playing";
}

export function openMissions(s: GameState): Mission[] {
  return s.missions.filter((m) => m.squad.length === 0);
}

export function squadOf(s: GameState, m: Mission): Ninja[] {
  return m.squad.map((id) => s.ninjas.find((n) => n.id === id)).filter(Boolean) as Ninja[];
}

export function deploy(s: GameState, missionId: number, ninjaIds: number[], ev: Ev[]): boolean {
  const m = s.missions.find((x) => x.id === missionId);
  if (!m || m.squad.length > 0 || ninjaIds.length === 0) return false;
  const squad = ninjaIds
    .map((id) => s.ninjas.find((n) => n.id === id))
    .filter((n): n is Ninja => !!n && n.status === "ready");
  if (squad.length === 0) return false;
  // a fast cell can shave a day off long missions
  const speed = squadSkill(s, squad, "spd");
  let days = m.totalDays;
  if (days > 1 && speed > m.slots * 22) days -= 1;
  m.days = days;
  m.squad = squad.map((n) => n.id);
  for (const n of squad) {
    n.status = "mission";
    n.daysLeft = days;
    n.missionId = m.id;
  }
  ev.push({ type: "deploy", count: squad.length, mission: m.name, ids: m.squad, days });
  pushLog(s, `${squad.length}-man cell deployed: ${m.name} (${days}d)`, "info");
  return true;
}

export function build(s: GameState, type: Bld, ev: Ev[]): boolean {
  const meta = BUILDINGS[type];
  const lvl = s.b[type];
  if (lvl >= meta.max || s.ap < 1) return false;
  const cost = meta.costs[lvl];
  if (s.gold < cost.gold || s.rice < cost.rice) return false;
  s.gold -= cost.gold;
  s.rice -= cost.rice;
  s.b[type] = lvl + 1;
  s.ap -= 1;
  ev.push({ type: "build", bld: type, lvl: lvl + 1 });
  pushLog(s, `${meta.name} raised to level ${lvl + 1}`, "good");
  return true;
}

/** Spend an action to bring three hopefuls to the gate. */
export function scout(s: GameState, ev: Ev[]): boolean {
  if (s.scout) return true;
  if (s.ninjas.length >= capOf(s)) return false;
  if (s.ap < 1 || s.gold < SCOUT_COST.gold || s.rice < SCOUT_COST.rice) return false;
  s.gold -= SCOUT_COST.gold;
  s.rice -= SCOUT_COST.rice;
  s.ap -= 1;

  // a rare unique shinobi may be among the hopefuls — never one you already hold
  const owned = new Set(s.ninjas.map((n) => n.legend).filter(Boolean) as string[]);
  const available = LEGEND_IDS.filter((id) => !owned.has(id));
  const chance = Math.min(0.42, 0.1 + s.day * 0.012 + s.b.hall * 0.04);
  const legendId = available.length && Math.random() < chance ? pick(available) : null;
  const slot = Math.floor(Math.random() * 3);

  s.scout = [0, 1, 2].map((i) => makeNinja(s, false, legendId && i === slot ? legendId : undefined));
  if (legendId) ev.push({ type: "legend_found", legend: legendId });
  ev.push({ type: "scout" });
  return true;
}

/** Choose one node from this ninja's personal tech tree. */
export function choosePerk(s: GameState, ninjaId: number, perkId: string, ev: Ev[]): boolean {
  const n = s.ninjas.find((x) => x.id === ninjaId);
  if (!n || pendingPerks(n) <= 0) return false;
  if (n.perks.includes(perkId)) return false;
  const p = perkById(perkId);
  if (!p) return false;
  n.perks.push(perkId);
  ev.push({ type: "perk", name: n.name, perk: p.name, kanji: p.kanji, signature: p.kind === "signature" });
  pushLog(s, `${n.name} mastered ${p.name}`, "great");
  return true;
}

export function pickScout(s: GameState, id: number, ev: Ev[]): boolean {
  if (!s.scout) return false;
  const n = s.scout.find((x) => x.id === id);
  if (!n) return false;
  s.ninjas.push(n);
  s.scout = null;
  ev.push({ type: "recruit", name: n.name });
  pushLog(s, `${n.name} joins the village`, "good");
  return true;
}

export function dismissScout(s: GameState): void {
  s.scout = null;
}

export function repair(s: GameState, ev: Ev[]): boolean {
  if (s.hp >= s.hpMax || s.ap < 1) return false;
  if (s.gold < REPAIR_COST.gold || s.rice < REPAIR_COST.rice) return false;
  s.gold -= REPAIR_COST.gold;
  s.rice -= REPAIR_COST.rice;
  s.ap -= 1;
  s.hp += 1;
  ev.push({ type: "repair" });
  pushLog(s, "Village walls repaired", "good");
  return true;
}

export function trainSkill(s: GameState, ninjaId: number, k: Skill, ev: Ev[]): boolean {
  const n = s.ninjas.find((x) => x.id === ninjaId);
  if (!n || n.sp <= 0) return false;
  n.sp--;
  const gain = Math.max(1, Math.round(1 + n.growth[k] * 1.4));
  n.s[k] += gain;
  ev.push({ type: "trained", name: n.name, skill: k, gain });
  return true;
}

/* ---------------- promotion ---------------- */

export interface PromoInfo {
  next: NinRank | null;
  okLevel: boolean;
  okMissions: boolean;
  okGold: boolean;
  okAp: boolean;
  ready: boolean;
  need: { level: number; missions: number; gold: number } | null;
}

export function promoInfo(s: GameState, n: Ninja): PromoInfo {
  const next = nextRank(n.rank);
  if (!next) return { next: null, okLevel: false, okMissions: false, okGold: false, okAp: false, ready: false, need: null };
  const req = RANK_META[next];
  // only one Kage may hold office
  const kageTaken = next === "kage" && s.ninjas.some((o) => o.rank === "kage");
  const okLevel = n.level >= req.level;
  const okMissions = n.wins >= req.missions;
  const okGold = s.gold >= req.gold;
  const okAp = s.ap >= 1;
  return {
    next,
    okLevel,
    okMissions,
    okGold,
    okAp,
    ready: okLevel && okMissions && okGold && okAp && !kageTaken && n.status === "ready",
    need: { level: req.level, missions: req.missions, gold: req.gold },
  };
}

export function promote(s: GameState, ninjaId: number, ev: Ev[]): boolean {
  const n = s.ninjas.find((x) => x.id === ninjaId);
  if (!n) return false;
  const info = promoInfo(s, n);
  if (!info.ready || !info.next) return false;
  const req = RANK_META[info.next];
  s.gold -= req.gold;
  s.ap -= 1;
  n.rank = info.next;
  n.sp += 2;
  // the exam sharpens everything, best skills most of all
  for (const k of SKILLS) n.s[k] += Math.max(1, Math.round(req.boost * (n.growth[k] / 1.4)));
  s.stats.promos++;
  s.score += 60 * (rankIndex(info.next) + 1);
  ev.push({ type: "promoted", name: n.name, rank: info.next, kanji: req.kanji });
  pushLog(s, `${n.name} promoted to ${req.name}!`, "great");
  return true;
}

/* ---------------- day advance ---------------- */

function gainXp(s: GameState, n: Ninja, amount: number, ev: Ev[]): void {
  const mult = n.trait === "prodigy" ? 1.4 : 1;
  n.xp += amount * mult;
  while (n.xp >= xpNext(n.level)) {
    n.xp -= xpNext(n.level);
    n.level++;
    // potential decides how much a level is worth: 1..3 skill points
    let sp = 1;
    if (Math.random() < (n.pot - 1) / 4.5) sp++;
    if (n.pot === 5 && Math.random() < 0.3) sp++;
    n.sp += sp;
    s.stats.levels++;
    for (const k of SKILLS) if (Math.random() < n.growth[k] * 0.4) n.s[k] += 1;
    ev.push({ type: "ninja_level", name: n.name, level: n.level, sp, id: n.id });
    pushLog(s, `${n.name} reached level ${n.level} (+${sp} SP)`, "good");
  }
}

/* ---------------- field reports ---------------- */

const OPENERS = [
  "The cell slipped out before the gate torches were lit.",
  "They left under a thin rain, hoods up, saying nothing.",
  "Dawn mist swallowed them a hundred paces from the wall.",
  "The contract seal was still warm when they moved out.",
  "They took the old smugglers' path to save half a day.",
];

const SKILL_BEAT: Record<Skill, string[]> = {
  nin: ["wove hand seals faster than the enemy could read them", "collapsed the approach with a single earth jutsu", "turned the river against the guard post"],
  tai: ["broke the line with bare hands", "took three of them down before the fourth drew steel", "held the doorway alone while the others worked"],
  gen: ["laid an illusion so gentle the sentries thanked them for it", "made the courtyard look empty for nine long seconds", "unpicked a trap woven into the lanternlight"],
  ste: ["crossed the open ground without disturbing the dust", "spent an hour under the floorboards, breathing slow", "left no print, no thread, no scent"],
  med: ["closed a bleeding wound mid-run", "brewed the antidote from what grew by the roadside", "kept the wounded one walking on chakra alone"],
  spd: ["was over the wall before the alarm finished its first note", "outran the pursuit for six li without slowing", "struck and was gone between two heartbeats"],
};

const WIN_CLOSERS = [
  "They were back before the third watch, mud to the knee and grinning.",
  "The client paid without haggling. That never happens.",
  "No alarm was ever raised. As far as the enemy knows, nothing occurred.",
  "The village gate opened for them at dawn. All accounted for.",
];

const LOSS_CLOSERS = [
  "They came back over the wall carrying one another.",
  "The contract is forfeit. The cell is alive — that is the whole of the good news.",
  "Someone was waiting for them. That question is for another day.",
  "They limped in at moonset and would not speak of it.",
];

function reportFor(s: GameState, m: Mission, squad: Ninja[], win: boolean, ch: number, cov: ReturnType<typeof coverage>): ReportLine[] {
  const lines: ReportLine[] = [];
  lines.push({ txt: pick(OPENERS), kind: "flavour" });

  const strongest = [...cov].sort((a, z) => z.cov - a.cov)[0];
  const weakest = [...cov].sort((a, z) => a.cov - z.cov)[0];

  if (strongest) {
    const hero = [...squad].sort((a, b) => effSkill(s, b, strongest.k) - effSkill(s, a, strongest.k))[0];
    if (hero) {
      lines.push({
        txt: `${hero.name.split(" ")[0]} ${pick(SKILL_BEAT[strongest.k])} — ${SKILL_META[strongest.k].name} ${Math.round(strongest.have)} against ${strongest.need} needed.`,
        kind: "clutch",
      });
    }
  }

  if (weakest && weakest.cov < 0.85) {
    lines.push({
      txt: `${SKILL_META[weakest.k].name} fell short (${Math.round(weakest.have)}/${weakest.need}) and the cell paid for it in time and blood.`,
      kind: "bad",
    });
  } else if (squad.length > 1) {
    lines.push({ txt: `The cell worked clean — no one had to cover for anyone.`, kind: "good" });
  }

  if (!meetsRank(m, squad)) {
    lines.push({ txt: `No ${RANK_META[m.minRank].name} led the cell. They were out of their depth from the first hour.`, kind: "bad" });
  }

  const tired = squad.find((n) => n.fatigue > 60);
  if (tired) lines.push({ txt: `${tired.name.split(" ")[0]} was running on fumes before they even set out.`, kind: "bad" });

  if (s.hungry) lines.push({ txt: "They marched hungry. The storehouse is empty and it shows.", kind: "bad" });

  const medic = squad.find((n) => n.trait === "medicnin" || n.perks.includes("fieldmedic"));
  if (medic && !win) lines.push({ txt: `${medic.name.split(" ")[0]} kept everyone breathing on the way home.`, kind: "good" });

  const legend = squad.find((n) => n.legend);
  if (legend && win) {
    lines.push({ txt: `${legend.name.split(" ")[0]} ${LEGENDS[legend.legend!].epithet} barely had to try.`, kind: "clutch" });
  }

  lines.push({ txt: `Odds were read at ${Math.round(ch * 100)}%.`, kind: "beat" });
  lines.push({ txt: pick(win ? WIN_CLOSERS : LOSS_CLOSERS), kind: "flavour" });
  return lines;
}

let reportId = 1;

function resolveMission(s: GameState, m: Mission, ev: Ev[]): void {
  const idx = s.missions.indexOf(m);
  if (idx >= 0) s.missions.splice(idx, 1);
  const squad = squadOf(s, m);
  const cov = coverage(s, m, squad);
  const ch = squadChance(s, m, squad);
  const win = Math.random() < ch;
  const usedSkills = Object.keys(m.req) as Skill[];
  const xpRows: ReportXp[] = [];

  for (const n of squad) {
    const fx = perkFx(n);
    const before = { level: n.level, sp: n.sp };
    const skillUps: { k: Skill; n: number }[] = [];
    n.missionId = null;
    n.runs++;
    for (const k of usedSkills) {
      if (Math.random() < (win ? 0.55 : 0.3) * n.growth[k]) {
        n.s[k] += 1;
        skillUps.push({ k, n: 1 });
      }
    }
    const xpGain = (win ? m.xp : m.xp * 0.45) * fx.xp;
    gainXp(s, n, xpGain, ev);
    if (win) {
      n.wins++;
      n.status = "ready";
      n.daysLeft = 0;
    } else {
      n.status = "injured";
      let d = 1 + Math.floor(m.totalDays * 0.7);
      if (n.trait === "stoic") d = Math.max(1, d - 1);
      if (squad.some((o) => o.id !== n.id && (o.trait === "medicnin" || o.perks.includes("fieldmedic")))) d -= 1;
      n.daysLeft = Math.max(1, d - Math.floor(s.b.shrine / 2));
    }
    xpRows.push({
      id: n.id,
      name: n.name,
      xp: Math.round(xpGain * 10) / 10,
      levels: n.level - before.level,
      sp: n.sp - before.sp,
      skillUps,
      injured: n.status === "injured",
      perkReady: pendingPerks(n) > 0,
    });
  }

  const pts = win ? Math.round(m.score * streakMult(s)) : 0;
  if (win) {
    s.streak++;
    s.gold += m.gold;
    s.rice += m.rice;
    s.score += pts;
    s.stats.done++;
    s.stats.earned += m.gold;
    ev.push({ type: "mission_success", rank: m.rank, name: m.name, gold: m.gold, rice: m.rice, pts, count: squad.length });
    pushLog(s, `Success — ${m.name} (+${m.gold}両)`, "great");
  } else {
    s.streak = 0;
    s.stats.failed++;
    ev.push({ type: "mission_fail", rank: m.rank, name: m.name, count: squad.length });
    pushLog(s, `Failed — ${m.name}. The cell limps home.`, "bad");
  }

  s.reports.push({
    id: reportId++,
    day: s.day,
    mission: m.name,
    rank: m.rank,
    win,
    chance: ch,
    gold: win ? m.gold : 0,
    rice: win ? m.rice : 0,
    pts,
    lines: reportFor(s, m, squad, win, ch, cov),
    xp: xpRows,
  });
}

/**
 * Advance one full day. Returns true when a raid battle has begun
 * (the caller must hand control to the battle screen).
 */
export function advanceDay(s: GameState, ev: Ev[]): boolean {
  s.day++;
  ev.push({ type: "day", day: s.day });

  // 1. missions in progress
  for (const m of [...s.missions]) {
    if (m.squad.length === 0) continue;
    m.days -= 1;
    for (const n of squadOf(s, m)) n.daysLeft = m.days;
    if (m.days <= 0) resolveMission(s, m, ev);
  }

  // 2. expiring contracts
  for (let i = s.missions.length - 1; i >= 0; i--) {
    const m = s.missions[i];
    if (m.squad.length === 0 && s.day > m.expiresDay) {
      s.missions.splice(i, 1);
      ev.push({ type: "expire", name: m.name });
    }
  }

  // 3. new contracts on the board
  const want = ri(1, 2);
  for (let i = 0; i < want; i++) {
    if (openMissions(s).length >= MISSION_CAP) break;
    s.missions.push(genMission(s));
  }

  // 4. economy
  s.gold += TEA_GOLD * s.b.tea;
  s.rice += FARM_RICE * s.b.farm;
  s.rice -= EAT_PER_DAY * s.ninjas.length;
  if (s.rice <= 0) {
    s.rice = 0;
    if (!s.hungry) {
      ev.push({ type: "hungry", on: 1 });
      pushLog(s, "The storehouse is empty — everyone fights hungry", "bad");
    }
    s.hungry = true;
  } else if (s.hungry) {
    s.hungry = false;
    ev.push({ type: "hungry", on: 0 });
  }

  // 5. rest, healing, dōjō training
  const rest = REST_PER_DAY + s.b.shrine * SHRINE_REST;
  for (const n of s.ninjas) {
    if (n.status === "mission") {
      n.fatigue = Math.min(100, n.fatigue + FATIGUE_PER_DAY_OUT * (n.trait === "ironwill" ? 0.6 : 1) * perkFx(n).fatigue);
    } else {
      n.fatigue = Math.max(0, n.fatigue - rest);
      if (n.status === "injured") {
        n.daysLeft -= 1;
        if (n.daysLeft <= 0) {
          n.status = "ready";
          n.daysLeft = 0;
          ev.push({ type: "healed", name: n.name });
          pushLog(s, `${n.name} has recovered`, "good");
        }
      }
      if (n.status === "ready" && s.b.dojo > 0) gainXp(s, n, DOJO_XP_DAY * s.b.dojo, ev);
    }
  }

  // 6. action points refresh
  s.ap = apMax(s);

  // 7. threat & raids
  s.threat += THREAT_PER_DAY * (1 + s.raids * 0.05);
  if (s.threat >= 100) {
    s.threat = 0;
    s.clan = pick(CLANS);
    const defenders = readyNinjas(s);
    if (defenders.length === 0) {
      // nobody home — the village eats the hit
      s.hp = Math.max(0, s.hp - 2);
      ev.push({ type: "raid_undefended", clan: s.clan });
      pushLog(s, `${s.clan} struck an undefended village! −2 ♥`, "bad");
      if (s.hp <= 0) {
        s.phase = "over";
        ev.push({ type: "gameover" });
      }
      return false;
    }
    s.battle = startBattle(s, defenders);
    s.phase = "battle";
    ev.push({ type: "raid_start", clan: s.clan });
    pushLog(s, `${s.clan} attacks the village!`, "bad");
    return true;
  }
  return false;
}
