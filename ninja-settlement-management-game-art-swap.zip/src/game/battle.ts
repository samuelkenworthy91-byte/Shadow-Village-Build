import type { BAction, Battle, GameState, Ninja, Unit } from "./types";
import { ENEMY_KINDS, NATURE_META, RANK_META, SKILLS, rankIndex } from "./content";
import { perkById, perkFx } from "./perks";

const rnd = (a: number, b: number) => a + Math.random() * (b - a);
const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

/* ================= stat derivation =================
 * Skills drive combat hard and legibly:
 *   TAI → attack power + HP + defence
 *   NIN → jutsu damage + chakra pool
 *   GEN → genjutsu potency + resistance
 *   STE → critical damage + ambush
 *   MED → healing strength
 *   SPD → turn order + crit chance + dodge
 */

export function unitFromNinja(n: Ninja): Unit {
  const fx = perkFx(n);
  const rb = rankIndex(n.rank);
  const hp = Math.round((46 + n.s.tai * 3.1 + n.level * 5 + rb * 12) * fx.hp);
  const cp = Math.round((14 + n.s.nin * 1.5 + n.s.gen * 0.8) * fx.cp);
  return {
    uid: `p${n.id}`,
    name: n.name.split(" ")[0],
    foe: false,
    ninjaId: n.id,
    kind: "ally",
    maxHp: hp,
    hp,
    maxCp: cp,
    cp,
    atk: (n.s.tai * 1.45 + n.s.nin * 0.3 + rb * 2) * fx.atk,
    def: (5 + n.s.tai * 0.55 + rb * 2.5) * fx.def,
    spd: n.s.spd * 1.4 + n.level,
    nin: n.s.nin,
    gen: n.s.gen,
    med: n.s.med,
    guard: false,
    stun: 0,
    alive: true,
    look: n.look,
    nature: n.nature,
    level: n.level,
    rank: n.rank,
    crit: clamp(0.05 + n.s.spd * 0.006 + fx.crit, 0, 0.7),
    critMult: 1.8 + n.s.ste * 0.022 + fx.critMult,
    dodge: clamp(n.s.spd * 0.0035 + fx.dodge, 0, 0.45),
    lifesteal: fx.lifesteal,
    counter: fx.counter,
    regen: fx.regen,
    firstStrike: fx.firstStrike,
    special: fx.special ? fx.special.id : null,
    perks: n.perks,
    legend: n.legend,
  };
}

function makeEnemy(i: number, kind: string, power: number): Unit {
  const k = ENEMY_KINDS[kind];
  const hp = Math.round((34 + power * 4.2) * k.hp);
  return {
    uid: `e${i}`,
    name: k.name,
    foe: true,
    ninjaId: null,
    kind,
    maxHp: hp,
    hp,
    maxCp: 22,
    cp: 22,
    atk: (7 + power * 1.15) * k.atk,
    def: 4 + power * 0.5,
    spd: (9 + power * 0.6) * k.spd,
    nin: 6 + power * 0.7,
    gen: 5 + power * 0.6,
    med: 0,
    guard: false,
    stun: 0,
    alive: true,
    look: null,
    nature: null,
    level: Math.max(1, Math.round(power / 3)),
    rank: null,
    crit: 0.1,
    critMult: 1.7,
    dodge: kind === "shadow" ? 0.15 : 0.04,
    lifesteal: 0,
    counter: 0,
    regen: 0,
    firstStrike: false,
    special: null,
    perks: [],
    legend: null,
  };
}

export function startBattle(s: GameState, defenders: Ninja[]): Battle {
  const power = 6 + (s.day - 1) * 1.6 + s.raids * 3.2;
  const allies = defenders.slice(0, 4).map(unitFromNinja);
  // Will of Fire style team auras
  let teamAtk = 1;
  for (const n of defenders) teamAtk *= perkFx(n).allyAtk;
  if (teamAtk !== 1) for (const a of allies) a.atk *= teamAtk;

  const count = Math.min(4, 1 + Math.floor(s.day / 4) + (s.raids > 2 ? 1 : 0));
  const kinds: string[] = [];
  for (let i = 0; i < count; i++) {
    kinds.push(i === count - 1 && s.raids >= 1 && count > 1 ? "boss" : pick(["grunt", "brute", "shadow"]));
  }
  const foes = kinds.map((k, i) => makeEnemy(i, k, power));
  foes.forEach((f, i) => {
    if (kinds.filter((k) => k === f.kind).length > 1) f.name = `${f.name} ${String.fromCharCode(65 + i)}`;
  });

  const b: Battle = {
    round: 1,
    units: [...allies, ...foes],
    order: [],
    idx: 0,
    state: "choose",
    log: [{ t: `${s.clan} storms the gates!`, kind: "info" }],
    clan: s.clan,
    gold: Math.round(45 + power * 10),
    score: Math.round(90 + power * 13),
    flash: null,
    acting: null,
  };
  rollOrder(b, s.b.tower, true);
  return b;
}

/* ---------------- turn order ---------------- */

function rollOrder(b: Battle, towerLvl = 0, first = false): void {
  const live = b.units.filter((u) => u.alive);
  b.order = live
    .map((u) => ({
      uid: u.uid,
      roll: u.spd * rnd(0.85, 1.15) + (u.foe ? 0 : towerLvl * 4) + (first && u.firstStrike ? 500 : u.firstStrike ? 12 : 0),
    }))
    .sort((a, z) => z.roll - a.roll)
    .map((x) => x.uid);
  b.idx = 0;
}

export function unitById(b: Battle, uid: string): Unit | undefined {
  return b.units.find((u) => u.uid === uid);
}

export function currentUnit(b: Battle): Unit | null {
  const uid = b.order[b.idx];
  const u = uid ? unitById(b, uid) : undefined;
  return u && u.alive ? u : null;
}

export const aliveFoes = (b: Battle) => b.units.filter((u) => u.foe && u.alive);
export const aliveAllies = (b: Battle) => b.units.filter((u) => !u.foe && u.alive);

function log(b: Battle, t: string, kind: Battle["log"][number]["kind"] = "info"): void {
  b.log.push({ t, kind });
  if (b.log.length > 40) b.log.shift();
}

/* ---------------- costs ---------------- */

export const COSTS: Record<BAction, number> = { attack: 0, jutsu: 8, genjutsu: 7, heal: 7, guard: 0, special: 14 };

export function canUse(u: Unit, a: BAction): boolean {
  if (u.cp < COSTS[a]) return false;
  if (a === "heal" && u.med < 4) return false;
  if (a === "genjutsu" && u.gen < 4) return false;
  if (a === "special" && !u.special) return false;
  return true;
}

export function actionLabel(u: Unit, a: BAction): string {
  switch (a) {
    case "attack": return "Strike";
    case "jutsu": return u.nature ? NATURE_META[u.nature].jutsu : "Jutsu";
    case "genjutsu": return "Genjutsu";
    case "heal": return "Mystic Palm";
    case "guard": return "Guard";
    case "special": {
      const p = u.special ? perkById(u.special) : null;
      return p?.tech?.name ?? "Ōgi";
    }
  }
}

/* ---------------- damage ---------------- */

function tryDodge(t: Unit): boolean {
  return Math.random() < t.dodge;
}

function damage(b: Battle, src: Unit | null, target: Unit, raw: number, kind: "hit" | "crit", pierce = false): number {
  let dmg = Math.max(1, Math.round(raw));
  if (target.guard && !pierce) dmg = Math.max(1, Math.round(dmg * 0.42));
  target.hp = Math.max(0, target.hp - dmg);
  b.flash = { uid: target.uid, amount: dmg, kind, n: (b.flash?.n ?? 0) + 1 };
  if (src && src.lifesteal > 0) {
    const heal = Math.round(dmg * src.lifesteal);
    if (heal > 0) {
      src.hp = Math.min(src.maxHp, src.hp + heal);
      log(b, `${src.name} drains ${heal} life`, "heal");
    }
  }
  if (target.hp <= 0) {
    target.alive = false;
    log(b, `${target.name} is down!`, "down");
  }
  return dmg;
}

function counterHit(b: Battle, attacker: Unit, defender: Unit, dealt: number): void {
  if (!defender.alive || defender.counter <= 0 || !attacker.alive) return;
  const back = Math.round(dealt * defender.counter);
  if (back <= 0) return;
  attacker.hp = Math.max(0, attacker.hp - back);
  log(b, `${defender.name} counters for ${back}!`, "crit");
  if (attacker.hp <= 0) {
    attacker.alive = false;
    log(b, `${attacker.name} is down!`, "down");
  }
}

export function doAction(b: Battle, action: BAction, targetUid?: string): { kind: string; targets: string[] } {
  const u = currentUnit(b);
  if (!u) return { kind: "none", targets: [] };
  u.guard = false;
  const foesSide = u.foe ? aliveAllies(b) : aliveFoes(b);
  const alliesSide = u.foe ? aliveFoes(b) : aliveAllies(b);
  let target = targetUid ? unitById(b, targetUid) : undefined;
  if (!target || !target.alive) target = undefined;

  switch (action) {
    case "attack": {
      const t = target && target.foe !== u.foe ? target : foesSide[0];
      if (!t) break;
      if (tryDodge(t)) {
        log(b, `${t.name} slips past ${u.name}'s strike`, "miss");
        return { kind: "miss", targets: [t.uid] };
      }
      const crit = Math.random() < u.crit;
      const raw = (u.atk * rnd(0.88, 1.14) - t.def * 0.45) * (crit ? u.critMult : 1);
      const d = damage(b, u, t, raw, crit ? "crit" : "hit");
      log(b, `${u.name} strikes ${t.name} for ${d}${crit ? " — CRITICAL!" : ""}`, crit ? "crit" : "hit");
      counterHit(b, u, t, d);
      return { kind: crit ? "crit" : "attack", targets: [t.uid] };
    }

    case "jutsu": {
      const t = target && target.foe !== u.foe ? target : foesSide[0];
      if (!t) break;
      u.cp -= COSTS.jutsu;
      const mastery = u.perks.includes("elemental") ? 1.4 : 1;
      const raw = (u.nin * 1.65 * mastery) * rnd(0.9, 1.18) - t.def * 0.18;
      const d = damage(b, u, t, raw, "hit");
      const other = foesSide.find((x) => x.uid !== t.uid);
      let splash = 0;
      if (other) splash = damage(b, u, other, raw * 0.4, "hit");
      const name = u.nature ? NATURE_META[u.nature].jutsu : "Chakra Blast";
      log(b, `${u.name} unleashes ${name} — ${d}${splash ? ` (+${splash} splash)` : ""}`, "hit");
      return { kind: "jutsu", targets: other ? [t.uid, other.uid] : [t.uid] };
    }

    case "genjutsu": {
      const t = target && target.foe !== u.foe ? target : foesSide[0];
      if (!t) break;
      u.cp -= COSTS.genjutsu;
      const sure = u.perks.includes("minddagger");
      if (sure || u.gen * rnd(0.85, 1.25) > t.gen * 0.8) {
        t.stun = sure ? 2 : 1;
        const d = damage(b, u, t, u.gen * 0.55, "hit");
        log(b, `${u.name} binds ${t.name} in an illusion — stunned! (${d})`, "hit");
        return { kind: "genjutsu", targets: [t.uid] };
      }
      log(b, `${t.name} shatters ${u.name}'s illusion`, "miss");
      return { kind: "miss", targets: [t.uid] };
    }

    case "heal": {
      u.cp -= COSTS.heal;
      const boost = u.perks.includes("fieldmedic") ? 1.4 : 1;
      const hurt = [...alliesSide].sort((a, z) => a.hp / a.maxHp - z.hp / z.maxHp)[0];
      const t = target && target.foe === u.foe && target.alive ? target : hurt;
      if (!t) break;
      const amt = Math.round(u.med * 2.1 * boost * rnd(0.92, 1.12));
      t.hp = Math.min(t.maxHp, t.hp + amt);
      b.flash = { uid: t.uid, amount: amt, kind: "heal", n: (b.flash?.n ?? 0) + 1 };
      log(b, `${u.name} mends ${t.name} for ${amt}`, "heal");
      return { kind: "heal", targets: [t.uid] };
    }

    case "special": {
      const p = u.special ? perkById(u.special) : null;
      if (!p?.tech) break;
      u.cp -= COSTS.special;
      const tech = p.tech;
      const statVal = tech.stat === "tai" ? u.atk / 1.45 : tech.stat === "nin" ? u.nin : tech.stat === "gen" ? u.gen : tech.stat === "med" ? u.med : tech.stat === "spd" ? u.spd / 1.4 : u.atk / 1.6;

      // revival / mass heal
      if (p.id === "mysticrevive") {
        const downed = b.units.find((x) => x.foe === u.foe && !x.alive);
        if (downed) {
          downed.alive = true;
          downed.hp = Math.round(downed.maxHp * 0.6);
          b.flash = { uid: downed.uid, amount: downed.hp, kind: "heal", n: (b.flash?.n ?? 0) + 1 };
          log(b, `${u.name} performs Mystic Revival — ${downed.name} rises!`, "heal");
          return { kind: "heal", targets: [downed.uid] };
        }
        for (const a of alliesSide) {
          const amt = Math.round(statVal * 1.5);
          a.hp = Math.min(a.maxHp, a.hp + amt);
        }
        b.flash = { uid: u.uid, amount: Math.round(statVal * 1.5), kind: "heal", n: (b.flash?.n ?? 0) + 1 };
        log(b, `${u.name} floods the cell with healing chakra`, "heal");
        return { kind: "heal", targets: alliesSide.map((a) => a.uid) };
      }

      // all-target techniques
      if (p.id === "shadowclone" || p.id === "lg_summon") {
        let total = 0;
        for (const t of [...foesSide]) total += damage(b, u, t, statVal * tech.power * rnd(0.92, 1.1), "crit");
        if (p.id === "lg_summon") {
          for (const a of alliesSide) a.hp = Math.min(a.maxHp, a.hp + Math.round(u.med * 1.2 + 6));
        }
        log(b, `奥義 ${tech.name}! ${total} damage across the field`, "crit");
        return { kind: "ogi", targets: foesSide.map((f) => f.uid) };
      }

      const t = target && target.foe !== u.foe
        ? target
        : p.id === "assassinate"
          ? [...foesSide].sort((a, z) => a.hp - z.hp)[0]
          : foesSide[0];
      if (!t) break;

      // low-HP scaling for the jinchūriki
      let power = tech.power;
      if (p.id === "lg_beastcloak") power *= 1 + (1 - u.hp / u.maxHp) * 1.1;
      const pierce = p.id === "gatekeeper" || p.id === "lg_silentmist";
      let total = 0;
      for (let i = 0; i < tech.hits; i++) {
        if (!t.alive) break;
        total += damage(b, u, t, statVal * power * rnd(0.94, 1.12), "crit", pierce);
      }
      if (p.id === "nightmare") t.stun = 2;
      log(b, `奥義 ${tech.name}! ${t.name} takes ${total}${tech.hits > 1 ? ` over ${tech.hits} hits` : ""}`, "crit");
      return { kind: "ogi", targets: [t.uid] };
    }

    case "guard": {
      u.guard = true;
      u.cp = Math.min(u.maxCp, u.cp + 7);
      log(b, `${u.name} takes a defensive stance`, "info");
      return { kind: "guard", targets: [u.uid] };
    }
  }
  return { kind: "none", targets: [] };
}

/* ---------------- AI ---------------- */

export function enemyAction(b: Battle): { action: BAction; target?: string } {
  const u = currentUnit(b);
  if (!u) return { action: "guard" };
  const targets = aliveAllies(b);
  if (targets.length === 0) return { action: "guard" };
  const weakest = [...targets].sort((a, z) => a.hp - z.hp)[0];
  const strongest = [...targets].sort((a, z) => z.atk - a.atk)[0];
  const t = weakest.hp < weakest.maxHp * 0.35 ? weakest : Math.random() < 0.6 ? strongest : pick(targets);
  if (u.cp >= COSTS.jutsu && Math.random() < 0.42) return { action: "jutsu", target: t.uid };
  if (u.cp >= COSTS.genjutsu && u.kind === "shadow" && Math.random() < 0.3) return { action: "genjutsu", target: t.uid };
  if (u.hp < u.maxHp * 0.2 && Math.random() < 0.25) return { action: "guard" };
  return { action: "attack", target: t.uid };
}

export function autoPickAction(b: Battle): { action: BAction; target?: string } {
  const u = currentUnit(b);
  if (!u) return { action: "guard" };
  const allies = aliveAllies(b);
  const foes = aliveFoes(b);
  const weak = [...foes].sort((a, z) => a.hp - z.hp)[0];
  const downed = b.units.find((x) => !x.foe && !x.alive);
  if (u.special && canUse(u, "special") && (foes.length > 1 || (weak && weak.hp > u.atk) || downed)) {
    return { action: "special", target: weak?.uid };
  }
  const hurt = allies.find((a) => a.hp < a.maxHp * 0.45);
  if (hurt && u.med >= 6 && canUse(u, "heal")) return { action: "heal", target: hurt.uid };
  if (canUse(u, "jutsu") && u.nin >= 9) return { action: "jutsu", target: weak?.uid };
  return { action: "attack", target: weak?.uid };
}

/* ---------------- turn cycle ---------------- */

export function nextTurn(b: Battle, towerLvl = 0): void {
  if (aliveFoes(b).length === 0) {
    b.state = "won";
    return;
  }
  if (aliveAllies(b).length === 0) {
    b.state = "lost";
    return;
  }
  for (let guard = 0; guard < 64; guard++) {
    b.idx++;
    if (b.idx >= b.order.length) {
      b.round++;
      for (const u of b.units) {
        if (!u.alive) continue;
        u.cp = Math.min(u.maxCp, u.cp + 3 + u.regen);
        if (u.regen > 0) u.hp = Math.min(u.maxHp, u.hp + u.regen);
        if (u.stun > 0) u.stun--;
      }
      rollOrder(b, towerLvl);
      log(b, `— Round ${b.round} —`, "info");
    }
    const u = currentUnit(b);
    if (!u) continue;
    if (u.stun > 0) {
      log(b, `${u.name} is trapped in the illusion`, "miss");
      continue;
    }
    b.state = "choose";
    return;
  }
  b.state = "choose";
}

/* ---------------- conclusion ---------------- */

export function finishBattle(s: GameState, ev: { type: string; [k: string]: unknown }[]): void {
  const b = s.battle;
  if (!b) return;
  const won = b.state === "won";

  for (const u of b.units) {
    if (u.foe || u.ninjaId == null) continue;
    const n = s.ninjas.find((x) => x.id === u.ninjaId);
    if (!n) continue;
    const fx = perkFx(n);
    n.fatigue = Math.min(100, n.fatigue + 26 * fx.fatigue);
    const gained = (won ? 7 : 3) * fx.xp * (n.trait === "prodigy" ? 1.4 : 1);
    n.xp += gained;
    while (n.xp >= 4 + n.level * 3) {
      n.xp -= 4 + n.level * 3;
      n.level++;
      let sp = 1;
      if (Math.random() < (n.pot - 1) / 4.5) sp++;
      n.sp += sp;
      s.stats.levels++;
      for (const k of SKILLS) if (Math.random() < n.growth[k] * 0.4) n.s[k] += 1;
      ev.push({ type: "ninja_level", name: n.name, level: n.level, sp, id: n.id });
    }
    if (!u.alive) {
      n.status = "injured";
      n.daysLeft = Math.max(1, 2 - Math.floor(s.b.shrine / 2) - (n.trait === "stoic" ? 1 : 0));
    }
  }

  if (won) {
    s.raids++;
    s.stats.raids++;
    s.gold += b.gold;
    s.score += b.score;
    s.stats.earned += b.gold;
    s.threat = 5;
    ev.push({ type: "raid_win", clan: b.clan, gold: b.gold, pts: b.score });
  } else {
    const dmg = 1 + (b.round <= 2 ? 1 : 0);
    s.hp = Math.max(0, s.hp - dmg);
    s.threat = 25;
    ev.push({ type: "raid_loss", clan: b.clan, dmg });
    if (s.hp <= 0) {
      s.phase = "over";
      s.battle = null;
      ev.push({ type: "gameover" });
      return;
    }
  }
  s.battle = null;
  s.phase = "playing";
}

export { RANK_META };
