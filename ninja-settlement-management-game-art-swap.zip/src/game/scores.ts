export interface ScoreEntry {
  name: string;
  score: number;
  day: number;
  done: number;
  date: number;
}

const KEY = "shadow-village-scores-v1";
const NAME_KEY = "shadow-village-name";

export function loadScores(): ScoreEntry[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw) as ScoreEntry[];
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

export function submitScore(name: string, score: number, day: number, done: number): { list: ScoreEntry[]; idx: number } {
  const entry: ScoreEntry = { name: name.trim().slice(0, 12) || "RONIN", score, day, done, date: Date.now() };
  const list = [...loadScores(), entry].sort((a, b) => b.score - a.score).slice(0, 8);
  try {
    localStorage.setItem(KEY, JSON.stringify(list));
  } catch {
    /* noop */
  }
  return { list, idx: list.indexOf(entry) };
}

export function getPlayerName(): string {
  try {
    return localStorage.getItem(NAME_KEY) || "SHADOW";
  } catch {
    return "SHADOW";
  }
}

export function setPlayerName(n: string): void {
  try {
    localStorage.setItem(NAME_KEY, n.trim().slice(0, 12) || "SHADOW");
  } catch {
    /* noop */
  }
}
