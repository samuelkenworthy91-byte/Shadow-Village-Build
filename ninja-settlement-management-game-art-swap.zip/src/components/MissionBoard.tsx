import { Coins, Lock, ScrollText, Sun, Users, Wheat } from "lucide-react";
import type { GameState, Mission, Skill } from "../game/types";
import { RANK_COLOR, RANK_KANJI, RANK_META, SKILL_META } from "../game/content";
import { autoSquad, coverage, meetsRank, squadChance, squadOf } from "../game/engine";
import NinjaSprite from "./NinjaSprite";
import { cn } from "../utils/cn";

export function chanceColor(c: number): string {
  return c >= 0.75 ? "text-jade" : c >= 0.5 ? "text-gold" : "text-vermil";
}

export default function MissionBoard({
  s,
  className,
  onOpen,
  onQuick,
}: {
  s: GameState;
  className?: string;
  onOpen: (id: number) => void;
  onQuick: (id: number, r: DOMRect) => void;
}) {
  const open = s.missions.filter((m) => m.squad.length === 0);
  const running = s.missions.filter((m) => m.squad.length > 0);
  const ordered = [...running, ...open];

  return (
    <section className={cn("panel flex min-h-0 flex-col", className)}>
      <header className="panel-h">
        <span className="p-kanji">任</span>
        <span className="panel-title">Mission Board</span>
        <span className="ml-auto rounded-md bg-black/30 px-1.5 py-0.5 text-[10px] font-semibold tabular-nums text-paper/60">
          {open.length} open · {running.length} out
        </span>
      </header>
      <div className="scroller min-h-0 flex-1 space-y-2 overflow-y-auto p-2">
        {ordered.length === 0 && (
          <div className="flex h-full min-h-24 flex-col items-center justify-center gap-2 text-paper/40">
            <ScrollText size={22} className="opacity-50" />
            <p className="text-[11px]">No contracts — end the day for new work.</p>
          </div>
        )}

        {ordered.map((m) => {
          if (m.squad.length > 0) {
            const squad = squadOf(s, m);
            const pct = 100 * (1 - m.days / m.totalDays);
            return (
              <article key={m.id} id={`mission-${m.id}`} className="scroll-card running" style={{ "--rc": RANK_COLOR[m.rank] } as React.CSSProperties}>
                <Seal rank={m.rank} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1">
                    <div className="flex -space-x-1">
                      {squad.map((n) => (
                        <span key={n.id} className="overflow-hidden rounded-full bg-black/50 ring-1 ring-white/15">
                          <NinjaSprite n={n} h={20} />
                        </span>
                      ))}
                    </div>
                    <h4 className="ml-1 truncate text-[12px] font-bold text-paper/90">{m.name}</h4>
                  </div>
                  <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-black/45">
                    <div className="h-full rounded-full bg-gradient-to-r from-[var(--rc)] to-white/70 transition-[width] duration-500" style={{ width: `${pct}%` }} />
                  </div>
                </div>
                <div className="flex w-14 shrink-0 flex-col items-end justify-center">
                  <span className="text-[13px] font-black tabular-nums text-paper/85">{m.days}d</span>
                  <span className="text-[8.5px] tracking-wider text-paper/45">REMAINING</span>
                </div>
              </article>
            );
          }

          const idx = open.indexOf(m);
          const auto = autoSquad(s, m);
          const autoN = auto.map((id) => s.ninjas.find((n) => n.id === id)!).filter(Boolean);
          const ch = squadChance(s, m, autoN);
          const cov = coverage(s, m, autoN);
          const daysLeft = m.expiresDay - s.day;
          const expiring = daysLeft <= 1;
          const rankOk = autoN.length > 0 && meetsRank(m, autoN);
          const rm = RANK_META[m.minRank];

          return (
            <article
              key={m.id}
              id={`mission-${m.id}`}
              className={cn("scroll-card pop-in flex-col !items-stretch", m.rank === "S" && "rank-s", expiring && "expiring")}
              style={{ "--rc": RANK_COLOR[m.rank] } as React.CSSProperties}
            >
              <div className="flex items-center gap-2">
                <Seal rank={m.rank} />
                <div className="min-w-0 flex-1">
                  <h4 className="truncate text-[12.5px] font-bold text-[#2b2118]">{m.name}</h4>
                  <div className="mt-0.5 flex flex-wrap items-center gap-x-2 text-[10px] font-semibold text-[#5c4c3a]">
                    <span className="inline-flex items-center gap-0.5"><Users size={10} />{m.slots}-man</span>
                    <span className="inline-flex items-center gap-0.5"><Sun size={10} />{m.totalDays}d</span>
                    <span className="inline-flex items-center gap-0.5 text-[#8a6a1d]"><Coins size={10} />{m.gold}</span>
                    {m.rice > 0 && <span className="inline-flex items-center gap-0.5 text-[#4d7a35]"><Wheat size={10} />{m.rice}</span>}
                    <span className={cn(expiring ? "font-bold text-vermil" : "text-[#7a6a55]")}>
                      {daysLeft <= 0 ? "last day" : `${daysLeft}d left`}
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-1.5 flex flex-wrap gap-1">
                <span
                  className={cn("inline-flex items-center gap-1 rounded-md px-1.5 py-[3px] text-[9.5px] font-bold", rankOk ? "bg-[#2f6b45]/12 text-[#2f6b45]" : "bg-[#a33a2a]/12 text-[#a33a2a]")}
                  title={`Requires a ${rm.name} or higher in the cell`}
                >
                  {!rankOk && <Lock size={9} />}
                  <b className="font-display">{rm.kanji}</b>
                  {rm.name}+
                </span>
                {cov.map((c) => {
                  const meta = SKILL_META[c.k as Skill];
                  const ok = c.cov >= 1;
                  return (
                    <span
                      key={c.k}
                      className={cn("inline-flex items-center gap-1 rounded-md px-1.5 py-[3px] text-[9.5px] font-bold tabular-nums", ok ? "bg-[#2f6b45]/15 text-[#2f6b45]" : "bg-[#a33a2a]/12 text-[#a33a2a]")}
                      style={{ boxShadow: `inset 0 0 0 1px ${meta.color}55` }}
                    >
                      <b style={{ color: meta.color }} className="font-display">{meta.kanji}</b>
                      {meta.short}
                      <span className="opacity-70">{Math.round(c.have)}/{c.need}</span>
                    </span>
                  );
                })}
              </div>

              <div className="mt-1.5 flex items-center gap-1.5">
                <span className={cn("rounded-md bg-black/10 px-1.5 py-1 text-[10px] font-black tabular-nums", chanceColor(ch), auto.length === 0 && "text-[#8a7a68]")}>
                  {auto.length ? `${Math.round(ch * 100)}%` : "NO CELL"}
                </span>
                <button onClick={() => onOpen(m.id)} className="btn-ink h-8 flex-1 rounded-lg text-[10.5px] font-black tracking-wider">
                  編成 SELECT SQUAD
                </button>
                <button
                  disabled={auto.length === 0}
                  onClick={(e) => onQuick(m.id, e.currentTarget.getBoundingClientRect())}
                  className="btn-primary relative h-8 w-[74px] shrink-0 rounded-lg text-[10.5px] font-black tracking-wider"
                >
                  派遣
                  {idx >= 0 && idx < 9 && <kbd className="kbd">{idx + 1}</kbd>}
                </button>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}

function Seal({ rank }: { rank: Mission["rank"] }) {
  return (
    <div className="seal-col" style={{ backgroundColor: `color-mix(in srgb, ${RANK_COLOR[rank]} 88%, black)` }}>
      <span className="font-display text-[13px] font-black leading-none text-white drop-shadow">{rank}</span>
      <span className="font-display text-[9px] leading-none text-white/70">{RANK_KANJI[rank]}</span>
    </div>
  );
}
