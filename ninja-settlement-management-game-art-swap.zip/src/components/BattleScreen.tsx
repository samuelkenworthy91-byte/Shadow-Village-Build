import { useEffect, useRef, useState } from "react";
import { Flame, Shield, Sparkles, Swords, Wand2, Zap } from "lucide-react";
import type { BAction, Battle, GameState } from "../game/types";
import { COSTS, actionLabel, aliveAllies, aliveFoes, canUse, currentUnit } from "../game/battle";
import { NATURE_META } from "../game/content";
import NinjaSprite, { EnemyArt } from "./NinjaSprite";
import { cn } from "../utils/cn";

const ACTIONS: { id: BAction; icon: typeof Swords; kanji: string }[] = [
  { id: "attack", icon: Swords, kanji: "撃" },
  { id: "jutsu", icon: Zap, kanji: "術" },
  { id: "genjutsu", icon: Wand2, kanji: "幻" },
  { id: "heal", icon: Sparkles, kanji: "医" },
  { id: "guard", icon: Shield, kanji: "守" },
  { id: "special", icon: Flame, kanji: "奥" },
];

function Bar({ v, max, color, h = 4 }: { v: number; max: number; color: string; h?: number }) {
  return (
    <div className="overflow-hidden rounded-full bg-black/55" style={{ height: h }}>
      <div className="h-full rounded-full transition-[width] duration-300" style={{ width: `${Math.max(0, (v / max) * 100)}%`, backgroundColor: color }} />
    </div>
  );
}

export default function BattleScreen({
  s,
  b,
  onAction,
  onAuto,
  onFinish,
}: {
  s: GameState;
  b: Battle;
  onAction: (a: BAction, target?: string) => void;
  onAuto: () => void;
  onFinish: () => void;
}) {
  const cur = currentUnit(b);
  const isPlayerTurn = b.state === "choose" && cur && !cur.foe;
  const [pending, setPending] = useState<BAction | null>(null);
  const logRef = useRef<HTMLDivElement>(null);
  const over = b.state === "won" || b.state === "lost";

  useEffect(() => {
    logRef.current?.scrollTo({ top: logRef.current.scrollHeight, behavior: "smooth" });
  }, [b.log.length]);

  useEffect(() => {
    setPending(null);
  }, [b.idx, b.round]);

  // keyboard: 1-5 actions, Enter auto
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (over) {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onFinish();
        }
        return;
      }
      if (!isPlayerTurn || !cur) return;
      if (e.key >= "1" && e.key <= "6") {
        const a = ACTIONS[Number(e.key) - 1];
        if (a && canUse(cur, a.id)) choose(a.id);
      } else if (e.key === "Enter") {
        onAuto();
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  });

  const needsTarget = (a: BAction) => a === "attack" || a === "jutsu" || a === "genjutsu";

  const choose = (a: BAction) => {
    if (!needsTarget(a)) {
      onAction(a);
      return;
    }
    const foes = aliveFoes(b);
    if (foes.length === 1) onAction(a, foes[0].uid);
    else setPending(a);
  };

  const allies = b.units.filter((u) => !u.foe);
  const foes = b.units.filter((u) => u.foe);
  const flash = b.flash;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#0b0c16]">
      {/* battlefield backdrop */}
      <div className="absolute inset-0">
        <img src="/bg-village.jpg" alt="" className="h-full w-full object-cover opacity-45" draggable={false} />
        <div className="absolute inset-0 bg-gradient-to-b from-[#1a0d18]/85 via-[#0b0c16]/55 to-[#0b0c16]" />
        <div className="vignette-raid absolute inset-0 opacity-60" />
      </div>

      <div className="relative flex h-full flex-col p-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-[max(0.5rem,env(safe-area-inset-top))] sm:p-3">
        {/* header */}
        <div className="flex shrink-0 items-center gap-2 rounded-xl bg-black/45 px-3 py-1.5 ring-1 ring-white/10 backdrop-blur">
          <span className="font-display text-[15px] font-black text-vermil">襲</span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-[12px] font-black tracking-wide text-paper">{b.clan}</p>
            <p className="text-[9.5px] font-bold tracking-[0.2em] text-paper/45">RAID ON THE VILLAGE</p>
          </div>
          <span className="rounded-md bg-black/40 px-2 py-1 text-[10px] font-black tabular-nums text-gold">ROUND {b.round}</span>
        </div>

        {/* enemies */}
        <div className="mt-2 flex shrink-0 items-end justify-center gap-2 sm:gap-4">
          {foes.map((u) => {
            const hit = flash?.uid === u.uid;
            const targetable = pending !== null && u.alive;
            return (
              <button
                key={u.uid}
                disabled={!targetable}
                onClick={() => {
                  if (pending) {
                    onAction(pending, u.uid);
                    setPending(null);
                  }
                }}
                className={cn(
                  "relative flex flex-col items-center rounded-xl px-1 pb-1 transition",
                  targetable && "ring-2 ring-vermil animate-pulse cursor-pointer",
                  cur?.uid === u.uid && b.state !== "choose" && "scale-105"
                )}
              >
                <div className={cn("relative", hit && flash?.n && "unit-hit", !u.alive && "unit-down")} key={`${u.uid}-${flash?.n ?? 0}`}>
                  <EnemyArt kind={u.kind} h={74} dead={!u.alive} />
                  {hit && (
                    <span className={cn("dmg-pop absolute left-1/2 top-2 font-display text-[19px] font-black", flash.kind === "heal" ? "text-jade" : flash.kind === "crit" ? "text-gold" : "text-[#ff6a6f]")}>
                      {flash.kind === "heal" ? "+" : "−"}{flash.amount}
                    </span>
                  )}
                </div>
                <div className="w-16 sm:w-20">
                  <p className="truncate text-center text-[8.5px] font-bold text-paper/70">{u.name}</p>
                  <Bar v={u.hp} max={u.maxHp} color="#e2452f" />
                </div>
              </button>
            );
          })}
        </div>

        {/* log */}
        <div ref={logRef} className="scroller my-2 min-h-0 flex-1 space-y-0.5 overflow-y-auto rounded-xl bg-black/45 p-2 text-[10.5px] ring-1 ring-white/10 backdrop-blur">
          {b.log.map((l, i) => (
            <p
              key={i}
              className={cn(
                "leading-snug",
                l.kind === "crit" && "font-black text-gold",
                l.kind === "hit" && "text-paper/80",
                l.kind === "heal" && "text-jade",
                l.kind === "down" && "font-bold text-vermil",
                l.kind === "miss" && "italic text-paper/40",
                l.kind === "info" && "text-paper/50"
              )}
            >
              {l.t}
            </p>
          ))}
        </div>

        {/* allies */}
        <div className="grid shrink-0 grid-cols-2 gap-1.5 sm:grid-cols-4">
          {allies.map((u) => {
            const active = cur?.uid === u.uid && b.state === "choose";
            const hit = flash?.uid === u.uid;
            return (
              <div
                key={u.uid}
                className={cn(
                  "relative flex items-center gap-1.5 rounded-xl bg-black/45 p-1.5 ring-1 backdrop-blur transition",
                  active ? "ring-gold shadow-[0_0_16px_rgba(244,198,79,0.3)]" : "ring-white/10",
                  !u.alive && "opacity-40"
                )}
              >
                <div className={cn("relative shrink-0", hit && "unit-hit")} key={`${u.uid}-${flash?.n ?? 0}`}>
                  {u.look && (
                    <NinjaSprite
                      n={{ id: u.ninjaId ?? 0, look: u.look, nature: u.nature ?? "fire", level: u.level, rank: u.rank ?? "genin", legend: u.legend }}
                      h={34}
                      grey={!u.alive}
                    />
                  )}
                  {hit && (
                    <span className={cn("dmg-pop absolute -top-1 left-1/2 font-display text-[15px] font-black", flash.kind === "heal" ? "text-jade" : "text-[#ff6a6f]")}>
                      {flash.kind === "heal" ? "+" : "−"}{flash.amount}
                    </span>
                  )}
                  {u.guard && <Shield size={11} className="absolute -right-1 -top-1 text-[#7db9ec]" />}
                  {u.stun > 0 && <span className="absolute -right-1 -top-1 text-[11px]">💫</span>}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[10px] font-bold text-paper/90">{u.name}</p>
                  <Bar v={u.hp} max={u.maxHp} color="#63c58c" />
                  <div className="mt-[3px]">
                    <Bar v={u.cp} max={u.maxCp} color="#4f9ad9" h={3} />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* command menu */}
        <div className="mt-1.5 shrink-0 rounded-xl bg-black/55 p-2 ring-1 ring-white/10 backdrop-blur">
          {over ? (
            <div className="flex items-center gap-3">
              <div className="min-w-0 flex-1">
                <p className={cn("font-display text-[17px] font-black tracking-wider", b.state === "won" ? "text-jade" : "text-vermil")}>
                  {b.state === "won" ? "勝利 — VILLAGE HELD" : "敗北 — THE WALLS BREAK"}
                </p>
                <p className="truncate text-[10.5px] text-paper/55">
                  {b.state === "won" ? `+${b.gold} gold · +${b.score} score` : "The village takes damage."}
                </p>
              </div>
              <button onClick={onFinish} autoFocus className="btn-primary h-11 shrink-0 rounded-xl px-5 text-[13px] font-black tracking-widest">
                CONTINUE <kbd className="kbd">↵</kbd>
              </button>
            </div>
          ) : pending ? (
            <div className="flex h-11 items-center gap-2">
              <p className="flex-1 text-[11.5px] font-bold text-gold">Choose a target above…</p>
              <button onClick={() => setPending(null)} className="btn-ghost h-9 rounded-lg px-4 text-[11px] font-black">CANCEL</button>
            </div>
          ) : isPlayerTurn && cur ? (
            <>
              <div className="mb-1.5 flex items-center gap-2">
                <span className="text-[10px] font-black tracking-[0.2em] text-gold">{cur.name.toUpperCase()}'S TURN</span>
                <span className="text-[9.5px] font-bold tabular-nums text-[#7db9ec]">CP {Math.round(cur.cp)}/{cur.maxCp}</span>
                <span className="hidden text-[9.5px] font-bold tabular-nums text-paper/45 sm:inline">
                  ATK {Math.round(cur.atk)} · CRIT {Math.round(cur.crit * 100)}% · DGE {Math.round(cur.dodge * 100)}%
                </span>
                <button onClick={onAuto} className="btn-ghost ml-auto h-7 rounded-lg px-2.5 text-[9.5px] font-black tracking-wider">
                  AUTO <kbd className="kbd">↵</kbd>
                </button>
              </div>
              <div className="grid grid-cols-6 gap-1">
                {ACTIONS.map((a, i) => {
                  const ok = canUse(cur, a.id);
                  const Icon = a.icon;
                  const isOgi = a.id === "special";
                  return (
                    <button
                      key={a.id}
                      disabled={!ok}
                      onClick={() => choose(a.id)}
                      className={cn(
                        "btn-ink relative flex h-[52px] flex-col items-center justify-center gap-0.5 rounded-lg px-0.5",
                        isOgi && ok && "ogi-btn"
                      )}
                    >
                      <Icon size={14} />
                      <span className="text-[8.5px] font-black leading-none tracking-wide">{actionLabel(cur, a.id).split(" ")[0].toUpperCase()}</span>
                      {COSTS[a.id] > 0 && <span className="text-[7.5px] font-bold text-[#7db9ec]">{COSTS[a.id]}cp</span>}
                      <kbd className="kbd absolute right-0.5 top-0.5">{i + 1}</kbd>
                    </button>
                  );
                })}
              </div>
            </>
          ) : (
            <div className="flex h-11 items-center justify-center gap-2 text-[11.5px] font-bold text-paper/50">
              <span className="inline-block h-2 w-2 animate-ping rounded-full bg-vermil" />
              {cur ? `${cur.name} moves…` : "…"}
            </div>
          )}
        </div>

        <p className="mt-1 shrink-0 text-center text-[9px] text-paper/30">
          {aliveAllies(b).length} shinobi standing · {aliveFoes(b).length} enemies left · village {s.hp}/{s.hpMax} ♥
          {cur && !cur.foe && cur.nature ? ` · ${NATURE_META[cur.nature].name} release` : ""}
        </p>
      </div>
    </div>
  );
}
