import { ChevronRight, Search, Star, TrendingUp } from "lucide-react";
import { LEGENDS, pendingPerks } from "../game/perks";
import type { GameState } from "../game/types";
import { SCOUT_COST, SKILL_META } from "../game/content";
import { capOf, effSkill, overall, potRange, promoInfo, topSkills } from "../game/engine";
import NinjaSprite from "./NinjaSprite";
import { FatigueBar, PotStars, RankPill } from "./Bits";
import { cn } from "../utils/cn";

export default function Roster({
  s,
  className,
  onOpen,
  onScout,
}: {
  s: GameState;
  className?: string;
  onOpen: (id: number) => void;
  onScout: (r: DOMRect) => void;
}) {
  const cap = capOf(s);
  const canScout = s.ninjas.length < cap && s.gold >= SCOUT_COST.gold && s.rice >= SCOUT_COST.rice && s.ap >= 1;
  const sorted = [...s.ninjas].sort((a, b) => overall(b) - overall(a));
  const sp = s.ninjas.reduce((a, n) => a + n.sp, 0);

  return (
    <section className={cn("panel flex min-h-0 flex-col", className)}>
      <header className="panel-h">
        <span className="p-kanji">忍</span>
        <span className="panel-title">Shinobi</span>
        {sp > 0 && (
          <span className="animate-pulse rounded-md bg-gold/20 px-1.5 py-0.5 text-[9.5px] font-black text-gold ring-1 ring-inset ring-gold/40">
            {sp} SP
          </span>
        )}
        <span className="ml-auto rounded-md bg-black/30 px-1.5 py-0.5 text-[10px] font-semibold tabular-nums text-paper/60">
          {s.ninjas.length}/{cap}
        </span>
      </header>
      <div className="scroller min-h-0 flex-1 space-y-1.5 overflow-y-auto p-2">
        {sorted.map((n) => {
          const tops = topSkills(n, 3);
          const pr = potRange(n);
          const promo = promoInfo(s, n);
          return (
            <button
              key={n.id}
              onClick={() => onOpen(n.id)}
              className={cn(
                "group flex w-full items-center gap-2 rounded-xl bg-black/25 p-1.5 text-left ring-1 ring-inset ring-white/5 transition hover:bg-black/35 active:scale-[0.99]",
                n.status === "injured" && "opacity-85"
              )}
            >
              <span className="relative shrink-0 overflow-hidden rounded-lg bg-black/25">
                <NinjaSprite n={n} h={40} grey={n.status === "injured"} aura={n.sp > 0} />
                {n.sp > 0 && (
                  <span className="absolute -right-0.5 -top-0.5 grid h-4 w-4 place-items-center rounded-full bg-gold text-[9px] font-black text-[#2b2118]">
                    {n.sp}
                  </span>
                )}
              </span>
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-1.5">
                  <b className="truncate text-[12px] font-bold text-paper/95">{n.name}</b>
                  {n.legend && <Star size={11} className="shrink-0" style={{ color: LEGENDS[n.legend].color }} />}
                  {promo.ready && <TrendingUp size={12} className="shrink-0 animate-pulse text-gold" />}
                  {pendingPerks(n) > 0 && (
                    <span className="shrink-0 animate-pulse rounded bg-[#b46ae0]/25 px-1 text-[8px] font-black text-[#cf9bf0]">奥</span>
                  )}
                </span>
                <span className="mt-0.5 flex items-center gap-1">
                  <RankPill rank={n.rank} level={n.level} />
                </span>
                <span className="mt-1 flex flex-wrap items-center gap-1">
                  {tops.map((k) => {
                    const meta = SKILL_META[k];
                    return (
                      <span key={k} className="inline-flex items-center gap-0.5 rounded px-1 py-[1px] text-[9.5px] font-black tabular-nums" style={{ backgroundColor: `${meta.color}26`, color: meta.color }}>
                        <b className="font-display">{meta.kanji}</b>
                        {Math.round(effSkill(s, n, k))}
                      </span>
                    );
                  })}
                  <PotStars lo={pr.lo} hi={pr.hi} known={pr.known} size={8} />
                </span>
                <span className="mt-1 flex items-center gap-2">
                  <FatigueBar n={n} wide />
                  <span
                    className={cn(
                      "w-[64px] shrink-0 rounded py-[2px] text-center text-[8.5px] font-black tracking-wider tabular-nums",
                      n.status === "ready" && "bg-jade/15 text-jade",
                      n.status === "mission" && "bg-[#4f9ad9]/15 text-[#7db9ec]",
                      n.status === "injured" && "bg-[#ff5a66]/12 text-[#ff8a92]"
                    )}
                  >
                    {n.status === "ready" && "READY"}
                    {n.status === "mission" && `OUT ${n.daysLeft}d`}
                    {n.status === "injured" && `HURT ${n.daysLeft}d`}
                  </span>
                </span>
              </span>
              <ChevronRight size={14} className="shrink-0 text-paper/25 transition group-hover:text-paper/60" />
            </button>
          );
        })}

        <button
          disabled={!canScout}
          onClick={(e) => onScout(e.currentTarget.getBoundingClientRect())}
          className={cn(
            "flex w-full items-center gap-2 rounded-xl border border-dashed p-2 text-left transition",
            canScout ? "border-gold/40 bg-gold/5 hover:bg-gold/10 active:scale-[0.98]" : "border-white/10 bg-black/20 opacity-50"
          )}
        >
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-black/30 text-gold">
            <Search size={16} />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-[11.5px] font-bold text-paper/90">
              Scout for Recruits <kbd className="kbd ml-1">N</kbd>
            </span>
            <span className="block text-[9.5px] font-semibold text-paper/50">
              {s.ninjas.length >= cap
                ? "Upgrade the Main Hall for capacity"
                : `1 action · ${SCOUT_COST.gold} gold · ${SCOUT_COST.rice} rice — choose 1 of 3`}
            </span>
          </span>
        </button>
      </div>
    </section>
  );
}
