import { useEffect, useMemo, useState } from "react";
import { Check, Sparkles, Users, X } from "lucide-react";
import type { GameState, Skill } from "../game/types";
import { NATURE_META, RANK_COLOR, SKILL_META, TRAIT_META } from "../game/content";
import { autoSquad, coverage, effSkill, squadChance } from "../game/engine";
import NinjaSprite from "./NinjaSprite";
import { FatigueBar, RankPill } from "./Bits";
import { chanceColor } from "./MissionBoard";
import { cn } from "../utils/cn";

export default function SquadModal({
  s,
  missionId,
  onClose,
  onDeploy,
}: {
  s: GameState;
  missionId: number;
  onClose: () => void;
  onDeploy: (ids: number[]) => void;
}) {
  const m = s.missions.find((x) => x.id === missionId);
  const [sel, setSel] = useState<number[]>(() => (m ? autoSquad(s, m) : []));

  const ready = useMemo(() => s.ninjas.filter((n) => n.status === "ready"), [s.ninjas]);
  const reqKeys = useMemo(() => (m ? (Object.keys(m.req) as Skill[]) : []), [m]);

  const squad = sel.map((id) => s.ninjas.find((n) => n.id === id)).filter(Boolean) as typeof s.ninjas;
  const ch = m ? squadChance(s, m, squad) : 0;
  const cov = m ? coverage(s, m, squad) : [];

  const toggle = (id: number) => {
    if (!m) return;
    setSel((cur) => {
      if (cur.includes(id)) return cur.filter((x) => x !== id);
      if (cur.length >= m.slots) return [...cur.slice(1), id];
      return [...cur, id];
    });
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!m) return;
      if (e.key === "Escape") {
        e.preventDefault();
        onClose();
      } else if (e.key === "Enter") {
        e.preventDefault();
        if (sel.length) onDeploy(sel);
      } else if (e.key.toLowerCase() === "a") {
        e.preventDefault();
        setSel(autoSquad(s, m));
      } else if (e.key >= "1" && e.key <= "9") {
        const n = ready[Number(e.key) - 1];
        if (n) toggle(n.id);
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  });

  if (!m) return null;

  // sort candidates by their fit for this specific mission
  const scored = ready
    .map((n) => ({ n, fit: reqKeys.reduce((a, k) => a + effSkill(s, n, k), 0) }))
    .sort((a, b) => b.fit - a.fit);

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#0d0e1a]/75 p-0 backdrop-blur-sm sm:items-center sm:p-4">
      <div className="modal-pop flex max-h-[92dvh] w-full max-w-lg flex-col rounded-t-2xl bg-[#161828]/97 shadow-2xl ring-1 ring-white/10 sm:rounded-2xl">
        {/* header */}
        <div className="flex items-start gap-2.5 border-b border-white/8 p-3">
          <span
            className="grid h-11 w-11 shrink-0 place-items-center rounded-xl font-display text-lg font-black text-white"
            style={{ background: `linear-gradient(180deg, ${RANK_COLOR[m.rank]}, color-mix(in srgb, ${RANK_COLOR[m.rank]} 55%, black))` }}
          >
            {m.rank}
          </span>
          <div className="min-w-0 flex-1">
            <h3 className="truncate text-[14px] font-black tracking-wide text-paper">{m.name}</h3>
            <p className="truncate text-[10.5px] italic text-paper/45">“{m.desc}”</p>
            <p className="mt-0.5 flex items-center gap-2 text-[10px] font-bold text-paper/60">
              <span className="inline-flex items-center gap-1"><Users size={10} />{sel.length}/{m.slots} cell</span>
              <span className="text-gold">{m.gold}両</span>
              {m.rice > 0 && <span className="text-[#8fce6a]">{m.rice}米</span>}
              <span className="text-paper/40">{m.totalDays} day{m.totalDays > 1 ? "s" : ""}</span>
            </p>
          </div>
          <button onClick={onClose} className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-black/30 text-paper/60 ring-1 ring-white/10 active:scale-90">
            <X size={15} />
          </button>
        </div>

        {/* coverage */}
        <div className="space-y-1.5 border-b border-white/8 p-3">
          {cov.map((c) => {
            const meta = SKILL_META[c.k];
            const pctFill = Math.min(140, c.cov * 100);
            return (
              <div key={c.k} className="flex items-center gap-2">
                <span className="w-11 shrink-0 text-[10px] font-bold" style={{ color: meta.color }}>
                  <b className="font-display">{meta.kanji}</b> {meta.short}
                </span>
                <div className="relative h-2.5 flex-1 overflow-hidden rounded-full bg-black/45">
                  <div className="h-full rounded-full transition-[width] duration-200" style={{ width: `${Math.min(100, pctFill)}%`, backgroundColor: meta.color }} />
                  {pctFill > 100 && <div className="absolute inset-y-0 right-0 w-[6px] bg-white/50" />}
                  <div className="absolute inset-y-0 left-[calc(100%-2px)] w-[2px] bg-white/40" />
                </div>
                <span className={cn("w-14 shrink-0 text-right text-[10px] font-black tabular-nums", c.cov >= 1 ? "text-jade" : "text-vermil")}>
                  {Math.round(c.have)}/{c.need}
                </span>
              </div>
            );
          })}
        </div>

        {/* candidates */}
        <div className="scroller min-h-0 flex-1 space-y-1.5 overflow-y-auto p-2.5">
          {scored.length === 0 && (
            <p className="py-6 text-center text-[11px] text-paper/40">Every shinobi is deployed or recovering.</p>
          )}
          {scored.map(({ n }, i) => {
            const on = sel.includes(n.id);
            const nat = NATURE_META[n.nature];
            return (
              <button
                key={n.id}
                onClick={() => toggle(n.id)}
                className={cn(
                  "flex w-full items-center gap-2 rounded-xl p-1.5 text-left ring-1 transition active:scale-[0.99]",
                  on ? "bg-vermil/15 ring-vermil/50" : "bg-black/25 ring-white/5 hover:bg-black/35"
                )}
              >
                <span className="relative shrink-0">
                  <NinjaSprite n={n} h={38} aura={on} />
                  {on && (
                    <span className="absolute -right-1 -top-1 grid h-4 w-4 place-items-center rounded-full bg-jade text-[#0d0e1a]">
                      <Check size={11} strokeWidth={4} />
                    </span>
                  )}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex items-center gap-1.5">
                    <b className="truncate text-[12px] font-bold text-paper/95">{n.name}</b>
                    <RankPill rank={n.rank} level={n.level} />
                  </span>
                  <span className="mt-0.5 flex flex-wrap items-center gap-1">
                    {reqKeys.map((k) => {
                      const meta = SKILL_META[k];
                      const v = effSkill(s, n, k);
                      const strong = v >= (m.req[k] ?? 0) * 0.6;
                      return (
                        <span
                          key={k}
                          className="inline-flex items-center gap-0.5 rounded px-1 py-[1px] text-[9.5px] font-black tabular-nums"
                          style={{
                            backgroundColor: strong ? `${meta.color}30` : "rgba(0,0,0,0.35)",
                            color: strong ? meta.color : "rgba(239,230,208,0.4)",
                          }}
                        >
                          <b className="font-display">{meta.kanji}</b>
                          {Math.round(v)}
                        </span>
                      );
                    })}
                    <span className="text-[9px] font-bold" style={{ color: nat.color }}>{nat.kanji}</span>
                    <span className="text-[9px] text-paper/35">{TRAIT_META[n.trait].name}</span>
                  </span>
                </span>
                <span className="w-12 shrink-0">
                  <FatigueBar n={n} wide />
                  <span className="mt-0.5 block text-right text-[8.5px] tabular-nums text-paper/35">{i + 1}</span>
                </span>
              </button>
            );
          })}
        </div>

        {/* footer */}
        <div className="flex items-center gap-2 border-t border-white/8 p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
          <div className="shrink-0 text-center">
            <p className="text-[8.5px] font-bold tracking-[0.2em] text-paper/40">ODDS</p>
            <p className={cn("text-[19px] font-black leading-none tabular-nums", chanceColor(ch))}>
              {sel.length ? `${Math.round(ch * 100)}%` : "—"}
            </p>
          </div>
          <button onClick={() => setSel(autoSquad(s, m))} className="btn-ghost h-11 shrink-0 rounded-xl px-3 text-[11px] font-black tracking-wider">
            <Sparkles size={13} className="mr-1 inline" />AUTO<kbd className="kbd">A</kbd>
          </button>
          <button
            disabled={sel.length === 0}
            onClick={() => onDeploy(sel)}
            className="btn-primary h-11 flex-1 rounded-xl text-[13px] font-black tracking-[0.14em]"
          >
            出撃 DEPLOY<kbd className="kbd">↵</kbd>
          </button>
        </div>
      </div>
    </div>
  );
}
