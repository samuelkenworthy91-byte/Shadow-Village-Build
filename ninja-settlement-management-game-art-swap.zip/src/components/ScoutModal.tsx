import { Star, UserPlus, X } from "lucide-react";
import { LEGENDS } from "../game/perks";
import type { Ninja } from "../game/types";
import { NATURE_META, SKILLS, SKILL_META, TRAIT_META } from "../game/content";
import { overall, potRange } from "../game/engine";
import NinjaSprite from "./NinjaSprite";
import { PotStars } from "./Bits";
import { cn } from "../utils/cn";

export default function ScoutModal({
  candidates,
  onPick,
  onClose,
}: {
  candidates: Ninja[];
  onPick: (id: number, r: DOMRect) => void;
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#0d0e1a]/78 p-0 backdrop-blur-sm sm:items-center sm:p-4">
      <div className="modal-pop flex max-h-[94dvh] w-full max-w-2xl flex-col rounded-t-2xl bg-[#161828]/97 shadow-2xl ring-1 ring-white/10 sm:rounded-2xl">
        <div className="flex items-center gap-2.5 border-b border-white/8 p-3">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-b from-gold to-[#a8791d] font-display text-lg font-black text-[#2b2118]">
            募
          </span>
          <div className="min-w-0 flex-1">
            <h3 className="text-[14px] font-black tracking-wide text-paper">Three hopefuls at the gate</h3>
            <p className="text-[10.5px] text-paper/50">Only one may take the headband. Potential is an estimate.</p>
          </div>
          <button onClick={onClose} className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-black/30 text-paper/60 ring-1 ring-white/10 active:scale-90">
            <X size={15} />
          </button>
        </div>

        <div className="scroller grid min-h-0 flex-1 gap-2 overflow-y-auto p-2.5 sm:grid-cols-3">
          {candidates.map((n, i) => {
            const nat = NATURE_META[n.nature];
            const trait = TRAIT_META[n.trait];
            const pr = potRange(n);
            const best = [...SKILLS].sort((a, b) => n.s[b] - n.s[a]);
            return (
              <article
                key={n.id}
                className={cn("pop-in flex flex-col rounded-xl p-2.5 ring-1 ring-inset", n.legend ? "legend-card bg-black/40" : "bg-black/30 ring-white/8")}
                style={{
                  animationDelay: `${i * 70}ms`,
                  ...(n.legend ? ({ "--lg": LEGENDS[n.legend].color } as React.CSSProperties) : {}),
                }}
              >
                {n.legend && (
                  <p className="mb-1.5 flex items-center gap-1 text-[9.5px] font-black tracking-[0.16em]" style={{ color: LEGENDS[n.legend].color }}>
                    <Star size={10} /> {LEGENDS[n.legend].title.toUpperCase()} · UNIQUE
                  </p>
                )}
                <div className="flex items-start gap-2">
                  <div className="shrink-0 rounded-lg bg-black/35 p-1 ring-1 ring-white/10">
                    <NinjaSprite n={n} h={62} crop="full" aura />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12.5px] font-black text-paper">{n.name}</p>
                    <p className="mt-0.5 flex flex-wrap gap-1 text-[9px] font-bold">
                      <span className="rounded px-1.5 py-[2px]" style={{ backgroundColor: `${nat.color}22`, color: nat.color }}>
                        <b className="font-display">{nat.kanji}</b> {nat.name}
                      </span>
                      <span className="rounded bg-gold/15 px-1.5 py-[2px] text-gold">{trait.icon} {trait.name}</span>
                    </p>
                    <p className="mt-1 text-[9px] font-bold tracking-wider text-paper/40">OVR {Math.round(overall(n))}</p>
                    <div className="mt-0.5">
                      <PotStars lo={pr.lo} hi={pr.hi} known={pr.known} />
                    </div>
                  </div>
                </div>

                <p className="mt-2 text-[8.5px] font-bold tracking-[0.2em] text-paper/35">SKILL SET</p>
                <div className="mt-1 grid grid-cols-3 gap-1">
                  {SKILLS.map((k) => {
                    const meta = SKILL_META[k];
                    const isTop = best.slice(0, 2).includes(k);
                    return (
                      <span
                        key={k}
                        className={cn("flex items-center justify-between rounded px-1 py-[2px] text-[9.5px] font-black tabular-nums", isTop ? "text-white" : "text-paper/50")}
                        style={{ backgroundColor: isTop ? `${meta.color}2e` : "rgba(0,0,0,0.3)" }}
                      >
                        <b className="font-display" style={{ color: meta.color }}>{meta.kanji}</b>
                        {n.s[k]}
                      </span>
                    );
                  })}
                </div>
                {n.legend ? (
                  <p className="mt-1.5 rounded-md px-1.5 py-1 text-[9.5px] font-semibold leading-snug" style={{ backgroundColor: `${LEGENDS[n.legend].color}1f`, color: LEGENDS[n.legend].color }}>
                    {LEGENDS[n.legend].blurb} Unlocks 奥義 {LEGENDS[n.legend].perk.name}.
                  </p>
                ) : (
                  <p className="mt-1.5 line-clamp-2 text-[9.5px] italic leading-snug text-paper/40">{trait.desc}.</p>
                )}

                <button
                  onClick={(e) => onPick(n.id, e.currentTarget.getBoundingClientRect())}
                  className="btn-primary mt-2 flex h-10 items-center justify-center gap-1.5 rounded-xl text-[12px] font-black tracking-wider"
                >
                  <UserPlus size={14} /> RECRUIT <kbd className="kbd">{i + 1}</kbd>
                </button>
              </article>
            );
          })}
        </div>
      </div>
    </div>
  );
}
