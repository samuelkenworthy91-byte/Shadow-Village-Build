import { RANK_META, SKILL_META } from "../game/content";
import type { NinRank, Ninja, Skill } from "../game/types";
import { cn } from "../utils/cn";

function Star({ size, fill }: { size: number; fill: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 12 12" className={fill}>
      <path fill="currentColor" d="M6 .8l1.6 3.3 3.6.5-2.6 2.5.6 3.6L6 9l-3.2 1.7.6-3.6L.8 4.6l3.6-.5z" />
    </svg>
  );
}

/** Potential shown as an uncertain band until the ninja has enough experience. */
export function PotStars({ lo, hi, known, size = 9 }: { lo: number; hi: number; known: boolean; size?: number }) {
  return (
    <span className="inline-flex items-center gap-1" title={known ? `Potential ${hi}/5` : `Potential ${lo}–${hi} of 5 (estimate)`}>
      <span className="inline-flex gap-[1px]">
        {Array.from({ length: 5 }, (_, i) => (
          <Star key={i} size={size} fill={i < lo ? "text-gold" : i < hi ? "text-gold/35" : "text-white/12"} />
        ))}
      </span>
      <span className={cn("text-[8px] font-bold tracking-wider", known ? "text-gold/70" : "text-paper/35")}>
        {known ? "CONFIRMED" : `${lo}–${hi}?`}
      </span>
    </span>
  );
}

export function RankPill({ rank, level }: { rank: NinRank; level: number }) {
  const rt = RANK_META[rank];
  return (
    <span
      className="inline-flex shrink-0 items-center gap-1 rounded-md px-1.5 py-[2px] text-[9px] font-bold tracking-wide"
      style={{ backgroundColor: `${rt.color}22`, color: rt.color, boxShadow: `inset 0 0 0 1px ${rt.color}44` }}
    >
      <b className="font-display">{rt.kanji}</b>
      {rt.name} · Lv{level}
    </span>
  );
}

export function SkillChip({ k, v, hot }: { k: Skill; v: number; hot?: boolean }) {
  const m = SKILL_META[k];
  return (
    <span
      className={cn("inline-flex items-center gap-0.5 rounded px-1 py-[1px] text-[9.5px] font-bold tabular-nums", hot ? "text-white" : "text-paper/65")}
      style={{ backgroundColor: hot ? `${m.color}33` : "rgba(0,0,0,0.3)" }}
    >
      <b className="font-display" style={{ color: m.color }}>{m.kanji}</b>
      {Math.round(v)}
    </span>
  );
}

export function FatigueBar({ n, wide }: { n: Ninja; wide?: boolean }) {
  const f = Math.round(n.fatigue);
  const col = f > 65 ? "#e2452f" : f > 35 ? "#f4c64f" : "#63c58c";
  return (
    <span className={cn("inline-flex items-center gap-1", wide && "flex-1")} title={`Fatigue ${f}%`}>
      <span className="text-[8.5px] font-bold tracking-wider text-paper/35">疲</span>
      <span className={cn("h-1 overflow-hidden rounded-full bg-black/50", wide ? "flex-1" : "w-9")}>
        <span className="block h-full rounded-full" style={{ width: `${f}%`, backgroundColor: col, transition: "width 250ms linear" }} />
      </span>
    </span>
  );
}
