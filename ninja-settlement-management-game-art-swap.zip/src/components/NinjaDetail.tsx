import { Check, Plus, Star, TrendingUp, X } from "lucide-react";
import type { GameState, Skill } from "../game/types";
import { NATURE_META, RANK_META, SKILLS, SKILL_META, TRAIT_META } from "../game/content";
import { effSkill, overall, potRange, promoInfo, xpNext } from "../game/engine";
import NinjaSprite from "./NinjaSprite";
import PerkTree from "./PerkTree";
import { FatigueBar, PotStars, RankPill } from "./Bits";
import { LEGENDS, perkFx } from "../game/perks";
import { unitFromNinja } from "../game/battle";
import { cn } from "../utils/cn";

export default function NinjaDetail({
  s,
  ninjaId,
  onClose,
  onTrain,
  onPromote,
  onPerk,
}: {
  s: GameState;
  ninjaId: number;
  onClose: () => void;
  onTrain: (k: Skill, r: DOMRect) => void;
  onPromote: (r: DOMRect) => void;
  onPerk: (id: string, r: DOMRect) => void;
}) {
  const n = s.ninjas.find((x) => x.id === ninjaId);
  if (!n) return null;
  const nat = NATURE_META[n.nature];
  const trait = TRAIT_META[n.trait];
  const xpPct = Math.min(100, (n.xp / xpNext(n.level)) * 100);
  const maxSkill = Math.max(20, ...SKILLS.map((k) => n.s[k]));
  const winRate = n.runs ? Math.round((n.wins / n.runs) * 100) : 0;
  const pr = potRange(n);
  const promo = promoInfo(s, n);
  const nextMeta = promo.next ? RANK_META[promo.next] : null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#0d0e1a]/75 p-0 backdrop-blur-sm sm:items-center sm:p-4">
      <div className="modal-pop flex max-h-[94dvh] w-full max-w-md flex-col rounded-t-2xl bg-[#161828]/97 shadow-2xl ring-1 ring-white/10 sm:rounded-2xl">
        <div className="flex items-start gap-3 border-b border-white/8 p-3">
          <div className="shrink-0 overflow-hidden rounded-xl bg-black/30 ring-1 ring-white/10">
            <NinjaSprite n={n} h={104} crop="full" grey={n.status === "injured"} aura />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-1.5">
              <h3 className="truncate text-[15px] font-black tracking-wide text-paper">{n.name}</h3>
            </div>
            <div className="mt-1"><RankPill rank={n.rank} level={n.level} /></div>
            <div className="mt-1.5 flex flex-wrap items-center gap-1.5 text-[10px] font-bold">
              <span className="rounded px-1.5 py-[2px]" style={{ backgroundColor: `${nat.color}22`, color: nat.color }}>
                <b className="font-display">{nat.kanji}</b> {nat.name}
              </span>
              <span className="rounded bg-gold/15 px-1.5 py-[2px] text-gold" title={trait.desc}>
                {trait.icon} {trait.name}
              </span>
            </div>
            <div className="mt-1.5"><PotStars lo={pr.lo} hi={pr.hi} known={pr.known} /></div>
            <p className="mt-1 text-[10px] font-black tabular-nums text-paper/60">
              OVR {Math.round(overall(n))} · {n.runs} missions · {winRate}% won
            </p>
          </div>
          <button onClick={onClose} className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-black/30 text-paper/60 ring-1 ring-white/10 active:scale-90">
            <X size={15} />
          </button>
        </div>

        {/* legendary banner */}
        {n.legend && LEGENDS[n.legend] && (
          <div
            className="border-b border-white/8 px-3 py-2"
            style={{ background: `linear-gradient(90deg, ${LEGENDS[n.legend].color}22, transparent)` }}
          >
            <p className="flex items-center gap-1.5 text-[10.5px] font-black tracking-wider" style={{ color: LEGENDS[n.legend].color }}>
              <Star size={11} /> {LEGENDS[n.legend].title.toUpperCase()} — {LEGENDS[n.legend].epithet}
            </p>
            <p className="mt-0.5 text-[9.5px] italic leading-snug text-paper/50">{LEGENDS[n.legend].blurb}</p>
          </div>
        )}

        {/* battle readout — makes stat impact legible */}
        {(() => {
          const u = unitFromNinja(n);
          const fx = perkFx(n);
          const rows: [string, string, string][] = [
            ["HP", String(u.maxHp), "#63c58c"],
            ["ATK", String(Math.round(u.atk)), "#e2764f"],
            ["DEF", String(Math.round(u.def)), "#9aa7bd"],
            ["CRIT", `${Math.round(u.crit * 100)}%`, "#f4c64f"],
            ["DODGE", `${Math.round(u.dodge * 100)}%`, "#4f9ad9"],
            ["CHAKRA", String(u.maxCp), "#b46ae0"],
          ];
          return (
            <div className="border-b border-white/8 px-3 py-2">
              <p className="mb-1 text-[9.5px] font-bold tracking-[0.2em] text-paper/40">BATTLE PROFILE</p>
              <div className="grid grid-cols-6 gap-1">
                {rows.map(([k, v, c]) => (
                  <div key={k} className="rounded-md bg-black/28 py-1 text-center">
                    <p className="text-[7.5px] font-bold tracking-wider text-paper/35">{k}</p>
                    <p className="text-[11px] font-black tabular-nums" style={{ color: c }}>{v}</p>
                  </div>
                ))}
              </div>
              {fx.special?.tech && (
                <p className="mt-1.5 rounded-md bg-gold/10 px-2 py-1 text-[9.5px] font-bold text-gold ring-1 ring-inset ring-gold/25">
                  奥義 {fx.special.tech.name} — {fx.special.tech.note}
                </p>
              )}
            </div>
          );
        })()}

        {/* promotion */}
        {nextMeta && (
          <div className={cn("border-b border-white/8 p-2.5", promo.ready && "bg-gold/[0.07]")}>
            <div className="flex items-center gap-2">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg font-display text-base font-black" style={{ backgroundColor: `${nextMeta.color}22`, color: nextMeta.color }}>
                {nextMeta.kanji}
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-[11.5px] font-black text-paper/90">Promotion Exam — {nextMeta.name}</p>
                <div className="mt-0.5 flex flex-wrap gap-x-2.5 gap-y-0.5 text-[9.5px] font-bold tabular-nums">
                  <Req ok={promo.okLevel} label={`Lv ${n.level}/${nextMeta.level}`} />
                  <Req ok={promo.okMissions} label={`${n.wins}/${nextMeta.missions} wins`} />
                  <Req ok={promo.okGold} label={`${nextMeta.gold} gold`} />
                  <Req ok={promo.okAp} label="1 action" />
                </div>
              </div>
              <button
                disabled={!promo.ready}
                onClick={(e) => onPromote(e.currentTarget.getBoundingClientRect())}
                className="btn-primary flex h-9 shrink-0 items-center gap-1 rounded-lg px-2.5 text-[10px] font-black tracking-wider"
              >
                <TrendingUp size={12} /> PROMOTE
              </button>
            </div>
            {promo.ready && (
              <p className="mt-1.5 text-[9.5px] text-gold/80">
                Grants +2 SP, a permanent skill boost and access to higher-grade contracts.
              </p>
            )}
          </div>
        )}
        {!nextMeta && (
          <div className="border-b border-white/8 bg-[#ff8a4d]/10 p-2.5 text-center text-[11px] font-black tracking-wider text-[#ff8a4d]">
            影 KAGE — the highest office. None stand above.
          </div>
        )}

        <div className="border-b border-white/8 px-3 py-2">
          <div className="flex items-center gap-2 text-[9.5px] font-bold tracking-wider text-paper/45">
            <span>XP</span>
            <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-black/45">
              <div className="h-full rounded-full bg-jade/80 transition-[width] duration-300" style={{ width: `${xpPct}%` }} />
            </div>
            <span className="tabular-nums">LV {n.level}</span>
          </div>
          <div className="mt-1.5 flex items-center gap-3">
            <FatigueBar n={n} wide />
            <span className={cn("text-[9.5px] font-black tracking-wider", n.status === "ready" ? "text-jade" : n.status === "mission" ? "text-[#7db9ec]" : "text-[#ff8a92]")}>
              {n.status === "ready" ? "AT THE VILLAGE" : n.status === "mission" ? `ON MISSION · ${n.daysLeft}d` : `RECOVERING · ${n.daysLeft}d`}
            </span>
          </div>
        </div>

        <div className="scroller min-h-0 flex-1 overflow-y-auto p-3">
          <div className="mb-2 flex items-center gap-2">
            <p className="text-[10px] font-bold tracking-[0.2em] text-paper/45">SKILL SET</p>
            <span className={cn("rounded-md px-1.5 py-[2px] text-[9.5px] font-black tracking-wider", n.sp > 0 ? "bg-gold/20 text-gold ring-1 ring-inset ring-gold/40" : "bg-black/30 text-paper/35")}>
              {n.sp} SKILL POINT{n.sp === 1 ? "" : "S"}
            </span>
          </div>

          <div className="space-y-1.5">
            {SKILLS.map((k) => {
              const meta = SKILL_META[k];
              const raw = n.s[k];
              const eff = effSkill(s, n, k);
              const penalty = raw - eff;
              const gr = n.growth[k];
              return (
                <div key={k} className="flex items-center gap-2">
                  <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg font-display text-[13px] font-black" style={{ backgroundColor: `${meta.color}22`, color: meta.color }}>
                    {meta.kanji}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-[10.5px] font-bold text-paper/80">{meta.name}</span>
                      {gr >= 1.4 && <span className="text-[8.5px] font-black tracking-wider text-jade">FAST</span>}
                      <span className="ml-auto text-[11px] font-black tabular-nums text-paper/95">{raw}</span>
                      {penalty > 0.4 && <span className="text-[9px] font-bold tabular-nums text-vermil">−{Math.round(penalty)}</span>}
                    </div>
                    <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-black/45">
                      <div className="h-full rounded-full transition-[width] duration-300" style={{ width: `${(raw / maxSkill) * 100}%`, backgroundColor: meta.color }} />
                    </div>
                  </div>
                  <button
                    disabled={n.sp <= 0}
                    onClick={(e) => onTrain(k, e.currentTarget.getBoundingClientRect())}
                    className="btn-ink grid h-7 w-8 shrink-0 place-items-center rounded-lg"
                    aria-label={`Train ${meta.name}`}
                  >
                    <Plus size={13} />
                  </button>
                </div>
              );
            })}
          </div>

          <div className="mt-4 border-t border-white/8 pt-3">
            <PerkTree n={n} onPick={onPerk} />
          </div>

          <p className="mt-3 rounded-lg bg-black/25 p-2.5 text-[10px] leading-relaxed text-paper/50 ring-1 ring-inset ring-white/5">
            <b className="text-paper/75">{trait.name}:</b> {trait.desc}. <b className="text-paper/75">{nat.name}</b> accelerates {SKILL_META[nat.boost].name}.
            Higher potential means more skill points each level — the estimate sharpens as {n.name.split(" ")[0]} gains experience.
          </p>
        </div>
      </div>
    </div>
  );
}

function Req({ ok, label }: { ok: boolean; label: string }) {
  return (
    <span className={cn("inline-flex items-center gap-0.5", ok ? "text-jade" : "text-paper/40")}>
      {ok ? <Check size={9} strokeWidth={4} /> : <span className="text-[8px]">○</span>}
      {label}
    </span>
  );
}
