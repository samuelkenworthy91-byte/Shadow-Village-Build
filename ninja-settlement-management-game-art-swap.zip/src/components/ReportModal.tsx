import { ChevronRight, Coins, ScrollText, Sparkles, TrendingUp, Wheat } from "lucide-react";
import type { GameState, Report } from "../game/types";
import { RANK_COLOR, SKILL_META } from "../game/content";
import NinjaSprite from "./NinjaSprite";
import { cn } from "../utils/cn";

export default function ReportModal({
  s,
  report,
  remaining,
  onNext,
}: {
  s: GameState;
  report: Report;
  remaining: number;
  onNext: () => void;
}) {
  const rc = RANK_COLOR[report.rank];
  return (
    <div className="fixed inset-0 z-[52] flex items-end justify-center bg-[#0d0e1a]/80 p-0 backdrop-blur-sm sm:items-center sm:p-4">
      <div className="modal-pop flex max-h-[94dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-2xl bg-[#171526]/97 shadow-2xl ring-1 ring-white/10 sm:rounded-2xl">
        {/* scroll header */}
        <div className="relative flex items-start gap-2.5 border-b border-white/8 bg-gradient-to-r from-[#efe3c8]/[0.09] to-transparent p-3">
          <span
            className="grid h-11 w-11 shrink-0 place-items-center rounded-xl font-display text-lg font-black text-white"
            style={{ background: `linear-gradient(180deg, ${rc}, color-mix(in srgb, ${rc} 52%, black))` }}
          >
            {report.rank}
          </span>
          <div className="min-w-0 flex-1">
            <p className="flex items-center gap-1.5 text-[9.5px] font-bold tracking-[0.25em] text-paper/40">
              <ScrollText size={10} /> FIELD REPORT · DAY {report.day}
            </p>
            <h3 className="truncate text-[14.5px] font-black tracking-wide text-paper">{report.mission}</h3>
            <p className={cn("mt-0.5 font-display text-[13px] font-black tracking-wider", report.win ? "text-jade" : "text-vermil")}>
              {report.win ? "成功 — MISSION COMPLETE" : "失敗 — MISSION FAILED"}
            </p>
          </div>
          {remaining > 0 && (
            <span className="shrink-0 rounded-md bg-black/40 px-2 py-1 text-[9.5px] font-black tabular-nums text-paper/50">
              +{remaining} more
            </span>
          )}
        </div>

        <div className="scroller min-h-0 flex-1 overflow-y-auto">
          {/* narrative */}
          <div className="space-y-1.5 border-b border-white/8 p-3">
            {report.lines.map((l, i) => (
              <p
                key={i}
                className={cn(
                  "report-line text-[11.5px] leading-relaxed",
                  l.kind === "flavour" && "italic text-paper/50",
                  l.kind === "clutch" && "font-semibold text-gold",
                  l.kind === "good" && "text-jade",
                  l.kind === "bad" && "text-[#ff9a8f]",
                  l.kind === "beat" && "text-paper/45"
                )}
                style={{ animationDelay: `${i * 70}ms` }}
              >
                {l.kind === "clutch" && "◆ "}
                {l.txt}
              </p>
            ))}
          </div>

          {/* spoils */}
          {report.win && (
            <div className="flex items-center gap-2 border-b border-white/8 px-3 py-2 text-[11.5px] font-black tabular-nums">
              <span className="inline-flex items-center gap-1 text-gold"><Coins size={12} />+{report.gold}</span>
              {report.rice > 0 && <span className="inline-flex items-center gap-1 text-[#8fce6a]"><Wheat size={12} />+{report.rice}</span>}
              <span className="ml-auto text-[#ffe9b8]">+{report.pts} pts</span>
            </div>
          )}

          {/* xp table */}
          <div className="p-3">
            <p className="mb-1.5 text-[9.5px] font-bold tracking-[0.22em] text-paper/40">CELL DEBRIEF</p>
            <div className="space-y-1.5">
              {report.xp.map((row, i) => {
                const n = s.ninjas.find((x) => x.id === row.id);
                return (
                  <div
                    key={row.id}
                    className="report-line flex items-center gap-2 rounded-xl bg-black/28 p-1.5 ring-1 ring-inset ring-white/5"
                    style={{ animationDelay: `${300 + i * 90}ms` }}
                  >
                    {n && (
                      <span className="shrink-0 overflow-hidden rounded-lg bg-black/25">
                        <NinjaSprite n={n} h={34} grey={row.injured} aura={row.levels > 0} />
                      </span>
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[11.5px] font-bold text-paper/95">{row.name}</p>
                      <div className="mt-0.5 flex flex-wrap items-center gap-1">
                        <span className="xp-tick rounded bg-jade/15 px-1.5 py-[1px] text-[9.5px] font-black tabular-nums text-jade">
                          +{row.xp} XP
                        </span>
                        {row.skillUps.map((su, j) => (
                          <span
                            key={j}
                            className="xp-tick rounded px-1.5 py-[1px] text-[9.5px] font-black"
                            style={{ backgroundColor: `${SKILL_META[su.k].color}26`, color: SKILL_META[su.k].color, animationDelay: `${(j + 1) * 90}ms` }}
                          >
                            <b className="font-display">{SKILL_META[su.k].kanji}</b> +{su.n}
                          </span>
                        ))}
                        {row.levels > 0 && (
                          <span className="xp-tick rounded bg-gold/20 px-1.5 py-[1px] text-[9.5px] font-black text-gold">
                            LEVEL UP ×{row.levels} · +{row.sp} SP
                          </span>
                        )}
                        {row.perkReady && (
                          <span className="xp-tick inline-flex items-center gap-0.5 rounded bg-[#b46ae0]/20 px-1.5 py-[1px] text-[9.5px] font-black text-[#cf9bf0]">
                            <TrendingUp size={9} /> TECH READY
                          </span>
                        )}
                        {row.injured && (
                          <span className="rounded bg-vermil/15 px-1.5 py-[1px] text-[9.5px] font-black text-[#ff8a92]">INJURED</span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="border-t border-white/8 p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
          <button onClick={onNext} autoFocus className="btn-primary flex h-11 w-full items-center justify-center gap-2 rounded-xl text-[13px] font-black tracking-[0.14em]">
            {remaining > 0 ? (
              <>NEXT REPORT <ChevronRight size={15} /></>
            ) : (
              <><Sparkles size={14} /> DISMISS <kbd className="kbd">↵</kbd></>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
