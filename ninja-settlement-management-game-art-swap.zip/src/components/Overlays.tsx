import { Hammer, Play, RotateCcw, ScrollText, Sparkles, Swords, Trophy, Users } from "lucide-react";
import type { GameState } from "../game/types";
import type { ScoreEntry } from "../game/scores";
import { cn } from "../utils/cn";
import type { ReactNode } from "react";

function Shell({ children, kanji }: { children: ReactNode; kanji: string }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-[#0d0e1a]/72 p-4 backdrop-blur-sm">
      <span className="pointer-events-none fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 select-none font-display text-[52vmin] font-black leading-none text-white/[0.035]">
        {kanji}
      </span>
      <div className="modal-pop relative w-full max-w-md rounded-2xl bg-[#161828]/95 p-5 shadow-2xl ring-1 ring-white/10 sm:p-6">
        {children}
      </div>
    </div>
  );
}

export function ScoreTable({ scores, highlight }: { scores: ScoreEntry[]; highlight: number }) {
  if (scores.length === 0) {
    return <p className="rounded-lg bg-black/25 px-3 py-2.5 text-center text-[11px] text-paper/40">No legends yet — survive to write the first.</p>;
  }
  const medal = ["text-gold", "text-[#cfd6e4]", "text-[#d9975f]"];
  return (
    <div className="overflow-hidden rounded-lg ring-1 ring-inset ring-white/10">
      {scores.map((e, i) => (
        <div
          key={e.date + "-" + i}
          className={cn(
            "flex items-center gap-2 px-2.5 py-[7px] text-[11px]",
            i % 2 ? "bg-white/[0.03]" : "bg-black/25",
            i === highlight && "bg-gold/15 ring-1 ring-inset ring-gold/40"
          )}
        >
          <span className={cn("w-4 text-center font-display font-black", medal[i] ?? "text-paper/35")}>{i + 1}</span>
          <span className="flex-1 truncate font-bold tracking-wide text-paper/90">{e.name}</span>
          <span className="tabular-nums text-paper/45">{e.day}d</span>
          <span className="tabular-nums text-paper/45">{e.done}任</span>
          <span className="w-16 text-right font-black tabular-nums text-[#ffe9b8]">{e.score.toLocaleString()}</span>
        </div>
      ))}
    </div>
  );
}

const HOW = [
  { icon: <Users size={16} />, title: "Deploy cells, then end the day", body: "Missions take in-game days. Spend actions, then advance the calendar." },
  { icon: <Swords size={16} />, title: "Raise your shinobi", body: "Skills grow on the job. Potential decides how much each level gives." },
  { icon: <ScrollText size={16} />, title: "Run the promotion exams", body: "Genin → Chūnin → Jōnin → ANBU → Kage unlocks higher contracts." },
  { icon: <Hammer size={16} />, title: "Win the raid battles", body: "Turn-based duels: strike, jutsu, genjutsu, heal or guard." },
];

export function StartOverlay({
  scores,
  name,
  onName,
  onStart,
}: {
  scores: ScoreEntry[];
  name: string;
  onName: (n: string) => void;
  onStart: () => void;
}) {
  return (
    <Shell kanji="影">
      <div className="text-center">
        <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-b from-[#e2452f] to-[#9c2417] font-display text-3xl font-black text-[#ffe9b8] shadow-[0_0_36px_rgba(226,69,47,0.5)]">
          影
        </span>
        <h1 className="title-glow mt-3 font-display text-[34px] font-black leading-none tracking-[0.14em] text-transparent sm:text-[40px]"
          style={{ backgroundImage: "linear-gradient(180deg,#fff4d8 0%,#f4c64f 55%,#c98a2e 100%)", WebkitBackgroundClip: "text", backgroundClip: "text" }}
        >
          SHADOW
        </h1>
        <h1 className="font-display text-[20px] font-black leading-tight tracking-[0.5em] text-paper/90 sm:text-[24px]">
          VILLAGE
        </h1>
        <p className="mt-2 text-[11.5px] font-medium text-paper/55">
          Build the village. Train the shadows. Survive the raids.
        </p>
      </div>

      <div className="mt-4 space-y-1.5">
        {HOW.map((h) => (
          <div key={h.title} className="flex items-center gap-3 rounded-lg bg-black/25 px-3 py-2 ring-1 ring-inset ring-white/5">
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-gold/12 text-gold">{h.icon}</span>
            <div className="min-w-0">
              <p className="text-[12px] font-bold text-paper/95">{h.title}</p>
              <p className="truncate text-[10.5px] text-paper/50">{h.body}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 flex gap-2">
        <input
          id="name-input"
          value={name}
          maxLength={12}
          onChange={(e) => onName(e.target.value.toUpperCase())}
          placeholder="YOUR NAME"
          className="h-11 w-[38%] rounded-xl bg-black/35 px-3 text-[13px] font-bold tracking-widest text-paper ring-1 ring-inset ring-white/10 outline-none placeholder:text-paper/25 focus:ring-gold/50"
        />
        <button onClick={onStart} className="btn-primary h-11 flex-1 rounded-xl text-[15px] font-black tracking-[0.2em]" style={{ animation: "pulseSoft 1.8s ease-in-out infinite" }}>
          BEGIN <kbd className="kbd">↵</kbd>
        </button>
      </div>

      <div className="mt-4">
        <p className="mb-1.5 flex items-center gap-1.5 text-[10px] font-bold tracking-[0.25em] text-paper/40">
          <Trophy size={11} className="text-gold" /> LOCAL LEGENDS
        </p>
        <ScoreTable scores={scores} highlight={-1} />
      </div>

      <p className="mt-3 text-center text-[9.5px] leading-relaxed text-paper/35">
        <kbd className="kbd">↵</kbd> end day · <kbd className="kbd">1–6</kbd> deploy · <kbd className="kbd">E</kbd> squad · <kbd className="kbd">N</kbd> scout · <kbd className="kbd">F/T/D/W/S/H</kbd> build
      </p>
    </Shell>
  );
}

export function PauseOverlay({ onResume, onRestart }: { onResume: () => void; onRestart: () => void }) {
  return (
    <Shell kanji="休">
      <div className="text-center">
        <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-[#23273d] font-display text-2xl font-black text-paper/80 ring-1 ring-white/10">休</span>
        <h2 className="mt-2 font-display text-2xl font-black tracking-[0.3em] text-paper/95">PAUSED</h2>
        <p className="mt-1 text-[11px] text-paper/45">The shadows hold their breath.</p>
      </div>
      <div className="mt-4 grid grid-cols-2 gap-2">
        <button onClick={onResume} autoFocus className="btn-primary flex h-11 items-center justify-center gap-2 rounded-xl text-[13px] font-black tracking-widest">
          <Play size={15} /> RESUME
        </button>
        <button onClick={onRestart} className="btn-ghost flex h-11 items-center justify-center gap-2 rounded-xl text-[13px] font-black tracking-widest">
          <RotateCcw size={15} /> RESTART
        </button>
      </div>
      <div className="mt-4 space-y-1 rounded-lg bg-black/25 p-3 text-[10.5px] leading-relaxed text-paper/55 ring-1 ring-inset ring-white/5">
        <p><kbd className="kbd">↵</kbd> end the day · <kbd className="kbd">1–6</kbd> auto-deploy · <kbd className="kbd">E</kbd> squad select · <kbd className="kbd">N</kbd> scout · <kbd className="kbd">X</kbd> repair</p>
        <p>Squad screen: <kbd className="kbd">1–9</kbd> toggle · <kbd className="kbd">A</kbd> auto-pick · <kbd className="kbd">↵</kbd> deploy · Battle: <kbd className="kbd">1–5</kbd> action</p>
        <p><kbd className="kbd">F</kbd> farm · <kbd className="kbd">T</kbd> tea · <kbd className="kbd">D</kbd> dōjō · <kbd className="kbd">W</kbd> tower · <kbd className="kbd">S</kbd> shrine · <kbd className="kbd">H</kbd> hall</p>
        <p><kbd className="kbd">Space</kbd> pause · <kbd className="kbd">M</kbd> mute · touch & swipe fully supported</p>
      </div>
    </Shell>
  );
}

export function GameOverOverlay({
  s,
  scores,
  highlight,
  name,
  onRestart,
  onTitle,
}: {
  s: GameState;
  scores: ScoreEntry[];
  highlight: number;
  name: string;
  onRestart: () => void;
  onTitle: () => void;
}) {
  const stats: [string, string][] = [
    ["SCORE", s.score.toLocaleString()],
    ["DAYS", String(s.day)],
    ["MISSIONS", String(s.stats.done)],
    ["RAIDS HELD", String(s.stats.raids)],
    ["GOLD EARNED", Math.floor(s.stats.earned).toLocaleString()],
    ["PROMOTIONS", String(s.stats.promos)],
  ];
  return (
    <Shell kanji="終">
      <div className="text-center">
        <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-b from-[#e2452f] to-[#7a1408] font-display text-2xl font-black text-[#ffe9b8] shadow-[0_0_30px_rgba(226,69,47,0.45)]">
          終
        </span>
        <h2 className="mt-2 font-display text-[21px] font-black tracking-[0.12em] text-paper/95 sm:text-2xl">
          THE VILLAGE HAS FALLEN
        </h2>
        <p className="mt-1 flex items-center justify-center gap-1.5 text-[11px] text-paper/50">
          <Sparkles size={11} className="text-gold" /> recorded as <b className="text-paper/80">{name}</b>
        </p>
      </div>

      <div className="mt-4 grid grid-cols-3 gap-1.5">
        {stats.map(([k, v]) => (
          <div key={k} className="rounded-lg bg-black/25 px-2 py-1.5 text-center ring-1 ring-inset ring-white/5">
            <p className="text-[8.5px] font-bold tracking-[0.2em] text-paper/40">{k}</p>
            <p className="truncate text-[15px] font-black tabular-nums text-[#ffe9b8]">{v}</p>
          </div>
        ))}
      </div>

      <div className="mt-3">
        <ScoreTable scores={scores} highlight={highlight} />
      </div>

      <div className="mt-4 grid grid-cols-2 gap-2">
        <button onClick={onTitle} className="btn-ghost h-11 rounded-xl text-[12px] font-black tracking-widest">
          TITLE
        </button>
        <button onClick={onRestart} autoFocus className="btn-primary flex h-11 items-center justify-center gap-2 rounded-xl text-[13px] font-black tracking-widest">
          <RotateCcw size={15} /> INSTANT RESTART <kbd className="kbd">R</kbd>
        </button>
      </div>
    </Shell>
  );
}
