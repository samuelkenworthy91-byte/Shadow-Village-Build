import { useMemo } from "react";
import { ChevronsRight } from "lucide-react";
import type { GameState, Ninja } from "../game/types";
import { BUILDINGS } from "../game/content";
import NinjaSprite from "./NinjaSprite";
import { cn } from "../utils/cn";

const DISPLAY_ORDER = ["tea", "farm", "hall", "dojo", "tower", "shrine"] as const;

export default function Scene({ s, onEndDay, busy }: { s: GameState; onEndDay: () => void; busy: boolean }) {
  const stars = useMemo(
    () =>
      Array.from({ length: 30 }, (_, i) => ({
        left: (i * 53 + 7) % 100,
        top: (i * 29 + 3) % 38,
        d: (i % 5) * 0.45,
        sz: 1 + (i % 3) * 0.7,
      })),
    []
  );
  const built = DISPLAY_ORDER.filter((t) => s.b[t] > 0);
  const home = s.ninjas.filter((n) => n.status !== "mission");
  const danger = s.threat >= 80;

  return (
    <section id="scene-box" className="relative h-[23dvh] shrink-0 overflow-hidden rounded-xl ring-1 ring-white/10 sm:h-[26dvh] lg:h-[30dvh]">
      <img src="/bg-village.jpg" alt="" draggable={false} className="absolute inset-0 h-full w-full select-none object-cover" />
      {/* gentle warm haze + drifting motes, tuned for the watercolour art */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#2a3550]/10 via-transparent to-[#3a2a1e]/20" />
      <div className="absolute inset-0">
        {stars.map((st, i) => (
          <span
            key={i}
            className="twinkle absolute rounded-full bg-[#fff6de]"
            style={{ left: `${st.left}%`, top: `${40 + (st.top % 45)}%`, width: st.sz + 0.6, height: st.sz + 0.6, animationDelay: `${st.d}s`, opacity: 0.5 }}
          />
        ))}
      </div>
      <div className="pointer-events-none absolute inset-0" style={{ boxShadow: "inset 0 0 60px 14px rgba(58,42,30,0.28)" }} />
      <div className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-[#241d16]/55 to-transparent" />

      {/* hearts */}
      <div className="absolute left-2.5 top-2.5 flex gap-1">
        {Array.from({ length: s.hpMax }, (_, i) => (
          <svg key={i} width="15" height="15" viewBox="0 0 24 24" className={cn("drop-shadow-[0_1px_3px_rgba(0,0,0,0.8)]", i < s.hp ? "text-[#ff5a66]" : "text-white/15")}>
            <path fill="currentColor" d="M12 21c-4.8-3.6-9-6.9-9-11.1C3 6.9 5.2 5 7.6 5c1.7 0 3.2.9 4.4 2.7C13.2 5.9 14.7 5 16.4 5 18.8 5 21 6.9 21 9.9c0 4.2-4.2 7.5-9 11.1z" />
          </svg>
        ))}
      </div>

      {/* threat */}
      <div className="absolute right-2.5 top-2.5 flex items-center gap-1.5">
        <span className={cn("font-display text-[11px] font-bold", danger ? "text-[#ff7a5c]" : "text-paper/60")}>襲</span>
        <div className="h-1.5 w-20 overflow-hidden rounded-full bg-black/50 ring-1 ring-white/10 sm:w-28">
          <div
            className={cn("h-full rounded-full transition-[width] duration-500", danger ? "bg-gradient-to-r from-[#e2452f] to-[#ff7a5c]" : "bg-[#7a6a9e]")}
            style={{ width: `${Math.min(100, s.threat)}%` }}
          />
        </div>
        {danger && <span className="animate-pulse text-[9px] font-bold tracking-widest text-[#ff7a5c]">RAID</span>}
      </div>

      {/* buildings */}
      <div className="absolute inset-x-0 bottom-1 flex items-end justify-center gap-2 px-2 sm:gap-3">
        {built.map((t) => {
          const meta = BUILDINGS[t];
          const lvl = s.b[t];
          return (
            <div key={`${t}-${lvl}`} className={cn("building pop-in", t === "hall" && "scale-110")} style={{ "--c": meta.color } as React.CSSProperties}>
              <div className="b-roof" />
              <div className="b-body"><span className="b-kanji">{meta.kanji}</span></div>
              <div className="b-pips">
                {Array.from({ length: meta.max }, (_, i) => (
                  <i key={i} className={i < lvl ? "on" : ""} />
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* villagers */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-14">
        {home.slice(0, 8).map((n: Ninja, i: number) => (
          <div
            key={n.id}
            className={cn("walker absolute bottom-0", n.status === "injured" && "hurt")}
            style={{ left: `${6 + ((i * 12 + Math.floor(n.seed * 19) % 6) % 84)}%`, animationDelay: `${-n.seed * 2.4}s` }}
          >
            <NinjaSprite n={n} h={50} crop="full" grey={n.status === "injured"} />
          </div>
        ))}
      </div>

      {/* END DAY */}
      <button
        onClick={onEndDay}
        disabled={busy}
        className="end-day-btn absolute bottom-2 right-2 flex h-11 items-center gap-1.5 rounded-xl px-3 text-[12px] font-black tracking-wider sm:h-12 sm:px-4 sm:text-[13px]"
      >
        <span className="font-display text-[15px]">次</span>
        END DAY
        <ChevronsRight size={16} />
        <kbd className="kbd">↵</kbd>
      </button>
    </section>
  );
}
