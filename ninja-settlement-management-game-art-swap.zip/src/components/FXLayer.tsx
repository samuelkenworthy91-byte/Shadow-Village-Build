import { useEffect, useRef, useState } from "react";

type PType = "coin" | "smoke" | "spark" | "petal" | "star";
export type BurstType = PType;

interface P {
  x: number; y: number; vx: number; vy: number;
  life: number; max: number; size: number;
  rot: number; vr: number; type: PType; g: number; sway: number;
}

interface Fly {
  id: number; x: number; y: number; color: string;
}

// Global imperative FX API — assigned by FXLayer on mount.
export const fx = {
  burst(_x: number, _y: number, _t: BurstType, _n = 14) {},
  shake(_px: number) {},
  fly(_x: number, _y: number, _color: string) {},
};

let flyId = 1;

const R = Math.random;

export default function FXLayer({ ambient }: { ambient: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const parts = useRef<P[]>([]);
  const shakeMag = useRef(0);
  const lastBurst = useRef(0);
  const amb = useRef(ambient);
  amb.current = ambient;
  const [flies, setFlies] = useState<Fly[]>([]);

  useEffect(() => {
    fx.burst = (x, y, type, n = 14) => {
      const arr = parts.current;
      const now = performance.now();
      if (now - lastBurst.current < 30 && arr.length > 160) return;
      lastBurst.current = now;
      for (let i = 0; i < n; i++) {
        const a = R() * Math.PI * 2;
        const sp = 0.4 + R() * 1.6;
        if (type === "coin") {
          arr.push({ x, y, vx: Math.cos(a) * 2.6 * sp, vy: -2 - R() * 4.2, g: 0.26, life: 0, max: 650 + R() * 480, size: 2.6 + R() * 3, rot: R() * 7, vr: (R() - 0.5) * 0.6, type, sway: 0 });
        } else if (type === "smoke") {
          arr.push({ x: x + (R() - 0.5) * 14, y: y + (R() - 0.5) * 10, vx: (R() - 0.5) * 0.8, vy: -0.3 - R() * 0.9, g: -0.008, life: 0, max: 700 + R() * 500, size: 5 + R() * 9, rot: 0, vr: 0, type, sway: 0 });
        } else if (type === "spark") {
          arr.push({ x, y, vx: Math.cos(a) * 4.4 * sp, vy: Math.sin(a) * 4.4 * sp - 1, g: 0.16, life: 0, max: 380 + R() * 320, size: 1.6 + R() * 1.6, rot: 0, vr: 0, type, sway: 0 });
        } else if (type === "star") {
          arr.push({ x: x + (R() - 0.5) * 30, y: y + (R() - 0.5) * 24, vx: Math.cos(a) * 1.6 * sp, vy: -0.6 - R() * 1.8, g: 0.03, life: 0, max: 600 + R() * 500, size: 2.5 + R() * 3.4, rot: R() * 7, vr: (R() - 0.5) * 0.3, type, sway: 0 });
        } else {
          // petal
          arr.push({ x, y, vx: (R() - 0.5) * 2.4, vy: -0.4 - R() * 2.2, g: 0.05, life: 0, max: 1200 + R() * 900, size: 3 + R() * 3.4, rot: R() * 7, vr: (R() - 0.5) * 0.25, type, sway: R() * 7 });
        }
      }
      if (arr.length > 240) arr.splice(0, arr.length - 240);
    };
    fx.shake = (px) => {
      shakeMag.current = Math.max(shakeMag.current, px);
    };
    fx.fly = (x, y, color) => {
      const id = flyId++;
      setFlies((f) => [...f, { id, x, y, color }]);
      window.setTimeout(() => setFlies((f) => f.filter((q) => q.id !== id)), 980);
    };

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let w = 0, h = 0, dpr = 1;
    const resize = () => {
      dpr = Math.min(2, window.devicePixelRatio || 1);
      w = canvas.clientWidth;
      h = canvas.clientHeight;
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    const coarse = window.matchMedia("(pointer:coarse)").matches;
    let raf = 0;
    let last = performance.now();
    let petalT = 0;

    const draw = (p: P, alpha: number) => {
      ctx.save();
      ctx.translate(p.x, p.y);
      if (p.type === "coin") {
        ctx.rotate(0);
        const sx = Math.abs(Math.cos(p.rot)) * 0.7 + 0.3;
        ctx.scale(sx, 1);
        ctx.globalAlpha = alpha;
        ctx.beginPath();
        ctx.arc(0, 0, p.size, 0, Math.PI * 2);
        ctx.fillStyle = "#f6c945";
        ctx.fill();
        ctx.lineWidth = 1;
        ctx.strokeStyle = "#9c7417";
        ctx.stroke();
      } else if (p.type === "smoke") {
        const grow = 1 + (1 - p.life / p.max) * 1.6;
        ctx.globalAlpha = alpha * 0.4;
        ctx.beginPath();
        ctx.arc(0, 0, p.size * grow, 0, Math.PI * 2);
        ctx.fillStyle = "#c9c4d6";
        ctx.fill();
      } else if (p.type === "spark") {
        ctx.globalAlpha = alpha;
        ctx.strokeStyle = "#ff7a4d";
        ctx.lineWidth = p.size * 0.7;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(-p.vx * 2.4, -p.vy * 2.4);
        ctx.stroke();
      } else if (p.type === "star") {
        ctx.rotate(p.rot);
        ctx.globalAlpha = alpha;
        ctx.fillStyle = "#fff3c2";
        const s = p.size;
        ctx.beginPath();
        ctx.moveTo(0, -s);
        ctx.quadraticCurveTo(0, 0, s, 0);
        ctx.quadraticCurveTo(0, 0, 0, s);
        ctx.quadraticCurveTo(0, 0, -s, 0);
        ctx.quadraticCurveTo(0, 0, 0, -s);
        ctx.fill();
      } else {
        // petal
        ctx.rotate(p.rot);
        ctx.globalAlpha = alpha * 0.9;
        ctx.fillStyle = "#f4aec9";
        ctx.beginPath();
        ctx.ellipse(0, 0, p.size, p.size * 0.55, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "rgba(214,110,150,0.55)";
        ctx.beginPath();
        ctx.ellipse(p.size * 0.25, 0, p.size * 0.35, p.size * 0.2, 0, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    };

    const loop = (now: number) => {
      const dt = Math.min(50, now - last);
      last = now;
      const step = dt / 16.667;

      // ambient sakura petals
      if (amb.current && w > 0) {
        petalT += dt;
        const rate = coarse ? 300 : 190;
        if (petalT > rate) {
          petalT = 0;
          const arr = parts.current;
          if (arr.length < (coarse ? 90 : 150)) {
            arr.push({
              x: R() * w, y: -12, vx: -0.2 - R() * 0.5, vy: 0.45 + R() * 0.6,
              g: 0.004, life: 0, max: 9000, size: 2.6 + R() * 3.2,
              rot: R() * 7, vr: (R() - 0.5) * 0.06, type: "petal", sway: R() * 7,
            });
          }
        }
      }

      // screen shake
      const el = document.getElementById("shake-root");
      if (el) {
        if (shakeMag.current > 0.25) {
          const m = shakeMag.current;
          el.style.transform = `translate3d(${(R() * 2 - 1) * m}px, ${(R() * 2 - 1) * m * 0.65}px, 0)`;
          shakeMag.current *= 0.86;
        } else if (el.style.transform) {
          el.style.transform = "";
          shakeMag.current = 0;
        }
      }

      // simulate + draw
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);
      const arr = parts.current;
      for (let i = arr.length - 1; i >= 0; i--) {
        const p = arr[i];
        p.life += dt;
        if (p.life >= p.max || p.y > h + 30) {
          arr.splice(i, 1);
          continue;
        }
        p.vy += p.g * step;
        p.x += p.vx * step;
        p.y += p.vy * step;
        if (p.sway || p.type === "petal") p.x += Math.sin((now + p.sway * 1000) * 0.0022) * 0.5;
        p.rot += p.vr * step;
        draw(p, Math.min(1, (p.max - p.life) / (p.max * 0.35)));
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      const el = document.getElementById("shake-root");
      if (el) el.style.transform = "";
    };
  }, []);

  return (
    <div className="pointer-events-none fixed inset-0 z-40">
      <canvas ref={canvasRef} className="h-full w-full" />
      {flies.map((f) => (
        <div key={f.id} className="fly-ninja absolute" style={{ left: f.x, top: f.y }}>
          <svg width="30" height="30" viewBox="0 0 32 32" aria-hidden>
            <path
              d="M16 2l4.4 9.2L30 16l-9.6 4.8L16 30l-4.4-9.2L2 16l9.6-4.8z"
              fill={f.color}
              stroke="#12141f"
              strokeWidth="1.4"
              strokeLinejoin="round"
            />
            <circle cx="16" cy="16" r="3" fill="#12141f" />
            <circle cx="16" cy="16" r="1.3" fill={f.color} />
          </svg>
        </div>
      ))}
    </div>
  );
}
