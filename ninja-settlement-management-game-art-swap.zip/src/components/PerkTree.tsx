import { Check, Lock, Sparkles } from "lucide-react";
import type { Ninja } from "../game/types";
import { pendingPerks, perkTree, tiersUnlocked } from "../game/perks";
import { cn } from "../utils/cn";

export default function PerkTree({ n, onPick }: { n: Ninja; onPick: (id: string, r: DOMRect) => void }) {
  const tree = perkTree(n);
  const unlockedTiers = tiersUnlocked(n.level);
  const pending = pendingPerks(n);
  // the tier currently being chosen = number already taken
  const activeTier = n.perks.length;

  return (
    <div>
      <div className="mb-2 flex items-center gap-2">
        <p className="text-[10px] font-bold tracking-[0.2em] text-paper/45">TECHNIQUE TREE</p>
        <span
          className={cn(
            "rounded-md px-1.5 py-[2px] text-[9.5px] font-black tracking-wider",
            pending > 0 ? "animate-pulse bg-[#b46ae0]/25 text-[#cf9bf0] ring-1 ring-inset ring-[#b46ae0]/50" : "bg-black/30 text-paper/35"
          )}
        >
          {pending > 0 ? `${pending} NODE${pending > 1 ? "S" : ""} TO LEARN` : `NEXT AT LV ${(unlockedTiers + 1) * 2}`}
        </span>
      </div>

      <div className="space-y-2">
        {tree.map((row, t) => {
          const taken = n.perks[t];
          const isActive = t === activeTier && pending > 0;
          const locked = t > activeTier || (t === activeTier && pending === 0);
          return (
            <div key={t} className="relative">
              {t > 0 && <div className="absolute -top-2 left-4 h-2 w-px bg-white/12" />}
              <div className="mb-1 flex items-center gap-1.5">
                <span
                  className={cn(
                    "grid h-4 w-4 place-items-center rounded-full text-[8px] font-black",
                    taken ? "bg-jade text-[#0d0e1a]" : isActive ? "bg-gold text-[#2b2118]" : "bg-white/10 text-paper/40"
                  )}
                >
                  {taken ? <Check size={9} strokeWidth={4} /> : t + 1}
                </span>
                <span className={cn("text-[9px] font-bold tracking-[0.18em]", isActive ? "text-gold" : "text-paper/30")}>
                  LEVEL {(t + 1) * 2}
                </span>
                {isActive && <span className="text-[9px] font-black tracking-wider text-gold">— CHOOSE ONE</span>}
              </div>

              <div className="grid grid-cols-1 gap-1 min-[420px]:grid-cols-3">
                {row.map((p) => {
                  const chosen = taken === p.id;
                  const dimmed = !!taken && !chosen;
                  return (
                    <button
                      key={p.id}
                      disabled={!isActive}
                      onClick={(e) => onPick(p.id, e.currentTarget.getBoundingClientRect())}
                      className={cn(
                        "relative flex flex-col rounded-lg p-1.5 text-left ring-1 transition",
                        chosen && "bg-jade/12 ring-jade/50",
                        dimmed && "bg-black/20 opacity-30 ring-white/5",
                        isActive && !chosen && "bg-black/30 ring-white/10 hover:bg-black/45 hover:ring-gold/50 active:scale-[0.98] cursor-pointer",
                        locked && !taken && "bg-black/20 opacity-45 ring-white/5"
                      )}
                      style={chosen ? { boxShadow: `inset 0 0 0 1px ${p.color}66` } : undefined}
                    >
                      <span className="flex items-center gap-1">
                        <span
                          className="grid h-5 w-5 shrink-0 place-items-center rounded font-display text-[11px] font-black"
                          style={{ backgroundColor: `${p.color}26`, color: p.color }}
                        >
                          {p.kanji}
                        </span>
                        <span className="truncate text-[10px] font-black text-paper/90">{p.name}</span>
                        {p.kind === "signature" && <Sparkles size={9} className="shrink-0 text-gold" />}
                        {locked && !taken && <Lock size={9} className="ml-auto shrink-0 text-paper/30" />}
                      </span>
                      <span className="mt-1 line-clamp-3 text-[9px] leading-snug text-paper/50">{p.desc}</span>
                      {p.kind === "signature" && (
                        <span className="mt-1 rounded bg-black/40 px-1 py-[1px] text-[8px] font-bold tracking-wider text-gold/80">
                          奥義 UNLOCK
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
