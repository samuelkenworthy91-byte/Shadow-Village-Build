import { Coins, HeartPulse, Wheat } from "lucide-react";
import type { Bld, GameState } from "../game/types";
import { BUILD_ORDER, BUILDINGS, REPAIR_COST } from "../game/content";
import { cn } from "../utils/cn";

export default function BuildMenu({
  s,
  className,
  onBuild,
  onRepair,
}: {
  s: GameState;
  className?: string;
  onBuild: (t: Bld, r: DOMRect) => void;
  onRepair: (r: DOMRect) => void;
}) {
  return (
    <section className={cn("panel flex min-h-0 flex-col", className)}>
      <header className="panel-h">
        <span className="p-kanji">築</span>
        <span className="panel-title">Build</span>
        <span className="ml-auto rounded-md bg-black/30 px-1.5 py-0.5 text-[10px] font-semibold text-paper/60">
          1 action each
        </span>
      </header>
      <div className="scroller min-h-0 flex-1 overflow-y-auto p-2">
        <div className="grid grid-cols-1 gap-1.5 min-[420px]:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
          {BUILD_ORDER.map((t) => {
            const meta = BUILDINGS[t];
            const lvl = s.b[t];
            const maxed = lvl >= meta.max;
            const cost = maxed ? null : meta.costs[lvl];
            const afford = cost ? s.gold >= cost.gold && s.rice >= cost.rice : false;
            return (
              <article key={t} className="flex items-center gap-2 rounded-lg bg-black/25 p-1.5 ring-1 ring-inset ring-white/5">
                <span
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-lg font-display text-[17px] font-black text-[#0d0e1a]"
                  style={{ background: `linear-gradient(180deg, ${meta.color}, color-mix(in srgb, ${meta.color} 60%, black))`, boxShadow: `0 0 12px ${meta.color}44` }}
                >
                  {meta.kanji}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className="truncate text-[11.5px] font-bold text-paper/90">{meta.name}</span>
                    <span className="flex gap-[3px]">
                      {Array.from({ length: meta.max }, (_, i) => (
                        <i key={i} className={cn("h-[5px] w-[5px] rounded-full", i < lvl ? "bg-gold" : "bg-white/15")} />
                      ))}
                    </span>
                  </div>
                  <p className="truncate text-[9.5px] font-medium text-paper/45">{meta.desc}</p>
                  {!maxed && cost && (
                    <p className="mt-0.5 flex items-center gap-2 text-[10px] font-bold tabular-nums">
                      <span className={cn("inline-flex items-center gap-0.5", s.gold >= cost.gold ? "text-gold" : "text-vermil")}>
                        <Coins size={9} />{cost.gold}
                      </span>
                      {cost.rice > 0 && (
                        <span className={cn("inline-flex items-center gap-0.5", s.rice >= cost.rice ? "text-[#8fce6a]" : "text-vermil")}>
                          <Wheat size={9} />{cost.rice}
                        </span>
                      )}
                    </p>
                  )}
                </div>
                <button
                  disabled={maxed || !afford}
                  onClick={(e) => onBuild(t, e.currentTarget.getBoundingClientRect())}
                  className="btn-ink relative h-8 w-[64px] shrink-0 rounded-lg text-[10px] font-black tracking-wider"
                >
                  {maxed ? "MAX" : lvl === 0 ? "BUILD" : "UPGRADE"}
                  {!maxed && <kbd className="kbd">{meta.hotkey}</kbd>}
                </button>
              </article>
            );
          })}

          {/* repair */}
          {(() => {
            const missing = s.hpMax - s.hp;
            const locked = s.ap < 1;
            const afford = s.gold >= REPAIR_COST.gold && s.rice >= REPAIR_COST.rice;
            const ok = missing > 0 && !locked && afford;
            return (
              <article className="flex items-center gap-2 rounded-lg bg-black/25 p-1.5 ring-1 ring-inset ring-white/5">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-gradient-to-b from-[#ff5a66] to-[#a11d2e] text-white shadow-[0_0_12px_rgba(255,90,102,0.3)]">
                  <HeartPulse size={16} />
                </span>
                <div className="min-w-0 flex-1">
                  <span className="block truncate text-[11.5px] font-bold text-paper/90">Repair Walls</span>
                  <p className="truncate text-[9.5px] font-medium text-paper/45">
                    {missing === 0 ? "Village at full strength" : locked ? "No actions left today" : `1 action · ${REPAIR_COST.gold} gold · ${REPAIR_COST.rice} rice`}
                  </p>
                </div>
                <button
                  disabled={!ok}
                  onClick={(e) => onRepair(e.currentTarget.getBoundingClientRect())}
                  className="btn-ink relative h-8 w-[64px] shrink-0 rounded-lg text-[10px] font-black tracking-wider"
                >
                  REPAIR
                  <kbd className="kbd">X</kbd>
                </button>
              </article>
            );
          })()}
        </div>
      </div>
    </section>
  );
}
