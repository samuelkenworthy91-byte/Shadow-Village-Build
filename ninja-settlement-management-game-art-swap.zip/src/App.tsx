import { useCallback, useEffect, useReducer, useRef, useState } from "react";
import FXLayer, { fx } from "./components/FXLayer";
import HUD from "./components/HUD";
import Scene from "./components/Scene";
import MissionBoard from "./components/MissionBoard";
import Roster from "./components/Roster";
import BuildMenu from "./components/BuildMenu";
import SquadModal from "./components/SquadModal";
import NinjaDetail from "./components/NinjaDetail";
import ScoutModal from "./components/ScoutModal";
import BattleScreen from "./components/BattleScreen";
import ReportModal from "./components/ReportModal";
import { GameOverOverlay, PauseOverlay, StartOverlay } from "./components/Overlays";
import * as eng from "./game/engine";
import * as bat from "./game/battle";
import { audio } from "./game/audio";
import { getPlayerName, loadScores, setPlayerName, submitScore, type ScoreEntry } from "./game/scores";
import { RANK_META, SKILL_META } from "./game/content";
import type { BAction, Bld, Ev, GameState, Skill } from "./game/types";
import { cn } from "./utils/cn";

type Tab = "missions" | "ninjas" | "build";
interface Floater { id: number; x: number; y: number; txt: string; kind: string }

let fid = 1;

const HINTS = [
  "Actions are limited each day — spend them, then end the day",
  "Missions take days: deploy, then advance the calendar",
  "Level-ups grant skill points — high potential grants more",
  "Promote ninja to unlock B, A and S-rank contracts",
  "Keep shinobi home when the raid meter is high",
];

export default function App() {
  const sRef = useRef<GameState>(null as unknown as GameState);
  if (!sRef.current) sRef.current = eng.createState("menu");
  const s = sRef.current;
  const [, force] = useReducer((x: number) => x + 1, 0);

  const [tab, setTab] = useState<Tab>("missions");
  const [squadFor, setSquadFor] = useState<number | null>(null);
  const [detailFor, setDetailFor] = useState<number | null>(null);
  const [floaters, setFloaters] = useState<Floater[]>([]);
  const [scores, setScores] = useState<ScoreEntry[]>(() => loadScores());
  const [highlight, setHighlight] = useState(-1);
  const [name, setName] = useState(() => getPlayerName());
  const [mutedUi, setMutedUi] = useState(() => audio.isMuted());
  const [hitFlash, setHitFlash] = useState(0);
  const [dayWipe, setDayWipe] = useState(0);
  const [busy, setBusy] = useState(false);

  const tabRef = useRef(tab);
  tabRef.current = tab;
  const nameRef = useRef(name);
  nameRef.current = name;
  const modalRef = useRef(false);
  modalRef.current = squadFor !== null || detailFor !== null || s.scout !== null;

  const floater = (x: number, y: number, txt: string, kind: string) => {
    const id = fid++;
    setFloaters((f) => [...f.slice(-14), { id, x, y, txt, kind }]);
    window.setTimeout(() => setFloaters((f) => f.filter((q) => q.id !== id)), 1300);
  };

  const handleEvs = useCallback((evs: Ev[]) => {
    let delay = 0;
    for (const e of evs) {
      switch (e.type) {
        case "mission_success": {
          const el = document.getElementById("hud-gold");
          if (el) {
            const r = el.getBoundingClientRect();
            fx.burst(r.left + r.width / 2, r.top + r.height / 2, "coin", 16);
          }
          fx.shake(3);
          audio.coin();
          window.setTimeout(() => audio.success(), 70);
          floater(34 + Math.random() * 28, 26 + delay, `+${e.gold} 両`, "gold");
          delay += 4;
          break;
        }
        case "mission_fail":
          fx.shake(6);
          audio.fail();
          fx.burst(window.innerWidth * 0.5, window.innerHeight * 0.3, "smoke", 12);
          floater(34 + Math.random() * 28, 30, "SQUAD ROUTED", "bad");
          break;
        case "ninja_level":
          audio.level();
          fx.burst(window.innerWidth * 0.5, window.innerHeight * 0.32, "star", 10);
          floater(38 + Math.random() * 24, 42, `${e.name} → LV ${e.level} (+${e.sp} SP)`, "good");
          break;
        case "promoted":
          audio.raidWin();
          fx.shake(6);
          fx.burst(window.innerWidth * 0.5, window.innerHeight * 0.3, "star", 26);
          floater(50, 34, `${e.kanji} ${e.name} → ${RANK_META[e.rank as keyof typeof RANK_META].name.toUpperCase()}`, "great");
          break;
        case "trained":
          audio.level();
          floater(50, 46, `${SKILL_META[e.skill as Skill].name} +${e.gain}`, "good");
          break;
        case "raid_win":
          audio.raidWin();
          fx.burst(window.innerWidth * 0.5, window.innerHeight * 0.28, "petal", 26);
          floater(48, 32, `VILLAGE HELD +${e.pts}`, "great");
          break;
        case "raid_loss":
        case "raid_undefended":
          audio.raidHit();
          fx.shake(18);
          setHitFlash(Date.now());
          floater(48, 30, `−${e.dmg ?? 2} ♥  BREACH!`, "bad");
          break;
        case "raid_start":
          audio.raidHit();
          fx.shake(14);
          break;
        case "gameover": {
          audio.over();
          fx.shake(26);
          setSquadFor(null);
          setDetailFor(null);
          const r = submitScore(nameRef.current, sRef.current.score, sRef.current.day, sRef.current.stats.done);
          setScores(r.list);
          setHighlight(r.idx);
          break;
        }
        case "hungry":
          if (e.on) floater(46, 22, "THE VILLAGE IS HUNGRY", "bad");
          break;
        case "recruit":
          audio.recruit();
          floater(70, 56, `${e.name} JOINS`, "good");
          break;
        case "perk":
          floater(50, 40, `${e.kanji} ${e.perk} LEARNED`, e.signature ? "great" : "good");
          break;
        case "legend_found":
          window.setTimeout(() => {
            audio.raidWin();
            fx.burst(window.innerWidth * 0.5, window.innerHeight * 0.3, "star", 24);
            floater(50, 18, "A UNIQUE SHINOBI HAS COME", "great");
          }, 220);
          break;
        default:
          break;
      }
    }
  }, []);

  // FX-only rAF loop lives in FXLayer; no simulation clock.
  useEffect(() => {
    if (!hitFlash) return;
    const t = window.setTimeout(() => setHitFlash(0), 460);
    return () => window.clearTimeout(t);
  }, [hitFlash]);

  /* ---------------- lifecycle ---------------- */

  const begin = () => {
    audio.unlock();
    if (sRef.current.phase === "menu") {
      sRef.current.phase = "playing";
      audio.start();
      force();
    }
  };

  const restart = () => {
    sRef.current = eng.createState("playing");
    setTab("missions");
    setHighlight(-1);
    setSquadFor(null);
    setDetailFor(null);
    audio.unlock();
    audio.start();
    fx.burst(window.innerWidth * 0.5, window.innerHeight * 0.3, "petal", 18);
    force();
  };

  const toTitle = () => {
    sRef.current = eng.createState("menu");
    setScores(loadScores());
    setHighlight(-1);
    setTab("missions");
    force();
  };

  const pauseToggle = () => {
    const st = sRef.current;
    if (st.phase === "playing" || st.phase === "paused") {
      eng.togglePause(st);
      audio.click();
      force();
    }
  };

  const muteToggle = () => {
    const next = !audio.isMuted();
    audio.setMuted(next);
    setMutedUi(next);
  };

  /* ---------------- turn actions ---------------- */

  const endDay = () => {
    const st = sRef.current;
    if (st.phase !== "playing" || busy) return;
    setBusy(true);
    setDayWipe(Date.now());
    audio.build();
    const evs: Ev[] = [];
    window.setTimeout(() => {
      const raid = eng.advanceDay(st, evs);
      handleEvs(evs);
      fx.burst(window.innerWidth * 0.5, 60, "petal", 10);
      if (raid) audio.raidHit();
      setBusy(false);
      force();
    }, 260);
  };

  const dismissReport = () => {
    const st = sRef.current;
    const r = st.reports.shift();
    audio.click();
    if (r?.win) fx.burst(window.innerWidth * 0.5, window.innerHeight * 0.4, "coin", 10);
    force();
  };

  const runDeploy = (missionId: number, ids: number[], r?: DOMRect) => {
    const st = sRef.current;
    const evs: Ev[] = [];
    if (eng.deploy(st, missionId, ids, evs)) {
      audio.dispatch();
      const rect = r ?? fallbackRect();
      fx.burst(rect.left + rect.width * 0.3, rect.top + rect.height / 2, "smoke", 12);
      ids.forEach((id, i) => {
        window.setTimeout(() => fx.fly(rect.left - i * 14, rect.top - 6, colorOf(id)), i * 90);
      });
      setSquadFor(null);
    } else {
      fx.shake(3);
      audio.click();
      floater(50, 44, "NO SHINOBI AVAILABLE", "bad");
    }
    handleEvs(evs.filter((e) => e.type !== "deploy"));
    force();
  };

  const quickDeploy = (missionId: number, r?: DOMRect) => {
    const st = sRef.current;
    const m = st.missions.find((x) => x.id === missionId);
    if (!m) return;
    runDeploy(missionId, eng.autoSquad(st, m), r);
  };

  const noAp = () => {
    audio.click();
    fx.shake(3);
    const el = document.getElementById("hud-ap");
    if (el) {
      const r = el.getBoundingClientRect();
      fx.burst(r.left + r.width / 2, r.top + r.height / 2, "smoke", 6);
    }
    floater(50, 40, "NO ACTIONS LEFT — END THE DAY", "bad");
  };

  const doBuild = (t: Bld, r?: DOMRect) => {
    const st = sRef.current;
    if (st.ap < 1) return noAp();
    const evs: Ev[] = [];
    if (eng.build(st, t, evs)) {
      audio.build();
      const rect = r ?? fallbackRect();
      fx.burst(rect.left + rect.width / 2, rect.top + rect.height / 2, "spark", 8);
      fx.shake(2.5);
    } else {
      audio.click();
      fx.shake(2);
    }
    handleEvs(evs);
    force();
  };

  const doScout = () => {
    const st = sRef.current;
    if (st.scout) return force();
    if (st.ap < 1) return noAp();
    const evs: Ev[] = [];
    if (eng.scout(st, evs)) audio.recruit();
    else {
      audio.click();
      fx.shake(2);
      floater(70, 56, "NEED GOLD / CAPACITY", "bad");
    }
    force();
  };

  const doPickScout = (id: number, r?: DOMRect) => {
    const evs: Ev[] = [];
    if (eng.pickScout(sRef.current, id, evs)) {
      const rect = r ?? fallbackRect();
      fx.burst(rect.left + rect.width / 2, rect.top + rect.height / 2, "star", 14);
      fx.shake(3);
    }
    handleEvs(evs);
    force();
  };

  const doRepair = (r?: DOMRect) => {
    const st = sRef.current;
    if (st.ap < 1) return noAp();
    const evs: Ev[] = [];
    if (eng.repair(st, evs)) {
      audio.repair();
      const rect = r ?? fallbackRect();
      fx.burst(rect.left + rect.width / 2, rect.top + rect.height / 2, "star", 8);
      floater(12, 14, "+1 ♥", "good");
    } else {
      audio.click();
      fx.shake(2);
    }
    handleEvs(evs);
    force();
  };

  const doTrain = (ninjaId: number, k: Skill, r?: DOMRect) => {
    const evs: Ev[] = [];
    if (eng.trainSkill(sRef.current, ninjaId, k, evs)) {
      const rect = r ?? fallbackRect();
      fx.burst(rect.left + rect.width / 2, rect.top + rect.height / 2, "spark", 10);
      fx.shake(2);
    } else audio.click();
    handleEvs(evs);
    force();
  };

  const doPerk = (ninjaId: number, perkId: string, r?: DOMRect) => {
    const evs: Ev[] = [];
    if (eng.choosePerk(sRef.current, ninjaId, perkId, evs)) {
      const rect = r ?? fallbackRect();
      fx.burst(rect.left + rect.width / 2, rect.top + rect.height / 2, "star", 18);
      fx.shake(4);
      audio.raidWin();
    } else audio.click();
    handleEvs(evs);
    force();
  };

  const doPromote = (ninjaId: number, r?: DOMRect) => {
    const evs: Ev[] = [];
    if (eng.promote(sRef.current, ninjaId, evs)) {
      const rect = r ?? fallbackRect();
      fx.burst(rect.left + rect.width / 2, rect.top + rect.height / 2, "star", 22);
    } else {
      audio.click();
      fx.shake(2);
    }
    handleEvs(evs);
    force();
  };

  /* ---------------- battle ---------------- */

  const battleStep = useCallback(() => {
    const st = sRef.current;
    const b = st.battle;
    if (!b || b.state === "won" || b.state === "lost") return;
    const u = bat.currentUnit(b);
    if (!u) {
      bat.nextTurn(b, st.b.tower);
      force();
      return;
    }
    if (u.foe) {
      b.state = "resolving";
      force();
      window.setTimeout(() => {
        const { action, target } = bat.enemyAction(b);
        const res = bat.doAction(b, action, target);
        if (res.kind === "crit" || res.kind === "attack") {
          audio.fail();
          fx.shake(res.kind === "crit" ? 12 : 6);
        } else if (res.kind === "jutsu") {
          audio.raidHit();
          fx.shake(10);
        }
        force();
        window.setTimeout(() => {
          bat.nextTurn(b, st.b.tower);
          force();
        }, 420);
      }, 480);
    }
  }, []);

  useEffect(() => {
    const b = s.battle;
    if (s.phase !== "battle" || !b) return;
    if (b.state === "choose") {
      const u = bat.currentUnit(b);
      if (u?.foe) battleStep();
    }
  });

  const playerAct = (action: BAction, target?: string) => {
    const st = sRef.current;
    const b = st.battle;
    if (!b || b.state !== "choose") return;
    const res = bat.doAction(b, action, target);
    if (res.kind === "crit") {
      audio.raidWin();
      fx.shake(14);
    } else if (res.kind === "jutsu") {
      audio.dispatch();
      fx.shake(9);
      fx.burst(window.innerWidth * 0.5, window.innerHeight * 0.25, "spark", 16);
    } else if (res.kind === "heal") {
      audio.level();
      fx.burst(window.innerWidth * 0.5, window.innerHeight * 0.6, "star", 10);
    } else if (res.kind === "attack") {
      audio.coin();
      fx.shake(5);
    } else audio.click();
    b.state = "resolving";
    force();
    window.setTimeout(() => {
      bat.nextTurn(b, st.b.tower);
      if (b.state === "won") audio.raidWin();
      if (b.state === "lost") audio.over();
      force();
    }, 430);
  };

  const battleAuto = () => {
    const b = sRef.current.battle;
    if (!b) return;
    const { action, target } = bat.autoPickAction(b);
    playerAct(action, target);
  };

  const battleFinish = () => {
    const evs: Ev[] = [];
    bat.finishBattle(sRef.current, evs);
    handleEvs(evs);
    force();
  };

  /* ---------------- keyboard ---------------- */

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const st = sRef.current;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") {
        if (e.key === "Enter") (e.target as HTMLInputElement).blur();
        return;
      }
      const k = e.key;
      if (st.reports.length > 0) {
        if (k === "Enter" || k === " " || k === "Escape") {
          e.preventDefault();
          dismissReport();
        }
        return;
      }
      if (st.phase === "battle") return; // BattleScreen owns the keys
      if (st.scout) {
        if (k >= "1" && k <= "3") {
          const c = st.scout[Number(k) - 1];
          if (c) doPickScout(c.id);
        } else if (k === "Escape") {
          eng.dismissScout(st);
          force();
        }
        return;
      }
      if (modalRef.current) {
        if (k === "m" || k === "M") muteToggle();
        if (k === "Escape") setDetailFor(null);
        return;
      }
      if (k === "Enter") {
        e.preventDefault();
        if (st.phase === "menu") begin();
        else if (st.phase === "over") restart();
        else if (st.phase === "paused") pauseToggle();
        else endDay();
        return;
      }
      if (k === " ") {
        e.preventDefault();
        if (st.phase === "menu") begin();
        else pauseToggle();
        return;
      }
      if (k === "Escape") {
        if (st.phase === "playing" || st.phase === "paused") pauseToggle();
        return;
      }
      if (k === "m" || k === "M") return muteToggle();
      if (st.phase === "over") {
        if (k === "r" || k === "R") restart();
        return;
      }
      if (st.phase !== "playing") return;

      if (k === "ArrowLeft" || k === "ArrowRight") {
        const order: Tab[] = ["missions", "ninjas", "build"];
        const i = order.indexOf(tabRef.current);
        setTab(order[(i + (k === "ArrowRight" ? 1 : order.length - 1)) % order.length]);
        audio.click();
        return;
      }
      if (k >= "1" && k <= "6") {
        const m = eng.openMissions(st)[Number(k) - 1];
        if (m) quickDeploy(m.id, document.getElementById(`mission-${m.id}`)?.getBoundingClientRect());
        return;
      }
      const lk = k.toLowerCase();
      if (lk === "e") {
        const m = eng.openMissions(st)[0];
        if (m) {
          setSquadFor(m.id);
          audio.click();
        }
        return;
      }
      const buildMap: Record<string, Bld> = { f: "farm", t: "tea", d: "dojo", w: "tower", s: "shrine", h: "hall" };
      if (buildMap[lk]) return doBuild(buildMap[lk]);
      if (lk === "n") doScout();
      if (lk === "x") doRepair();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ---------------- derived ---------------- */

  let hint = "";
  if (s.phase === "playing") {
    const open = eng.openMissions(s);
    const sp = s.ninjas.reduce((a, n) => a + n.sp, 0);
    const promoReady = s.ninjas.some((n) => eng.promoInfo(s, n).ready);
    if (s.hungry) hint = "The village is hungry — build rice paddies [F]";
    else if (sp > 0) hint = `${sp} unspent skill point${sp > 1 ? "s" : ""} — open a shinobi to train`;
    else if (promoReady) hint = "A shinobi is ready for their promotion exam";
    else if (s.threat >= 80) hint = "Raid imminent — keep your best cell at the village";
    else if (s.ap === 0) hint = "Out of actions — end the day to continue";
    else if (open.length > 0 && eng.readyNinjas(s).length > 0) hint = "Deploy a cell, then end the day to advance time";
    else hint = HINTS[(s.day - 1) % HINTS.length];
  }

  const openCount = eng.openMissions(s).length;
  const readyCount = eng.readyNinjas(s).length;
  const tabs: { id: Tab; kanji: string; label: string; badge: string }[] = [
    { id: "missions", kanji: "任", label: "Missions", badge: String(openCount) },
    { id: "ninjas", kanji: "忍", label: "Shinobi", badge: String(readyCount) },
    { id: "build", kanji: "築", label: "Build", badge: s.ap > 0 ? String(s.ap) : "" },
  ];

  const recentLog = s.log.slice(-4);

  return (
    <div className="fixed inset-0 select-none overflow-hidden bg-ink font-body text-paper" onPointerDown={() => audio.unlock()}>
      <FXLayer ambient={s.phase !== "paused"} />
      <div id="shake-root" className="relative z-10 h-full will-change-transform">
        <div className="mx-auto flex h-full max-w-6xl flex-col gap-2 px-2.5 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-[max(0.5rem,env(safe-area-inset-top))] sm:px-3">
          <HUD s={s} muted={mutedUi} onMute={muteToggle} onPause={pauseToggle} />
          <Scene s={s} onEndDay={endDay} busy={busy} />

          <nav className="flex h-10 shrink-0 gap-1.5 lg:hidden">
            {tabs.map((t) => (
              <button
                key={t.id}
                onClick={() => {
                  setTab(t.id);
                  audio.click();
                }}
                className={cn(
                  "flex flex-1 items-center justify-center gap-1.5 rounded-lg text-[11px] font-bold tracking-wider ring-1 ring-inset transition active:scale-[0.97]",
                  tab === t.id ? "bg-vermil/25 text-[#ffb4a4] ring-vermil/50" : "bg-[#151728]/85 text-paper/45 ring-white/10"
                )}
              >
                <span className="font-display">{t.kanji}</span>
                {t.label}
                {t.badge && <span className="rounded-md bg-black/40 px-1.5 py-0.5 text-[10px] tabular-nums">{t.badge}</span>}
              </button>
            ))}
          </nav>

          <div className="grid min-h-0 flex-1 grid-cols-1 gap-2 lg:grid-cols-3">
            <MissionBoard
              s={s}
              className={cn(tab !== "missions" && "max-lg:hidden")}
              onOpen={(id) => {
                setSquadFor(id);
                audio.click();
              }}
              onQuick={quickDeploy}
            />
            <Roster
              s={s}
              className={cn(tab !== "ninjas" && "max-lg:hidden")}
              onOpen={(id) => {
                setDetailFor(id);
                audio.click();
              }}
              onScout={doScout}
            />
            <BuildMenu s={s} className={cn(tab !== "build" && "max-lg:hidden")} onBuild={doBuild} onRepair={doRepair} />
          </div>

          <p className="h-4 shrink-0 truncate text-center text-[10px] font-medium tracking-wide text-paper/40">{hint}</p>
        </div>
      </div>

      {/* day chronicle */}
      {s.phase === "playing" && recentLog.length > 0 && (
        <div className="pointer-events-none fixed bottom-6 left-2 z-[44] hidden w-56 space-y-1 lg:block">
          {recentLog.map((l) => (
            <p
              key={l.id}
              className={cn(
                "log-line truncate rounded-md bg-black/55 px-2 py-1 text-[9.5px] font-semibold backdrop-blur-sm",
                l.kind === "great" && "text-gold",
                l.kind === "good" && "text-jade",
                l.kind === "bad" && "text-[#ff8a92]",
                l.kind === "info" && "text-paper/55"
              )}
            >
              {l.txt}
            </p>
          ))}
        </div>
      )}

      {dayWipe > 0 && <div key={dayWipe} className="day-wipe pointer-events-none fixed inset-0 z-[46]" onAnimationEnd={() => setDayWipe(0)} />}
      {hitFlash > 0 && <div key={hitFlash} className="hit-flash pointer-events-none fixed inset-0 z-30" />}

      <div className="pointer-events-none fixed inset-0 z-[45] overflow-hidden">
        {floaters.map((f) => (
          <span key={f.id} className={cn("floater font-display", `f-${f.kind}`)} style={{ left: `${f.x}%`, top: `${f.y}%` }}>
            {f.txt}
          </span>
        ))}
      </div>

      {s.reports.length > 0 && (
        <ReportModal s={s} report={s.reports[0]} remaining={s.reports.length - 1} onNext={dismissReport} />
      )}
      {s.phase === "battle" && s.battle && (
        <BattleScreen s={s} b={s.battle} onAction={playerAct} onAuto={battleAuto} onFinish={battleFinish} />
      )}
      {s.scout && s.phase === "playing" && (
        <ScoutModal
          candidates={s.scout}
          onPick={doPickScout}
          onClose={() => {
            eng.dismissScout(sRef.current);
            force();
          }}
        />
      )}
      {squadFor !== null && s.phase === "playing" && !s.scout && (
        <SquadModal s={s} missionId={squadFor} onClose={() => setSquadFor(null)} onDeploy={(ids) => runDeploy(squadFor, ids)} />
      )}
      {detailFor !== null && !s.scout && (
        <NinjaDetail
          s={s}
          ninjaId={detailFor}
          onClose={() => setDetailFor(null)}
          onTrain={(k, r) => doTrain(detailFor, k, r)}
          onPromote={(r) => doPromote(detailFor, r)}
          onPerk={(id, r) => doPerk(detailFor, id, r)}
        />
      )}

      {s.phase === "menu" && (
        <StartOverlay
          scores={scores}
          name={name}
          onName={(n) => {
            setName(n);
            setPlayerName(n);
          }}
          onStart={begin}
        />
      )}
      {s.phase === "paused" && <PauseOverlay onResume={pauseToggle} onRestart={restart} />}
      {s.phase === "over" && (
        <GameOverOverlay s={s} scores={scores} highlight={highlight} name={name} onRestart={restart} onTitle={toTitle} />
      )}
    </div>
  );
}

const FLY_COLORS = ["#f4c64f", "#4f9ad9", "#63c58c", "#e2452f", "#b46ae0", "#f2a7c3"];
function colorOf(id: number): string {
  return FLY_COLORS[id % FLY_COLORS.length];
}

function fallbackRect(): DOMRect {
  return { left: window.innerWidth * 0.5, top: window.innerHeight * 0.7, width: 10, height: 10 } as DOMRect;
}
