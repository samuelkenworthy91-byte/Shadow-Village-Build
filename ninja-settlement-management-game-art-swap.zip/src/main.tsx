import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);

// Offline support + Android/iOS "Add to Home Screen" installability.
// Skipped inside the Capacitor native shell, which serves from the bundle already.
if ("serviceWorker" in navigator && !/capacitor|file:/i.test(location.protocol)) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch(() => undefined);
  });
}

// Kill pinch-zoom / double-tap zoom so touch controls stay tight on phones.
document.addEventListener("gesturestart", (e) => e.preventDefault());
let lastTouch = 0;
document.addEventListener(
  "touchend",
  (e) => {
    const now = Date.now();
    if (now - lastTouch < 320) e.preventDefault();
    lastTouch = now;
  },
  { passive: false }
);
